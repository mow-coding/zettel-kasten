# Reading Memory And Revision

Use this reference when the human asks what the archive knows, whether a zet is fresh, what changed, or whether earlier canonical bytes can be recovered.

## Search Through WOM

For a bounded archive search, use:

```text
archive search <archive-root> <query> --count-total --format json
```

Inspect the complete-or-truncated metadata before claiming zero results or
complete coverage. Raw filesystem grep and raw SQLite queries are diagnostic
tools, not authoritative WOM search results.

Before claiming that an objet, source file, or preserved original does not
exist, run `archive objet-rediscovery-plan <archive-root> <query> --dry-run
--count-total --format json`. `archive search.complete` covers only index
truncation, not source freshness, private names, objet edges, external stores,
remote availability, or unrecovered refs; `search_incomplete` forbids global absence. For directly observed canonical source coverage versus recorded local storage evidence, run `python -B -m wom_kit.archive_cli source-reference-coverage-audit <archive-root> --dry-run --format json`; its population is not archive-wide, manifest identity is not byte proof, and a receipt does not prove current remote availability.

To inspect whether historical AI-declared inbox drafts contradict the current
official draft shape, use:

```text
archive inbox-pipeline-audit <archive-root> --dry-run --format json
```

`pipeline_shape_consistent` is not proof that WOM wrote a file,
`possible_out_of_pipeline_draft` is only a human-review signal, and
`insufficient_evidence` must remain uncertain. Do not rewrite or delete a
draft to silence the audit.

To validate one human-selected event anchor and exact member set, use:

```text
archive activity-group-membership-plan <archive-root> --request .wom-scratch/private/activity-groups/<reviewed>.json --dry-run --progress --format json
```

The request is private review evidence. Search can help a human find
candidates, but the command must not convert search results, titles, dates,
nearby files, or existing edges into membership. Treat `activity_group` as
neutral co-membership, not sequence, source, derivation, continuation, or
containment.

To add the reviewed memberships, pass the exact request and review-plan hashes
to `activity-group-membership-write --dry-run`, then use its explicit
`--approve --reviewed-by ... --affirm-memberships-reviewed` path only after
human review. Never hand-edit canonical zets. After a hard interruption,
confirm the old writer stopped, then use the recovery plan and its exact
digest-bound approval. Never infer membership or execute
`manual_forensic_hold`. A retained add/removal journal in either private root
blocks both writers before and under the shared lock; do not read, rename, or
delete it to proceed. Cleanup requires the operation-specific receipt hash and
ordered journal/lock binding to match the reviewed recovery plan.

To review explicitly selected removals, start read-only:

```text
archive activity-group-membership-removal-plan <archive-root> --request .wom-scratch/private/activity-group-removals/<reviewed>.json --dry-run --progress --format json
```

Preserve the exact private request and review digest. Preview the separate
`activity-group-membership-removal-write` with both expected digests; approve
only with an attributed human reviewer and `--affirm-removals-reviewed`.
`already_absent` rows are reviewed no-ops, not mutation evidence. After an
interruption, confirm the removal writer stopped, then use
`activity-group-membership-removal-recovery-plan --dry-run` and only the exact
digest-bound approval. Never use add recovery for removal evidence, edit a
canonical zet directly, infer candidates, expose an MCP writer, or treat
recovery as deliberate revert.

## Read Abstracts Before Full Bodies

Check first-read readiness:

```text
archive first-read-readiness <archive-root> --dry-run --progress --format json
```

Read the bounded abstract catalog and relation hints before opening full zet
bodies. Abstracts choose reading order; they do not replace the full documents
needed to answer the human's goal.

Use freshness inspection when abstracts or derived reading surfaces may lag:

```text
archive abstract-freshness <archive-root> --dry-run --progress --format json
```

Separate these questions:

- **coverage**: does each eligible zet have a usable abstract?
- **freshness**: does the abstract still describe the current canonical body?
- **semantic quality**: is the abstract accurate and useful to a human?

A structural pass cannot prove semantic quality.

## Follow The Goal Through The Archive

1. Start from abstract matches and the human's stated goal.
2. Use ties, edges, and containment as reading routes, not as a substitute for
   reading relevant nodes.
3. Open complete zet bodies in the order suggested by those routes.
4. Inspect linked objet metadata or bytes only when the answer needs source
   evidence.
5. Record unresolved contradictions instead of silently choosing one version.

## Preserve Human Change Without Inventing Entity Certainty

- Compare time-situated artifacts and their provenance before explaining how a
  person's meaning, belief, or judgment changed.
- Treat a repeated name or label as a reading clue, never as proof of one
  identity or one stable meaning.
- Treat `canonical` as the current human-reviewed archive state, not objective
  or timeless truth.
- State identity and relationship interpretations as bounded inferences with
  their artifact, time, and scope. Never silently merge records or rewrite old
  artifacts to make the graph look cleaner.
- Use ties, edges, indexes, embeddings, and graph projections to order or
  explain reading. They remain replaceable aids beneath the artifacts.
- Preserve contradictions, corrections, repeated states, and supersession as
  chronology when they help the human see change.

## Prepare Abstract Backfill Carefully

Backfill and repair commands are write workflows. Preview proposals, inspect
the exact target set and body hashes, then use only the explicit approved path.
Never treat a generated abstract as human-verified truth.

## Audit Revisions Before Handoff

After approved revision work, run:

```text
archive zet-revision-receipt-audit <archive-root> --dry-run --max-receipts 5000 --max-locks 5000 --max-problems 100 --progress --format json
```

If a v0.2 canonical revision needs to be restored, use
`zet-revision-restore-proposal-from-snapshot` to make an independent private
review copy, then use the dedicated restore plan/write workflow. Legacy v0.1
receipts still need a trusted private byte source. Do not delete revision
locks, rewrite receipts, hard-link a mutable proposal to immutable history, or
reconstruct old bytes from a displayed diff.

## Close A Session Without Trusting Chat Memory

Before a context reset or handoff, update and approve
`ops/operational-context.yml` when the mission, completed work, next work,
blockers, gotchas, or reviewed decisions changed. Then inspect:

```text
archive session-handoff-checkpoint <archive-root> --dry-run --format json
```

Resolve `needs_durable_capture` before continuing. Review the current
conversation for important decisions, corrections, unfinished work, and AI
artifacts that still exist only in chat. Move those into durable WOM artifacts,
then rerun with `--confirm-chat-reviewed`. Approval requires the exact returned
`state_digest`, `--reviewed-by`, and the same confirmation.

The command does not read the host chat or AI artifact bodies. A green receipt
proves only the bounded archive evidence and explicit review at checkpoint
time. Any important later chat decision requires another checkpoint. It is not
remote backup proof.

Search [operator-contract.md](operator-contract.md) for these exact advanced
workflows before using them:

- `zet-abstract-backfill`
- `zet-abstract-backfill-revert`
- `zet-revision-plan`
- `zet-revision-write`
- `zet-revision-restore-proposal-from-snapshot`
- `zet-revision-restore-plan`
- `zet-revision-restore-write`
- `session-handoff-checkpoint`

The complete operator contract contains required hashes, event timestamps, human affirmations, and rollback boundaries.
