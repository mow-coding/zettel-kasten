"""Small JSON Schema subset validator for archive doctor.

The checked schemas use standard JSON Schema 2020-12 keywords, but the runtime
intentionally supports only the small subset needed for local archive health
checks: type, required, properties, additionalProperties, items, enum, const,
allOf, and simple if/then conditionals.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from functools import lru_cache
import json
from pathlib import Path
from typing import Any

from .resource_paths import runtime_resource_root


SCHEMAS_ROOT = runtime_resource_root("schemas")


@dataclass
class SchemaIssue:
    code: str
    message: str
    data_path: str


@lru_cache(maxsize=None)
def load_schema(schema_name: str) -> dict[str, Any]:
    """Load each immutable packaged schema at most once per process.

    Doctor validates many records against the same small schema set.  The
    validator only reads schema dictionaries, so reusing the parsed document
    avoids repeated package-resource I/O without changing validation meaning.
    """

    path = SCHEMAS_ROOT / schema_name
    return json.loads(path.read_text(encoding="utf-8"))


def validate_schema(data: Any, schema_name: str) -> list[SchemaIssue]:
    schema = load_schema(schema_name)
    return validate_value(data, schema, "$")


def validate_value(data: Any, schema: dict[str, Any], data_path: str) -> list[SchemaIssue]:
    issues: list[SchemaIssue] = []

    all_of = schema.get("allOf")
    if isinstance(all_of, list):
        for child_schema in all_of:
            if isinstance(child_schema, dict):
                issues.extend(validate_value(data, child_schema, data_path))

    if_schema = schema.get("if")
    then_schema = schema.get("then")
    if isinstance(if_schema, dict) and isinstance(then_schema, dict):
        if not validate_value(data, if_schema, data_path):
            issues.extend(validate_value(data, then_schema, data_path))

    expected_type = schema.get("type")
    if expected_type is not None and not matches_type(data, expected_type):
        issues.append(
            SchemaIssue(
                "schema_type",
                f"{data_path} should be {format_expected_type(expected_type)}, got {type_name(data)}.",
                data_path,
            )
        )
        return issues

    enum_values = schema.get("enum")
    if isinstance(enum_values, list) and data not in enum_values:
        issues.append(
            SchemaIssue(
                "schema_enum",
                f"{data_path} should be one of: {', '.join(map(str, enum_values))}.",
                data_path,
            )
        )

    if "const" in schema and data != schema.get("const"):
        issues.append(
            SchemaIssue(
                "schema_const",
                f"{data_path} should be {schema.get('const')!r}.",
                data_path,
            )
        )

    if isinstance(data, dict):
        required = schema.get("required") or []
        if isinstance(required, list):
            for key in required:
                if isinstance(key, str) and key not in data:
                    issues.append(
                        SchemaIssue(
                            "schema_required",
                            f"{data_path}.{key} is required.",
                            f"{data_path}.{key}",
                        )
                    )

        properties = schema.get("properties") or {}
        if isinstance(properties, dict):
            for key, child_schema in properties.items():
                if key in data and isinstance(child_schema, dict):
                    issues.extend(validate_value(data[key], child_schema, f"{data_path}.{key}"))

            additional = schema.get("additionalProperties", True)
            unknown_keys = [key for key in data if key not in properties]
            if additional is False:
                for key in unknown_keys:
                    issues.append(
                        SchemaIssue(
                            "schema_additional_property",
                            f"{data_path}.{key} is not an allowed property.",
                            f"{data_path}.{key}",
                        )
                    )
            elif isinstance(additional, dict):
                for key in unknown_keys:
                    issues.extend(
                        validate_value(
                            data[key],
                            additional,
                            f"{data_path}.{key}",
                        )
                    )
            elif additional is not True:
                # A malformed or unsupported schema declaration must not be
                # interpreted as permission to accept arbitrary properties.
                issues.append(
                    SchemaIssue(
                        "schema_unsupported",
                        f"{data_path} has an unsupported additionalProperties declaration.",
                        data_path,
                    )
                )

    if isinstance(data, list):
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(data):
                issues.extend(validate_value(item, item_schema, f"{data_path}[{index}]"))

    return issues


def matches_type(data: Any, expected_type: Any) -> bool:
    if isinstance(expected_type, list):
        return any(matches_type(data, item) for item in expected_type)
    if expected_type == "object":
        return isinstance(data, dict)
    if expected_type == "array":
        return isinstance(data, list)
    if expected_type == "string":
        return isinstance(data, str) or isinstance(data, (date, datetime))
    if expected_type == "integer":
        return isinstance(data, int) and not isinstance(data, bool)
    if expected_type == "number":
        return (isinstance(data, int) or isinstance(data, float)) and not isinstance(data, bool)
    if expected_type == "boolean":
        return isinstance(data, bool)
    if expected_type == "null":
        return data is None
    return True


def format_expected_type(expected_type: Any) -> str:
    if isinstance(expected_type, list):
        return " or ".join(map(str, expected_type))
    return str(expected_type)


def type_name(data: Any) -> str:
    if isinstance(data, dict):
        return "object"
    if isinstance(data, list):
        return "array"
    if isinstance(data, str):
        return "string"
    if isinstance(data, bool):
        return "boolean"
    if isinstance(data, int):
        return "integer"
    if isinstance(data, float):
        return "number"
    if data is None:
        return "null"
    if isinstance(data, (date, datetime)):
        return "string"
    return type(data).__name__
