"""Minimal stdio MCP server for zettel-kasten archives.

This module intentionally implements a small JSON-RPC stdio subset directly.
It can later be swapped to the official MCP Python SDK without changing the
archive-facing tool functions.
"""

from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path
from typing import Any

from . import __version__
from . import approval_integrity
from . import archive_cli
from . import archive_services
from . import completion_workflows
from . import duplicate_object_reconciliation
from . import human_artifact_registry


SERVER_NAME = "zettel-kasten-archive-mcp"
SUPPORTED_PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"]
MCP_ALLOWED_ROOTS_ENV = "AI_ARCHIVE_MCP_ALLOWED_ROOTS"
MCP_ALLOW_LOCAL_PATHS_ENV = "AI_ARCHIVE_MCP_ALLOW_LOCAL_PATHS"
ZET_CATALOG_CACHE_MAX_SCOPES = 8
ZET_CATALOG_ITEM_CACHES: dict[tuple[str, str], dict[str, dict[str, Any]]] = {}

JSONRPC_PARSE_ERROR = -32700
JSONRPC_INVALID_REQUEST = -32600
JSONRPC_METHOD_NOT_FOUND = -32601
JSONRPC_INVALID_PARAMS = -32602
JSONRPC_INTERNAL_ERROR = -32603
JSONRPC_ERROR_MESSAGES = {
    JSONRPC_PARSE_ERROR: "Parse error",
    JSONRPC_INVALID_REQUEST: "Invalid Request",
    JSONRPC_METHOD_NOT_FOUND: "Method not found",
    JSONRPC_INVALID_PARAMS: "Invalid params",
    JSONRPC_INTERNAL_ERROR: "Internal error",
}

TOOL_EXECUTION_ERROR_TEXT = "Tool execution failed."
TOOL_EXECUTION_ERROR_CODE = "tool_execution_failed"


class NonFiniteJsonNumberError(ValueError):
    pass


def reject_nonstandard_json_constant(value: str) -> None:
    raise NonFiniteJsonNumberError(value)


def parse_finite_json_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise NonFiniteJsonNumberError(value)
    return parsed


def zet_catalog_item_cache(archive_root: Path, status: str) -> dict[str, dict[str, Any]]:
    key = (str(archive_root.resolve()).casefold(), status)
    cache = ZET_CATALOG_ITEM_CACHES.get(key)
    if cache is not None:
        return cache
    while len(ZET_CATALOG_ITEM_CACHES) >= ZET_CATALOG_CACHE_MAX_SCOPES:
        oldest_key = next(iter(ZET_CATALOG_ITEM_CACHES))
        del ZET_CATALOG_ITEM_CACHES[oldest_key]
    cache = {}
    ZET_CATALOG_ITEM_CACHES[key] = cache
    return cache


def configure_stdio_utf8() -> None:
    for stream in (sys.stdin, sys.stdout):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except (TypeError, ValueError):
                pass


TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "archive_work_session_manage",
        "description": (
            "Explicitly register an app, create a human-reviewed task, claim, pause, resume, complete, hand off or recover its session. "
            "The AI retains original registration selection and app/task references before mutation; "
            "Request-init returns a new routing-only task reference for an explicit registered app, "
            "without creating, approving or saving a task. Retain it before create; "
            "resume uses that original reference and never another request-init. "
            "humans never copy hashes or JSON. Private labels are input only, not output. "
            "Create/accept/handoff/recover have no dry-run preview. "
            "Handoff approve uses the original current session and target_app_ref. "
            "Accept approve uses a new task route and work_session_ref of the predecessor; "
            "it creates an unclaimed successor and does not transfer artifact responsibility. "
            "Accept resume/review_original uses app and original task route only, without a replacement predecessor. "
            "Recover approve selects the same app's claimed active session using explicit app/task/session references, "
            "with no target_app_ref, and issues its replacement claim only under the existing OS lock and human decision. "
            "Recover resume/review_original retains those exact original references and accepts no replacement reviewer. "
            "Review_original requires approve and only reopens an original pending decision with genuinely absent claim evidence. "
            "Action pause/resume/complete with apply starts a state transition; the resume flag instead "
            "continues only the original operation and never creates a new claim or human approval."
            " Completion closes only session metadata, never deleting or cleaning up archive data."
        ),
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": False},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string"},
                "action": {"type": "string", "enum": ["register-app", "request-init", "create", "claim", "pause", "resume", "complete", "handoff", "accept", "recover"]},
                "dry_run": {"type": "boolean", "default": False},
                "approve": {"type": "boolean", "default": False},
                "apply": {"type": "boolean", "default": False},
                "resume": {"type": "boolean", "default": False},
                "review_original": {"type": "boolean", "default": False},
                "client_app_ref": {"type": "string"},
                "task_route_ref": {"type": "string"},
                "work_session_ref": {"type": "string"},
                "target_app_ref": {"type": "string"},
                "request": {
                    "type": "object", "additionalProperties": False,
                    "properties": {
                        "label": {"type": "string"},
                        "reviewer_claim": {"type": "string"},
                        "selection": {
                            "type": "object", "additionalProperties": False,
                            "properties": {key: {"type": "string"} for key in
                                           ("schema", "archive_identity_sha256", "client_app_ref",
                                            "plan_sha256", "before_sha256", "label_sha256")},
                            "required": ["schema", "archive_identity_sha256", "client_app_ref",
                                         "plan_sha256", "before_sha256", "label_sha256"],
                        },
                    },
                },
            },
            "required": ["archive_root", "action"],
        },
    },
    {
        "name": "archive_work_session",
        "description": (
            "Read one complete work-session registry generation using opaque references and cursor pages. "
            "Does not disclose private labels or claim tokens, infer legacy artifact ownership, or grant write authority. "
            "Only list/inspect are exposed by this development slice."
        ),
        "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True,
                        "openWorldHint": False},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string"},
                "action": {"type": "string", "enum": ["list", "inspect"], "default": "list"},
                "kind": {"type": "string", "enum": ["app", "workstream", "session"], "default": "session"},
                "ref": {"type": "string"}, "client_app_ref": {"type": "string"},
                "workstream_ref": {"type": "string"}, "cursor": {"type": "string"},
                "page_size": {"type": "integer", "minimum": 1, "maximum": 2000, "default": 20},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "wom_profile_list",
        "description": "List read-only WOM profile registry entries before resolving archive runtime context.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "registry": {"type": "string", "description": "Path to the WOM profile registry YAML file."},
                "current_profile": {"type": "string"},
                "strict": {"type": "boolean", "default": False},
                "redact_local_paths": {
                    "type": "boolean",
                    "default": True,
                    "description": "Local paths remain redacted unless AI_ARCHIVE_MCP_ALLOW_LOCAL_PATHS=1 is set on the MCP server.",
                },
            },
            "required": ["registry"],
        },
    },
    {
        "name": "wom_profile_resolve",
        "description": "Resolve a requested WOM profile by profile id, label, or alias before runtime-context or draft work.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "registry": {"type": "string", "description": "Path to the WOM profile registry YAML file."},
                "target": {"type": "string", "description": "Requested profile id, label, or alias."},
                "current_profile": {"type": "string"},
                "strict": {"type": "boolean", "default": False},
                "redact_local_paths": {
                    "type": "boolean",
                    "default": True,
                    "description": "Local paths remain redacted unless AI_ARCHIVE_MCP_ALLOW_LOCAL_PATHS=1 is set on the MCP server.",
                },
            },
            "required": ["registry", "target"],
        },
    },
    {
        "name": "wom_profile_wallet_check",
        "description": "Preview wallet-ready WOM profile/node identity metadata. Read-only; never generates keys, signs, registers wallets, or calls blockchain/provider APIs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root used for context."},
                "profile": {"type": "string", "description": "Requested profile id, label, or alias."},
                "registry": {
                    "type": "string",
                    "description": "Optional path to the WOM profile registry YAML file. If omitted, fixed archive-local registry paths are checked.",
                },
                "dry_run": {"type": "boolean", "default": True},
                "redact_local_paths": {
                    "type": "boolean",
                    "default": True,
                    "description": "Local paths remain redacted unless AI_ARCHIVE_MCP_ALLOW_LOCAL_PATHS=1 is set on the MCP server.",
                },
            },
            "required": ["archive_root", "profile"],
        },
    },
    {
        "name": "archive_doctor",
        "description": "Inspect a zettel-kasten archive for structural, metadata, object manifest, and zettel policy issues.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "strict": {"type": "boolean", "default": False},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "archive_runtime_context",
        "description": "Return quick read-only AI runtime context for a mounted archive before draft, dry-run, or mint approval work; complete Doctor is explicit.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "expected_archive_id": {"type": "string"},
                "expected_type": {"type": "string", "enum": sorted(archive_services.RUNTIME_CONTEXT_ARCHIVE_TYPES)},
                "strict": {"type": "boolean", "default": False},
                "full_doctor": {
                    "type": "boolean",
                    "default": False,
                    "description": "Run complete archive Doctor diagnostics. The default returns bounded runtime context without scanning all zets or receipts.",
                },
                "redact_local_paths": {
                    "type": "boolean",
                    "default": True,
                    "description": "Local paths remain redacted unless AI_ARCHIVE_MCP_ALLOW_LOCAL_PATHS=1 is set on the MCP server.",
                },
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "archive_capabilities",
        "description": "Return the same read-only parser-derived CLI command and CapabilityAvailability truth as archive capabilities --machine; no archive, provider, credential, or network access is performed.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "no_commands": {
                    "type": "boolean",
                    "default": False,
                    "description": "Omit the detailed command and availability rows while retaining full counts.",
                },
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "prompt_boundary_check",
        "description": "Heuristic dry-run prompt-injection boundary check. Read-only; never executes inspected text, calls LLMs, calls providers, approves, mints, or mutates files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "text": {"type": "string", "description": "Inline untrusted text to inspect."},
                "path": {"type": "string", "description": "Archive-relative zet or text path to inspect."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "github_repository_setup_plan",
        "description": "Plan GitHub repository metadata for a WOM profile. Read-only; never creates repos, remotes, pushes, OAuth, or API calls.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "profile_id": {"type": "string"},
                "profile_slug": {"type": "string"},
                "github_owner": {"type": "string"},
                "github_account_ref": {"type": "string"},
                "repo_name": {"type": "string"},
                "visibility": {
                    "type": "string",
                    "enum": sorted(archive_services.GITHUB_REPOSITORY_ALLOWED_VISIBILITIES),
                    "default": archive_services.GITHUB_REPOSITORY_DEFAULT_VISIBILITY,
                },
                "remote_protocol": {
                    "type": "string",
                    "enum": sorted(archive_services.GITHUB_REPOSITORY_REMOTE_PROTOCOLS),
                    "default": archive_services.GITHUB_REPOSITORY_DEFAULT_REMOTE_PROTOCOL,
                },
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_setup_plan",
        "description": "Plan object storage metadata for WOM objets. Read-only; never creates buckets, uploads, syncs, copies, hashes, OAuth, or API calls.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "provider": {"type": "string"},
                "profile_id": {"type": "string"},
                "profile_slug": {"type": "string"},
                "storage_account_ref": {"type": "string"},
                "bucket_name": {"type": "string"},
                "region": {"type": "string"},
                "endpoint_ref": {"type": "string"},
                "objet_prefix": {"type": "string"},
                "visibility": {
                    "type": "string",
                    "enum": sorted(archive_services.OBJECT_STORAGE_ALLOWED_VISIBILITIES),
                    "default": archive_services.OBJECT_STORAGE_DEFAULT_VISIBILITY,
                },
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "provider_setup_status",
        "description": "Check local provider setup metadata and receipts. Read-only; never calls providers, creates repos or buckets, uploads, syncs, pushes, hashes, OAuth, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_adapter_readiness_plan",
        "description": "Check readiness for a future object-storage adapter. Read-only; never calls providers, retrieves secrets, uploads, downloads, creates presigned URLs, reads object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.OBJECT_STORAGE_ADAPTER_OPERATIONS),
                    "default": "presigned_download",
                },
                "provider_ref": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_operation_request_plan",
        "description": "Compose a read-only approval request package before a future object-storage operation. Never calls providers, retrieves secrets, uploads, downloads, creates presigned URLs, reads object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.OBJECT_STORAGE_ADAPTER_OPERATIONS),
                    "default": "presigned_download",
                },
                "object_id": {"type": "string"},
                "store_ref": {"type": "string"},
                "ttl_seconds": {"type": "integer", "default": archive_services.PRESIGNED_URL_DEFAULT_TTL_SECONDS},
                "provider_ref": {"type": "string"},
                "credential_id": {"type": "string", "default": "cred:object-storage"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS), "default": "password_manager"},
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS), "default": "needs_review"},
                "approval_receipt": {"type": "string"},
                "consumer": {"type": "string", "default": "wom:adapter:object-storage"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS), "default": "windows"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_adapter_execution_contract",
        "description": "Preview the read-only execution contract a future object-storage upload adapter must satisfy. Never calls providers, retrieves secrets, reads object bytes, uploads, writes receipts, or updates manifests.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.OBJECT_STORAGE_ADAPTER_EXECUTION_CONTRACT_OPERATIONS),
                    "default": "upload_object",
                },
                "object_id": {"type": "string"},
                "store_ref": {"type": "string"},
                "provider_ref": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_upload_plan",
        "description": "Plan a content-addressed object-storage upload with digest-aware idempotency. Read-only; never calls providers, retrieves secrets, reads object bytes, uploads, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "provider_kind": {"type": "string", "enum": sorted(archive_services.OBJECT_STORAGE_ALLOWED_PROVIDERS), "default": "cloudflare-r2"},
                "store_ref": {"type": "string"},
                "access_key_id_ref": {"type": "string"},
                "secret_access_key_ref": {"type": "string"},
                "only": {"type": "string"},
                "max_objects": {"type": "integer"},
                "skip_uploaded": {"type": "boolean", "default": False},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "object_storage_upload_verify",
        "description": "Verify planned objects' local RAW bytes hash to their object id. Read-only; never calls providers, retrieves secrets, uploads, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "provider_kind": {"type": "string", "enum": sorted(archive_services.OBJECT_STORAGE_ALLOWED_PROVIDERS), "default": "cloudflare-r2"},
                "store_ref": {"type": "string"},
                "only": {"type": "string"},
                "max_objects": {"type": "integer"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "human_artifact_store_plan",
        "description": "Plan a user-facing human artifact surface. Read-only; never creates notes, publishes posts, uploads files, starts OAuth, calls providers, mints, or runs ZET transport.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "surface_kind": {"type": "string", "enum": sorted(archive_services.HUMAN_ARTIFACT_SURFACE_KINDS)},
                "surface_ref": {"type": "string"},
                "role": {
                    "type": "string",
                    "enum": sorted(archive_services.HUMAN_ARTIFACT_ROLES),
                    "default": archive_services.HUMAN_ARTIFACT_DEFAULT_ROLE,
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "surface_kind"],
        },
    },
    {
        "name": "human_artifact_root_registration_plan",
        "description": (
            "Plan registration of one project .wom-scratch scope or one "
            "explicitly reviewed delivery root. Read-only and metadata-only; "
            "MCP cannot approve or write the private registry, so live "
            "registration must use the local CLI."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "project_root": {"type": "string"},
                "root_kind": {
                    "type": "string",
                    "enum": sorted(human_artifact_registry.EXTERNAL_ROOT_KINDS),
                    "default": "external_project",
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {
                    "type": "boolean",
                    "const": False,
                    "default": False,
                    "description": (
                        "Must remain false. Use human-artifact-register-root "
                        "in a local terminal for the native approval dialog."
                    ),
                },
            },
            "required": ["archive_root", "project_root"],
        },
    },
    {
        "name": "human_artifact_registry_scan",
        "description": (
            "Run a bounded metadata-only human-artifact scan. Read-only; "
            "never opens artifact bodies or returns file names or paths."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "max_entries_per_root": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": human_artifact_registry.MAX_ENTRIES_PER_ROOT,
                    "default": human_artifact_registry.DEFAULT_MAX_ENTRIES_PER_ROOT,
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {"type": "boolean", "const": False, "default": False},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "human_artifact_transition_plan",
        "description": (
            "Plan one append-only human-artifact lifecycle transition from "
            "caller-supplied content and destination bindings. Read-only; "
            "live receipt writing requires the local native-approval CLI."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "artifact_id": {"type": "string"},
                "target_state": {
                    "type": "string",
                    "enum": sorted(human_artifact_registry.LIFECYCLE_STATES),
                },
                "content_sha256": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "size_bytes": {"type": "integer", "minimum": 0},
                "related_refs": {
                    "type": "array",
                    "maxItems": 32,
                    "items": {
                        "type": "object",
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": [
                                    "object_id",
                                    "zet_id",
                                    "receipt_id",
                                    "artifact_version_id",
                                ],
                            },
                            "ref": {"type": "string"},
                        },
                        "required": ["kind", "ref"],
                        "additionalProperties": False,
                    },
                },
                "max_entries_per_root": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": human_artifact_registry.MAX_ENTRIES_PER_ROOT,
                    "default": human_artifact_registry.DEFAULT_MAX_ENTRIES_PER_ROOT,
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {
                    "type": "boolean",
                    "const": False,
                    "default": False,
                    "description": (
                        "Must remain false. Use human-artifact-transition in "
                        "a local terminal for the native approval dialog."
                    ),
                },
            },
            "required": [
                "archive_root",
                "artifact_id",
                "target_state",
                "content_sha256",
                "size_bytes",
            ],
        },
    },
    {
        "name": "duplicate_object_reconciliation_plan",
        "description": (
            "Classify duplicate object-manifest rows by count and digest. "
            "Read-only; MCP cannot apply reconciliation, which requires the "
            "local native exact-approval CLI."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {"type": "boolean", "const": False, "default": False},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "approval_integrity_audit",
        "description": (
            "Classify a bounded set of operation receipts through the "
            "existing archive authentication key. Read-only and content-free."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "max_receipts": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10000,
                    "default": 4096,
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {"type": "boolean", "const": False, "default": False},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "approval_integrity_guard",
        "description": (
            "Read one authenticated approval-integrity overlay chain and "
            "fail closed when review is active or the ledger is invalid."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "affected_kind": {
                    "type": "string",
                    "enum": sorted(approval_integrity.AFFECTED_KINDS),
                },
                "affected_id_sha256": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "max_overlays": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10000,
                    "default": 1024,
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {"type": "boolean", "const": False, "default": False},
            },
            "required": ["archive_root", "affected_kind", "affected_id_sha256"],
        },
    },
    {
        "name": "approval_integrity_overlay_plan",
        "description": (
            "Plan one append-only approval-integrity overlay from exact "
            "receipt and affected-id digests. Read-only; live repair requires "
            "the local native exact-approval CLI."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "operation_receipt": {
                    "type": "string",
                    "description": "Exact archive-relative receipt path; never echoed.",
                },
                "expected_operation_receipt_sha256": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "affected_kind": {
                    "type": "string",
                    "enum": sorted(approval_integrity.AFFECTED_KINDS),
                },
                "affected_id_sha256": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "state": {
                    "type": "string",
                    "enum": sorted(approval_integrity.OVERLAY_STATES),
                },
                "expected_current_overlay_digest": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "max_overlays": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10000,
                    "default": 1024,
                },
                "dry_run": {"type": "boolean", "const": True, "default": True},
                "approve": {
                    "type": "boolean",
                    "const": False,
                    "default": False,
                    "description": (
                        "Must remain false. Use approval-integrity-overlay "
                        "locally for the native exact-approval dialog."
                    ),
                },
            },
            "required": [
                "archive_root",
                "operation_receipt",
                "expected_operation_receipt_sha256",
                "affected_kind",
                "affected_id_sha256",
                "state",
            ],
        },
    },
    {
        "name": "imap_mailbox_plan",
        "description": "Plan a read-only Gmail, Naver, or generic IMAP mailbox source. Dry-run only; never connects, logs in, reads headers/bodies/attachments, sends mail, changes flags, stores secrets, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "source_id": {"type": "string"},
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "imap_mailbox_operation_request_plan",
        "description": "Compose a read-only approval request package before a future IMAP mailbox operation. Dry-run only; never connects, logs in, reads headers/bodies/attachments, opens keyrings, starts OAuth, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "source_id": {"type": "string"},
                "adapter_id": {
                    "type": "string",
                    "description": "Optional safe adapter manifest id to check under config/imap-adapters/.",
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS),
                    "default": "header_metadata_scan",
                },
                "max_messages": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_LIMIT,
                    "default": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT,
                },
                "since_days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_SINCE_DAYS_LIMIT,
                },
                "credential_id": {"type": "string", "default": "cred:mail-source-access"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "credential_provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "approval_receipt": {"type": "string"},
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "imap_mailbox_adapter_readiness_plan",
        "description": "Check readiness for a future IMAP mailbox adapter. Dry-run only; never connects, logs in, reads headers/bodies/attachments, opens keyrings, starts OAuth, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "source_id": {"type": "string"},
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS),
                    "default": "header_metadata_scan",
                },
                "max_messages": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_LIMIT,
                    "default": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT,
                },
                "since_days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_SINCE_DAYS_LIMIT,
                },
                "credential_id": {"type": "string", "default": "cred:mail-source-access"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "credential_provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "approval_receipt": {"type": "string"},
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "imap_mailbox_selection_plan",
        "description": "Plan future read-only mailbox message selection. Dry-run only; never connects, logs in, selects/searches a mailbox, lists message ids, reads headers/bodies/attachments, opens keyrings, starts OAuth, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "source_id": {"type": "string"},
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS),
                    "default": "header_metadata_scan",
                },
                "selection_rule": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_SELECTION_RULES),
                    "default": "newest_first",
                },
                "selector_id": {"type": "string", "default": "mail-selection:recent-inbox"},
                "max_messages": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_LIMIT,
                    "default": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT,
                },
                "since_days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_SINCE_DAYS_LIMIT,
                },
                "credential_id": {"type": "string", "default": "cred:mail-source-access"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "credential_provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "approval_receipt": {"type": "string"},
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "imap_mailbox_adapter_audit_plan",
        "description": "Preview a non-secret future IMAP adapter audit receipt. Dry-run only; never connects, logs in, selects/searches a mailbox, lists messages, reads headers/bodies/attachments, opens keyrings, starts OAuth, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_id": {"type": "string"},
                "source_id": {"type": "string"},
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS),
                    "default": "header_metadata_scan",
                },
                "selection_rule": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_SELECTION_RULES),
                    "default": "newest_first",
                },
                "selector_id": {"type": "string", "default": "mail-selection:recent-inbox"},
                "max_messages": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_LIMIT,
                    "default": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT,
                },
                "since_days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_SINCE_DAYS_LIMIT,
                },
                "credential_id": {"type": "string", "default": "cred:mail-source-access"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "credential_provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "approval_receipt": {"type": "string"},
                "result_status": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ADAPTER_AUDIT_RESULT_STATUSES),
                    "default": "not_run",
                },
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_id", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "imap_mailbox_adapter_manifest_plan",
        "description": "Preview a non-secret future IMAP adapter manifest. Dry-run only; never writes manifests, connects, logs in, selects/searches a mailbox, lists messages, reads headers/bodies/attachments, opens keyrings, starts OAuth, or calls providers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_id": {"type": "string"},
                "providers": {
                    "type": "array",
                    "items": {"type": "string", "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS)},
                },
                "operations": {
                    "type": "array",
                    "items": {"type": "string", "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS)},
                },
                "selection_rules": {
                    "type": "array",
                    "items": {"type": "string", "enum": sorted(archive_services.IMAP_MAILBOX_SELECTION_RULES)},
                },
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_id"],
        },
    },
    {
        "name": "imap_mailbox_adapter_preflight_plan",
        "description": "Run a read-only preflight before any future IMAP adapter execution. Dry-run only; never connects, logs in, selects/searches a mailbox, lists messages, reads headers/bodies/attachments, opens keyrings, starts OAuth, calls providers, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_id": {"type": "string"},
                "source_id": {"type": "string"},
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_PROVIDERS),
                    "default": "generic_imap",
                },
                "imap_host": {"type": "string"},
                "imap_port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 993},
                "account_ref": {"type": "string"},
                "username_ref": {"type": "string"},
                "auth_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_ALLOWED_AUTH_MODES),
                    "default": "app_password_ref",
                },
                "app_password_ref": {"type": "string"},
                "oauth_token_ref": {"type": "string"},
                "mailbox_ref": {"type": "string", "default": "imap:mailbox:inbox"},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_OPERATION_REQUEST_OPERATIONS),
                    "default": "header_metadata_scan",
                },
                "selection_rule": {
                    "type": "string",
                    "enum": sorted(archive_services.IMAP_MAILBOX_SELECTION_RULES),
                    "default": "newest_first",
                },
                "selector_id": {"type": "string", "default": "mail-selection:recent-inbox"},
                "max_messages": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_LIMIT,
                    "default": archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT,
                },
                "since_days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.IMAP_MAILBOX_OPERATION_SINCE_DAYS_LIMIT,
                },
                "credential_id": {"type": "string", "default": "cred:mail-source-access"},
                "credential_ref": {"type": "string"},
                "credential_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS)},
                "credential_provider": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS)},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {"type": "string", "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS)},
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "approval_receipt": {"type": "string"},
                "consumer": {"type": "string", "default": "wom:adapter:imap-mailbox"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_id", "source_id", "account_ref", "username_ref"],
        },
    },
    {
        "name": "credential_ref_plan",
        "description": "Plan a local credential reference for mail, model APIs, OCR APIs, storage, or backups. Dry-run only; never reads, writes, prompts for, or echoes secret values.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                    "default": "generic_secret",
                },
                "purpose": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PURPOSES),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "credential_id", "credential_ref"],
        },
    },
    {
        "name": "credential_ref_inventory",
        "description": "List known credential refs without echoing ref values or secrets. Read-only; never reads environment variables, opens keyrings, calls providers, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "credential_store_recommendation",
        "description": "Recommend a password manager, OS keyring, or secret manager class for a human scenario. Read-only; never reads, writes, prompts for, or echoes secrets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "scenario": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_SCENARIOS),
                },
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "scenario"],
        },
    },
    {
        "name": "credential_vault_onboarding_plan",
        "description": "Plan safe human vault/keyring onboarding without opening password managers, browser stores, keyrings, files, environment variables, or providers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "scenario": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_SCENARIOS),
                },
                "store_id": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_VAULT_ONBOARDING_STORE_IDS),
                    "default": "recommended",
                },
                "credential_id": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "scenario"],
        },
    },
    {
        "name": "credential_plaintext_migration_plan",
        "description": "Plan safe migration from a human-selected plaintext secret note into a real vault/keyring without reading files, returning secrets, writing vaults, or deleting plaintext.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "source_label": {"type": "string", "description": "Safe non-secret source label; not a path."},
                "credential_id": {"type": "string"},
                "target_store_id": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_VAULT_ONBOARDING_STORE_IDS),
                    "default": "recommended",
                },
                "scenario": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_SCENARIOS),
                    "default": "personal_local_first",
                },
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source_label", "credential_id"],
        },
    },
    {
        "name": "credential_policy_check",
        "description": "Check a credential request against the approval policy gate before any future adapter can run. Read-only; never opens stores, reads secrets, writes receipts, or executes adapters.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "approval_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "adapter_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS),
                },
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_OPERATIONS),
                },
                "consumer": {"type": "string", "default": "wom_local_adapter"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "approval_receipt": {
                    "type": "string",
                    "description": "Optional archive-relative credential access approval receipt to verify.",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "credential_id", "action_kind"],
        },
    },
    {
        "name": "credential_keepassxc_command_plan",
        "description": "Plan a KeePassXC CLI add command after verifying an approval receipt. Read-only; never executes keepassxc-cli, opens vaults, reads paths, prompts for, writes, or echoes secrets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                    "default": "plaintext_secret_migration",
                },
                "operation": {
                    "type": "string",
                    "enum": ["plaintext_secret_migration", "write_new_secret"],
                    "default": "plaintext_secret_migration",
                },
                "approval_receipt": {
                    "type": "string",
                    "description": "Archive-relative credential access approval receipt to verify.",
                },
                "entry_label": {"type": "string", "description": "Safe non-secret KeePassXC entry label."},
                "group_label": {"type": "string", "description": "Optional safe non-secret KeePassXC group label."},
                "database_ref": {
                    "type": "string",
                    "description": "Safe label for the human-selected database; not a local path.",
                    "default": "keepassxc:human-selected-database",
                },
                "consumer": {"type": "string", "default": "wom:adapter:keepassxc"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "credential_id", "approval_receipt", "entry_label"],
        },
    },
    {
        "name": "credential_access_broker_plan",
        "description": "Plan a future approved credential broker request without retrieving secrets. Read-only; never opens password managers, browser stores, keyrings, files, or environment variables.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "consumer": {"type": "string", "default": "wom_local_adapter"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "credential_id", "action_kind"],
        },
    },
    {
        "name": "credential_access_approval_plan",
        "description": "Preview a future credential access approval receipt without writing or retrieving secrets. Read-only; never opens vaults, keyrings, browser stores, files, or environment variables.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "decision": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_APPROVAL_DECISIONS),
                    "default": "needs_review",
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                    "default": "password_manager",
                },
                "consumer": {"type": "string", "default": "wom_local_adapter"},
                "reviewed_by": {"type": "string", "default": "human:pending-review"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "credential_id", "action_kind"],
        },
    },
    {
        "name": "credential_adapter_readiness_plan",
        "description": "Preview a future credential adapter contract without opening keyrings, vaults, browser stores, files, or environment variables. Read-only; never retrieves, writes, or echoes secrets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS),
                },
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_OPERATIONS),
                },
                "credential_id": {"type": "string"},
                "credential_ref": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                },
                "consumer": {"type": "string"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_kind", "operation", "credential_id", "action_kind"],
        },
    },
    {
        "name": "credential_adapter_manifest_plan",
        "description": "Preview a non-secret future credential adapter manifest without writing it. Read-only; never opens keyrings, vaults, browser stores, files, or environment variables.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_id": {"type": "string"},
                "adapter_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS),
                },
                "operations": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": sorted(archive_services.CREDENTIAL_ADAPTER_OPERATIONS),
                    },
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                },
                "consumer": {"type": "string"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_id", "adapter_kind"],
        },
    },
    {
        "name": "credential_adapter_audit_plan",
        "description": "Preview a non-secret future credential adapter audit receipt without writing it. Read-only; never executes adapters, opens stores, reads secrets, or calls providers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "adapter_id": {"type": "string"},
                "adapter_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_KINDS),
                },
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_OPERATIONS),
                },
                "credential_id": {"type": "string"},
                "credential_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_KINDS),
                },
                "provider": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_REF_ALLOWED_PROVIDERS),
                },
                "action_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_ACTIONS),
                },
                "result_status": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ADAPTER_AUDIT_RESULT_STATUSES),
                    "default": "not_run",
                },
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_ACCESS_BROKER_STORE_KINDS),
                },
                "consumer": {"type": "string"},
                "platform": {
                    "type": "string",
                    "enum": sorted(archive_services.CREDENTIAL_STORE_RECOMMENDATION_PLATFORMS),
                    "default": "windows",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "adapter_id", "adapter_kind", "operation", "credential_id", "action_kind"],
        },
    },
    {
        "name": "zet_surface_prototype_plan",
        "description": "Plan a user-selected ZET surface prototype for WordPress, Joplin, Notion, or Obsidian. Read-only; never calls providers, requests tokens, writes notes, publishes, syncs, mints, or transports.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "surface_kind": {"type": "string", "enum": sorted(archive_services.ZET_SURFACE_PROTOTYPE_KINDS)},
                "surface_ref": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "surface_kind"],
        },
    },
    {
        "name": "prehashed_objet_ledger_preview",
        "description": "Preview an already-hashed external content-addressed objet ledger. Read-only; never echoes row values, reads blob bytes, registers manifests, writes, uploads, or calls providers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "ledger": {"type": "string", "description": "UTF-8 JSONL ledger path."},
                "store_kind": {
                    "type": "string",
                    "enum": sorted(archive_services.PREHASHED_OBJET_LEDGER_STORE_KINDS),
                    "default": "generic_content_addressed_store",
                },
                "sha256_field": {"type": "string", "default": "sha256"},
                "size_field": {"type": "string", "default": "bytes"},
                "mime_field": {"type": "string", "default": "mime"},
                "max_rows": {"type": "integer", "default": 100000},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "ledger"],
        },
    },
    {
        "name": "resolve_objet_ref",
        "description": "Resolve one sha256 objet reference to safe manifest, local, and external candidates. Read-only; never echoes absolute paths, calls providers, creates URLs, downloads, hashes bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "object_id": {"type": "string", "description": "sha256:<64 lowercase hex> or bare 64 lowercase hex."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "object_id"],
        },
    },
    {
        "name": "presigned_url_plan",
        "description": "Plan a future provider presigned URL request for an objet. Read-only; never creates URLs, calls providers, reads object bytes, downloads, uploads, retrieves secrets, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "object_id": {"type": "string", "description": "sha256:<64 lowercase hex> or bare 64 lowercase hex."},
                "store_ref": {"type": "string", "description": "Safe external store label/ref, not a URL, path, token, or secret."},
                "operation": {
                    "type": "string",
                    "enum": sorted(archive_services.PRESIGNED_URL_OPERATIONS),
                    "default": "download",
                },
                "ttl_seconds": {
                    "type": "integer",
                    "default": archive_services.PRESIGNED_URL_DEFAULT_TTL_SECONDS,
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "object_id"],
        },
    },
    {
        "name": "project_intake_plan",
        "description": "Plan one staged project folder intake session. Read-only; returns human review questions and never reads bodies, recurses, writes, uploads, drafts, mints, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "staged_folder": {"type": "string", "description": "Path to one staged project folder."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "staged_folder"],
        },
    },
    {
        "name": "project_intake_unpack_queue",
        "description": "Queue top-level staged items for human-guided unpacking. Read-only; returns opaque item refs and never exposes names, reads bodies, hashes, writes, captures, drafts, mints, uploads, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "staged_folder": {"type": "string", "description": "Path to one staged project folder."},
                "receipt": {"type": "string", "description": "Optional archive-relative project-intake decisions receipt."},
                "max_items": {"type": "integer", "default": 25},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "staged_folder"],
        },
    },
    {
        "name": "project_intake_unpack_choice",
        "description": "Record one human-confirmed unpack choice. Approval-gated; validates a choice file, completed project-intake receipt, and current opaque queue without exposing staged entry names or local paths.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "choice": {"type": "string", "description": "Path to one reviewed unpack-choice JSON file."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt."},
                "staged_folder": {"type": "string", "description": "Path to one staged project folder."},
                "dry_run": {"type": "boolean", "default": True},
                "approve": {"type": "boolean", "default": False},
                "reviewed_by": {"type": "string", "description": "Reviewer id required when approve is true."},
            },
            "required": ["archive_root", "choice", "receipt", "staged_folder"],
        },
    },
    {
        "name": "project_intake_staging_guide",
        "description": "Show where to stage one project folder before a project intake session. Read-only; never creates folders, moves files, uploads, captures, drafts, mints, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "project_slug": {"type": "string", "description": "Lowercase ASCII project slug for the staged folder."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "project_slug"],
        },
    },
    {
        "name": "project_intake_session_guide",
        "description": "Show the next safe human-guided project intake step. Read-only; never writes decisions, captures, drafts, mints, uploads, cleans, or runs automatically.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "project_slug": {"type": "string", "description": "Lowercase ASCII project slug for staging guidance."},
                "staged_folder": {"type": "string", "description": "One staged project folder for a new intake session."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt for a continuing session."},
                "session_id": {"type": "string", "description": "Optional safe session id for a new decision template."},
                "staged_folder_ref": {"type": "string", "description": "Optional non-secret staged folder reference for a new decision template."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "project_intake_status",
        "description": "Review one project-intake decisions receipt. Read-only; returns checklist coverage and next human-review prompts without echoing answer values.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "receipt"],
        },
    },
    {
        "name": "project_intake_next_question",
        "description": "Return the next human-review question for one project intake session. Read-only; never writes decisions, echoes answer values, reads bodies, captures, drafts, mints, uploads, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "staged_folder": {"type": "string", "description": "One staged project folder for a new intake session."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt for a continuing session."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "project_intake_decision_template",
        "description": "Build a next-question project-intake decisions JSON template. Read-only; never fills answers, echoes previous answer values, writes decisions, captures, drafts, mints, uploads, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "staged_folder": {"type": "string", "description": "One staged project folder for a new intake session."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt for a continuing session."},
                "session_id": {"type": "string", "description": "Optional safe session id for the template."},
                "staged_folder_ref": {"type": "string", "description": "Optional non-secret staged folder reference for the template."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "project_intake_item_plan",
        "description": "Preview the source-intake dry-run route for one human-selected project-intake item. Read-only; redacts local paths and never writes, captures, drafts, mints, uploads, or cleans.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "receipt": {"type": "string", "description": "Archive-relative project-intake decisions receipt."},
                "local_path": {"type": "string", "description": "One local file selected by the human for item planning."},
                "source_role": {"type": "string", "description": "Optional source role for later draft provenance."},
                "title": {"type": "string", "description": "Optional non-secret human-reviewed title."},
                "mime": {"type": "string", "description": "Optional MIME type."},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "receipt", "local_path"],
        },
    },
    {
        "name": "git_backup_reconcile_plan",
        "description": (
            "Preview or execute the existing session-scoped Git backup using exact native human approval. "
            "Fresh preview/apply require the explicit app/task/work-session route; apply also requires reviewed_by. "
            "Resume and review_original select only the retained original by app/task (optional work-session); "
            "omit every fresh option and reviewer, including null/default values. review_original redisplays "
            "the original approval when needed, not a replacement approval. Unknown/other-session changes stay excluded. "
            "No eligible outputs is not a completed backup; metadata receipts do not prove source-byte capture."
        ),
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": True},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string", "minLength": 1, "maxLength": 65536},
                "mode": {"type": "string", "enum": ["preview", "apply", "resume", "review_original"]},
                "client_app_ref": {"type": "string", "minLength": 1},
                "task_route_ref": {"type": "string", "minLength": 1},
                "work_session_ref": {"type": "string", "minLength": 1},
                "reviewed_by": {"type": "string", "minLength": 1},
                "remote_name": {"type": "string", "minLength": 1},
                "branch": {"type": "string", "minLength": 1},
                "credential_mode": {"type": "string", "enum": ["stored"]},
                "max_changes": {"type": "integer", "minimum": 1, "maximum": 100000},
                "max_changed_bytes": {"type": "integer", "minimum": 1, "maximum": 2147483648},
            },
            "required": ["archive_root", "mode", "client_app_ref", "task_route_ref"],
            "allOf": [
                {"if": {"properties": {"mode": {"enum": ["preview", "apply"]}}},
                 "then": {"required": ["work_session_ref"]}},
                {"if": {"properties": {"mode": {"const": "apply"}}},
                 "then": {"required": ["reviewed_by"]},
                 "else": {"not": {"required": ["reviewed_by"]}}},
                {"if": {"properties": {"mode": {"enum": ["resume", "review_original"]}}},
                 "then": {"not": {"anyOf": [{"required": [key]} for key in (
                     "remote_name", "branch", "credential_mode", "max_changes", "max_changed_bytes")]}}},
            ],
        },
    },
    {
        "name": "source_intake_batch",
        "description": (
            "Preview or record a source-intake batch in the explicit app/task work session with exact native human approval. "
            "Fresh preview/apply require work_session_ref and manifest; apply also requires reviewed_by. "
            "This records metadata receipts and, when prepared, a capture request; it does not capture source bytes. "
            "Resume selects only the retained original by app/task (optional work-session); omit manifest and reviewer "
            "entirely, including null values. No replacement approval, hashes or approval IDs are accepted. "
            "Explicit review_original may reopen only the retained original whose claim was never published; "
            "normal resume never opens a new approval dialog."
        ),
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": False},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string", "minLength": 1, "maxLength": 65536},
                "mode": {"type": "string", "enum": ["preview", "apply", "resume", "review_original"]},
                "client_app_ref": {"type": "string", "minLength": 1},
                "task_route_ref": {"type": "string", "minLength": 1},
                "work_session_ref": {"type": "string", "minLength": 1},
                "manifest": {"type": "string", "minLength": 1,
                             "description": "Existing batch request JSON, relative to archive_root or absolute; fresh modes only."},
                "reviewed_by": {"type": "string", "minLength": 1,
                                "description": "Safe reviewer reference for fresh apply only."},
            },
            "required": ["archive_root", "mode", "client_app_ref", "task_route_ref"],
            "allOf": [
                {"if": {"properties": {"mode": {"enum": ["preview", "apply"]}}},
                 "then": {"required": ["work_session_ref", "manifest"]},
                 "else": {"not": {"required": ["manifest"]}}},
                {"if": {"properties": {"mode": {"const": "apply"}}},
                 "then": {"required": ["reviewed_by"]},
                 "else": {"not": {"required": ["reviewed_by"]}}},
            ],
        },
    },
    {
        "name": "zet_title_remap_write",
        "description": (
            "Preview or apply local title recovery in the explicit app/task session with native human approval. "
            "Fresh modes require source_mirror and work_session_ref; apply requires reviewed_by. "
            "Resume or explicit review_original takes only retained app/task references and never replacement source evidence, "
            "reviewer, approval identifiers or hashes. Existing approval resumes without a new dialog. "
            "This verifies changed fields and index completion, not whole-document Git ownership."
        ),
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": False},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string", "minLength": 1},
                "mode": {"type": "string", "enum": ["preview", "apply", "resume", "review_original"]},
                "client_app_ref": {"type": "string", "minLength": 1},
                "task_route_ref": {"type": "string", "minLength": 1},
                "work_session_ref": {"type": "string", "minLength": 1},
                "source_mirror": {"type": "string", "minLength": 1},
                "reviewed_by": {"type": "string", "minLength": 1},
                "max_items": {"type": "integer", "minimum": 1, "maximum": 5000},
                "expected_identifier_title_count": {"type": "integer", "minimum": 0},
            },
            "required": ["archive_root", "mode", "client_app_ref", "task_route_ref"],
            "allOf": [
                {"if": {"properties": {"mode": {"enum": ["preview", "apply"]}}},
                 "then": {"required": ["source_mirror", "work_session_ref"]},
                 "else": {"not": {"anyOf": [{"required": ["source_mirror"]}, {"required": ["max_items"]},
                                               {"required": ["expected_identifier_title_count"]}]}}},
                {"if": {"properties": {"mode": {"const": "apply"}}},
                 "then": {"required": ["reviewed_by"]},
                 "else": {"not": {"required": ["reviewed_by"]}}},
            ],
        },
    },
    {
        "name": "source_intake_record",
        "description": (
            "Record one redacted source-intake plan using its explicit app/task session and native exact approval. "
            "This preserves metadata only, not source bytes, and creates no capture request. "
            "Resume selects the original approval using only app/task references; omit plan, reviewer, hashes and approval IDs. "
            "Explicit review_original may reopen only the retained original whose claim was never published; "
            "normal resume never opens a new approval dialog."
        ),
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": False},
        "inputSchema": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "archive_root": {"type": "string"},
                "mode": {"type": "string", "enum": ["preview", "apply", "resume", "review_original"]},
                "client_app_ref": {"type": "string"}, "task_route_ref": {"type": "string"},
                "work_session_ref": {"type": "string"},
                "source_intake_plan": {"type": "string", "description": "Existing redacted plan JSON path; omitted on original resume."},
                "reviewed_by": {"type": "string", "description": "Safe reviewer reference for fresh apply only."},
            },
            "required": ["archive_root", "mode", "client_app_ref", "task_route_ref"],
        },
    },
    {
        "name": "source_intake_plan",
        "description": "Plan safe source/objet references before draft creation. Read-only metadata-only dry-run; never reads file bodies, hashes, copies, uploads, imports, OCRs, transcribes, or calls provider APIs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "dry_run": {"type": "boolean", "default": True},
                "local_path": {"type": "string"},
                "source": {"type": "string"},
                "item_id": {"type": "string"},
                "relative_path": {"type": "string"},
                "objet_ref": {"type": "string"},
                "object_id": {"type": "string"},
                "provider": {"type": "string"},
                "provider_object_id": {"type": "string"},
                "provider_kind": {"type": "string"},
                "ai_artifact_ref": {"type": "string"},
                "runtime": {"type": "string", "enum": sorted(archive_services.SOURCE_INTAKE_RUNTIMES)},
                "artifact_kind": {"type": "string"},
                "expected_archive_id": {"type": "string"},
                "expected_type": {"type": "string"},
                "profile_id": {"type": "string"},
                "source_role": {"type": "string", "enum": sorted(archive_services.SOURCE_INTAKE_ROLES)},
                "title": {"type": "string"},
                "mime": {"type": "string"},
                "redact_local_paths": {"type": "boolean", "default": True},
                "project_intake_receipt": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "tiro_import_plan",
        "description": "Plan a Tiro meeting transcript and audio-objet import from an archive-internal manifest. Dry-run only; never calls Tiro, reads audio bytes, echoes transcript text, writes derived text, drafts, or mints.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string", "description": "Path to the archive root."},
                "manifest": {"type": "string", "description": "Archive-relative Tiro manifest JSON path."},
                "source": {"type": "string", "enum": [archive_services.TIRO_IMPORT_SOURCE], "default": archive_services.TIRO_IMPORT_SOURCE},
                "max_segments": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.TIRO_IMPORT_MAX_SEGMENTS,
                    "default": 1000,
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "manifest"],
        },
    },
    {
        "name": "archive_init",
        "description": f"Preview archive initialization only. Real initialization is unavailable in v{__version__} pending exact compound human approval.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "archive_type": {"type": "string", "enum": ["personal", "company", "family"]},
                "archive_id": {"type": "string"},
                "principal_id": {"type": "string"},
                "principal_name": {"type": "string"},
                "principal_kind": {
                    "type": "string",
                    "enum": ["person", "family", "household", "child", "company", "team", "project", "role", "client"],
                    "default": "person",
                },
                "name": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "archive_type", "archive_id", "principal_id"],
        },
    },
    {
        "name": "archive_onboarding_plan",
        "description": "Plan beginner-friendly Docker-first archive onboarding. This never creates folders or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "target_root": {"type": "string"},
                "archive_type": {"type": "string", "enum": ["personal", "company", "family"]},
                "archive_id": {"type": "string"},
                "principal_id": {"type": "string"},
                "principal_name": {"type": "string"},
                "principal_kind": {
                    "type": "string",
                    "enum": ["person", "family", "household", "child", "company", "team", "project", "role", "client"],
                },
                "name": {"type": "string"},
                "provider_profile": {
                    "type": "string",
                    "enum": sorted(archive_services.ONBOARDING_PROVIDER_PROFILES),
                    "default": "local_only",
                },
            },
            "required": ["target_root", "archive_type", "archive_id", "principal_id"],
        },
    },
    {
        "name": "real_pilot_plan",
        "description": "Plan a safe first real personal/team archive pilot. This never creates folders, scans files, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "personal_root": {"type": "string"},
                "team_root": {"type": "string"},
                "personal_archive_id": {"type": "string", "default": "archive:personal:life"},
                "personal_principal_id": {"type": "string", "default": "person:me"},
                "personal_principal_name": {"type": "string"},
                "team_archive_id": {"type": "string", "default": "archive:company:founding-team"},
                "team_principal_id": {"type": "string", "default": "team:founding-team"},
                "team_principal_name": {"type": "string"},
                "personal_provider_profile": {
                    "type": "string",
                    "enum": sorted(archive_services.ONBOARDING_PROVIDER_PROFILES),
                    "default": "object_storage_planned",
                },
                "team_provider_profile": {
                    "type": "string",
                    "enum": sorted(archive_services.ONBOARDING_PROVIDER_PROFILES),
                    "default": "full_provider_plan",
                },
            },
            "required": ["personal_root", "team_root"],
        },
    },
    {
        "name": "archive_preflight_check",
        "description": "Check archive safety before connecting real personal or team data. This is read-only.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "peer_archive": {"type": "string"},
                "require_source_maps": {"type": "boolean", "default": False},
                "require_restore_drill": {"type": "boolean", "default": False},
                "strict": {"type": "boolean", "default": False},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "recovery_plan",
        "description": "Show local backup and restore readiness. This never writes files or calls external APIs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"}
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "restore_drill_plan",
        "description": "Plan a local restore drill. This never creates the restore target or writes receipts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "target": {"type": "string"}
            },
            "required": ["archive_root", "target"],
        },
    },
    {
        "name": "external_import_plan",
        "description": "Plan a Notion or Google Drive export import. This never writes archive files or calls external APIs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.EXTERNAL_IMPORT_SOURCES)},
                "export_path": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 200},
            },
            "required": ["archive_root", "source", "export_path"],
        },
    },
    {
        "name": "connection_import_plan",
        "description": "Plan Notion connection evidence import into WOM typed-edge candidates, including containment-to-contains mapping and model-gap escalation. Dry-run only; never calls Notion, reads exports, writes zets, or writes edges.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.CONNECTION_IMPORT_SOURCES)},
                "connection_kind": {
                    "type": "string",
                    "enum": ["all"] + sorted(archive_services.CONNECTION_IMPORT_KINDS),
                    "default": "all",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source"],
        },
    },
    {
        "name": "connection_evidence_parser_contract",
        "description": "Preview the dry-run-only contract a future Notion connection evidence parser must satisfy. It never reads exports, parses files, writes candidates, or writes edges.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.CONNECTION_IMPORT_SOURCES)},
                "connection_kind": {
                    "type": "string",
                    "enum": ["all"] + sorted(archive_services.CONNECTION_IMPORT_KINDS),
                    "default": "all",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source"],
        },
    },
    {
        "name": "connection_evidence_parse_fixture",
        "description": "Parse a sanitized archive-internal Notion connection evidence fixture into candidate edge previews. Dry-run only; never reads real exports or writes candidates/edges.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "evidence": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.CONNECTION_IMPORT_SOURCES)},
                "connection_kind": {
                    "type": "string",
                    "enum": ["all"] + sorted(archive_services.CONNECTION_IMPORT_KINDS),
                    "default": "all",
                },
                "max_items": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 100},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "evidence", "source"],
        },
    },
    {
        "name": "notion_nested_tree_plan",
        "description": "Plan nested Notion child-page recovery from a sanitized tree fixture with generation assignment, content/structure classification, and untraceable reporting. Dry-run only; never reads real exports, page titles, bodies, or writes zets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": 1000},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "tree", "source"],
        },
    },
    {
        "name": "notion_ancestor_crawl_plan",
        "description": "Plan missing Notion ancestor crawl requests from a sanitized nested tree fixture. Dry-run only; never calls providers, reads titles or bodies, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": 1000},
                "max_depth": {"type": "integer", "minimum": 1, "maximum": 64, "default": 16},
                "scope_generation_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_root_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_ancestor_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_leaf_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "tree", "source"],
        },
    },
    {
        "name": "notion_ancestor_fetch_adapter_execution_contract",
        "description": "Preview the read-only execution and actor contract a future credential-bounded Notion ancestor fetch adapter must satisfy. The AI chat runtime is not the live fetch subject, and client fixture supply is only a sanitized fallback input. Never calls providers, retrieves secrets, reads titles or bodies, downloads media, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "credential_ref": {"type": "string"},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": 1000},
                "max_depth": {"type": "integer", "minimum": 1, "maximum": 64, "default": 16},
                "scope_generation_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_root_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_ancestor_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_leaf_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "tree", "source"],
        },
    },
    {
        "name": "notion_media_fetch_adapter_execution_contract",
        "description": "Preview the read-only execution and actor contract a future credential-bounded Notion media byte fetch adapter must satisfy for nested leaf media preservation. Never calls providers, retrieves secrets, refreshes signed URLs, downloads media bytes, hashes bytes, or writes manifests.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "credential_ref": {"type": "string"},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": 1000},
                "scope_generation_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_root_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "scope_leaf_refs": {"type": "array", "items": {"type": "string"}, "default": []},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "tree", "source"],
        },
    },
    {
        "name": "notion_media_result_verification_plan",
        "description": "Verify a sanitized Notion media result fixture against object manifests. Read-only; never calls providers, refreshes signed URLs, downloads media bytes, hashes bytes, or writes manifests.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "media_result": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": 1000},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "media_result", "source"],
        },
    },
    {
        "name": "notion_block_mirror_tree_fixture_plan",
        "description": "Build a sanitized nested tree fixture preview from reviewed Notion block mirror metadata. Dry-run only; never calls providers, reads titles or bodies, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "mirror": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "mirror", "source"],
        },
    },
    {
        "name": "notion_ancestor_merge_plan",
        "description": "Merge sanitized ancestor result nodes into a nested tree fixture preview and replan. Dry-run only; never calls providers, reads titles or bodies, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "ancestors": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "tree", "ancestors", "source"],
        },
    },
    {
        "name": "notion_client_issue_verification_plan",
        "description": "Verify a client Notion nested-tree issue from sanitized local fixtures. Dry-run only; never calls providers, reads titles or bodies, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "mirror": {"type": "string"},
                "ancestors": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT},
                "max_depth": {"type": "integer", "minimum": 1, "maximum": 64, "default": 16},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source"],
        },
    },
    {
        "name": "notion_client_fixture_request_plan",
        "description": "Package the sanitized fixture request contract for client Notion issue verification. Dry-run only; never sends messages, calls providers, reads titles or bodies, or writes fixtures.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "tree": {"type": "string"},
                "mirror": {"type": "string"},
                "ancestors": {"type": "string"},
                "source": {"type": "string", "enum": sorted(archive_services.NOTION_NESTED_TREE_SOURCES)},
                "scenario": {"type": "string", "enum": ["missing_ancestor", "nested_tree", "block_mirror", "ancestor_merge"], "default": "missing_ancestor"},
                "max_items": {"type": "integer", "minimum": 1, "maximum": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT, "default": archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT},
                "max_depth": {"type": "integer", "minimum": 1, "maximum": 64, "default": 16},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "source"],
        },
    },
    {
        "name": "list_sources",
        "description": "List registered source bindings and current source map status.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "source_scan_plan",
        "description": "Plan a metadata-only source scan. This never writes source maps or receipts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source": {"type": "string"},
                "source_root": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 10000, "default": 2000},
            },
            "required": ["archive_root", "source"],
        },
    },
    {
        "name": "source_registration_plan",
        "description": "Plan source registration. This never writes source-bindings.yml or local profiles.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source_id": {"type": "string"},
                "source_type": {"type": "string", "enum": sorted(archive_services.SOURCE_TYPES)},
                "description": {"type": "string"},
                "root_ref": {"type": "string"},
                "local_root": {"type": "string"},
                "write_local_profile": {"type": "boolean", "default": False},
                "include": {"type": "array", "items": {"type": "string"}},
                "exclude": {"type": "array", "items": {"type": "string"}},
                "max_items": {"type": "integer", "minimum": 1, "maximum": 10000, "default": 2000},
                "visibility_scope": {"type": "string", "default": "private"},
                "source_visibility": {"type": "string", "default": "private"},
                "replace": {"type": "boolean", "default": False},
            },
            "required": ["archive_root", "source_id", "source_type"],
        },
    },
    {
        "name": "source_mount_plan",
        "description": "Show host-native and Docker mount guidance for registered sources. This never changes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "list_zettels",
        "description": "List draft and/or canonical zettels with basic frontmatter metadata.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "status": {"type": "string", "enum": ["all", "draft", "canonical"], "default": "canonical"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "zet_catalog",
        "description": "Enumerate every selected local zet's available abstract state and frontmatter connections in deterministic pages. Use projection=reading and coverage_mode=strict for compact contiguous zet coverage; after the required full first page, response_profile=continuation may omit repeated diagnostics while retaining items, coverage, snapshot, and continuation proof. Use routed_reading only with seeded_connection_walk when per-item connection-order reasons are worth the extra tokens. Inspect item and compact service-result envelope estimates, with an optional explicit envelope reserve, plus separate abstract-reading and id-followup readiness. Read-only; never reads zet bodies or requires a generated index.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "status": {"type": "string", "enum": ["all", "draft", "canonical"], "default": "canonical"},
                "projection": {
                    "type": "string",
                    "enum": ["full", "reading", "routed_reading"],
                    "default": "full",
                },
                "coverage_mode": {"type": "string", "enum": ["page", "strict"], "default": "page"},
                "order": {
                    "type": "string",
                    "enum": ["path", "seeded_connection_walk"],
                    "default": "path",
                },
                "start_zettel_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "maxItems": archive_services.ZET_CATALOG_MAX_SEED_IDS,
                },
                "cursor": {"type": "integer", "minimum": 0, "default": 0},
                "page_size": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 200},
                "max_estimated_tokens": {
                    "type": "integer",
                    "minimum": 1,
                    "description": "Optional approximate items-only token budget for one page; at least one item is returned to preserve progress.",
                },
                "response_envelope_reserve_tokens": {
                    "type": "integer",
                    "minimum": 0,
                    "default": 0,
                    "description": "Optional tokens reserved from max_estimated_tokens for non-item compact service-result fields.",
                },
                "response_profile": {
                    "type": "string",
                    "enum": ["full", "continuation"],
                    "default": "full",
                    "description": "Use continuation only after the first strict page to omit repeated diagnostics without changing items or continuation proof.",
                },
                "expected_snapshot_id": {"type": "string"},
                "continuation_token": {"type": "string", "maxLength": 4096},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "first_read_readiness",
        "description": "Check whether every canonical zet has an explicit compact first read and a uniquely resolvable safe id. Frontmatter-only and read-only; does not return abstract text, read bodies, inspect objets, call providers, or access secrets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "max_items": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "abstract_freshness",
        "description": "Compare canonical abstract/body hash pairs with retained human-review evidence. Read-only and text-free: returns no abstract, body, title, hash, receipt path, reviewer id, provider URL, or secret value.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "max_items": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.ABSTRACT_FRESHNESS_MAX_ATTENTION_ITEMS,
                    "default": 100,
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "zet_revision_plan",
        "description": "Validate one private full-zet revision proposal against the current canonical zet. Read-only and content-free: writes nothing and returns no zet id, path, title, abstract, body, custom frontmatter value, provider URL, reviewer id, or secret value.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string", "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]*$"},
                "proposal_path": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "zettel_id", "proposal_path"],
        },
    },
    {
        "name": "read_zettel",
        "description": "Read one zettel by zettel id or archive-relative path. Use section=overview for the compact first read; large bodies can be read in hash-bound bounded pages without changing the default full-body response.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "section": {
                    "type": "string",
                    "enum": sorted(archive_services.ZETTEL_READ_SECTIONS),
                    "default": "body",
                },
                "body_cursor": {
                    "type": "integer",
                    "minimum": 0,
                    "default": 0,
                    "description": "Unicode code-point offset. A nonzero cursor requires expected_body_sha256 from the first page.",
                },
                "body_max_chars": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.ZETTEL_READ_BODY_MAX_CHARS,
                    "description": "Maximum body code points returned in this bounded page.",
                },
                "expected_body_sha256": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                    "description": "Complete decoded-body hash from the first page; required for every nonzero continuation cursor.",
                },
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "zettel_objet_links",
        "description": "Preview safe local-client objet link candidates referenced by one zettel. Read-only; never echoes body text, frontmatter values, absolute paths, provider URLs, presigned URLs, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_refs": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "zettel_objet_link_receipts",
        "description": (
            "Find internally validated immutable receipts for current structured "
            "Zettel-Objet links. Read-only; returns only safe ids, roles, "
            "archive-relative receipt paths, and lifecycle states. Never "
            "returns labels, zettel content, object bytes, provider data, or "
            "absolute paths."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "object_id": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                },
                "role": {
                    "type": "string",
                    "pattern": "^[a-z][a-z0-9_]{0,79}$",
                },
                "dry_run": {"type": "boolean", "default": True},
                "max_receipts": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 100,
                },
            },
            "required": ["archive_root"],
            "oneOf": [
                {"required": ["zettel_id"], "not": {"required": ["path"]}},
                {"required": ["path"], "not": {"required": ["zettel_id"]}},
            ],
        },
    },
    {
        "name": "facet_vocabulary",
        "description": (
            "List the base and archive-local stable facet key vocabulary and "
            "role classifications without reading facet values or zettel bodies."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "view_health",
        "description": "Diagnose saved view hit counts, facet distributions, and navigation/internal facet roles without reading zettel bodies or writing files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_values": {"type": "integer", "minimum": 1, "maximum": 50, "default": 10},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "view_recommendation_plan",
        "description": "Plan saved view recommendations from navigation facet distributions without reading zettel bodies or writing view files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_values": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
                "max_recommendations": {"type": "integer", "minimum": 1, "maximum": 100, "default": 12},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "index_health",
        "description": "Check whether the generated local SQLite index matches live zettel paths and basic frontmatter metadata. Read-only; writes nothing.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_items": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "notion_objet_link_plan",
        "description": "Plan Notion provider locator to manifested objet link candidates for one zettel. Read-only; never echoes provider URLs, body text, frontmatter values, absolute paths, presigned URLs, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_locators": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
                "max_candidates": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "notion_objet_link_index",
        "description": "Index Notion provider locator to manifested objet link candidates across zettels. Read-only; never echoes provider URLs, body text, frontmatter values, absolute paths, presigned URLs, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
                "max_zettels": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
                "max_locators_per_zettel": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
                "max_candidates": {"type": "integer", "minimum": 1, "maximum": 50, "default": 5},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "notion_objet_source_map_link_plan",
        "description": "Plan zettel-to-objet material link candidates from source maps and optional download ledgers when body provider locators were removed. Read-only; never echoes provider URLs, page titles, body text, frontmatter values, absolute paths, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source_maps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Archive-relative source-map JSON/JSONL/YAML files. Defaults to source-maps/*.jsonl.",
                },
                "ledgers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Archive-relative download/retrieval ledger JSON/JSONL/YAML files.",
                },
                "dry_run": {"type": "boolean", "default": True},
                "max_rows": {"type": "integer", "minimum": 1, "maximum": 100000, "default": 10000},
                "max_candidates": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 200},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "notion_objet_import_clue_audit",
        "description": "Audit imported Notion zettels for preserved material clues after provider locator omission. Read-only; never reads zettel bodies, echoes provider URLs, page titles, frontmatter values, absolute paths, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "source_maps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Archive-relative source-map JSON/JSONL/YAML files. Defaults to source-maps/*.jsonl.",
                },
                "ledgers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Archive-relative download/retrieval ledger JSON/JSONL/YAML files.",
                },
                "dry_run": {"type": "boolean", "default": True},
                "max_rows": {"type": "integer", "minimum": 1, "maximum": 100000, "default": 10000},
                "max_zettels": {"type": "integer", "minimum": 1, "maximum": 5000, "default": 500},
                "max_candidates": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 1000},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "notion_objet_link_rewrite_plan",
        "description": "Validate one reviewed Notion locator to objet conversion plan before any approval-gated rewrite or embed edge write. Read-only; never echoes provider URLs, body text, page titles, absolute paths, object bytes, or writes files.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "locator_fingerprint": {"type": "string"},
                "object_id": {"type": "string"},
                "target_mode": {
                    "type": "string",
                    "enum": ["objet_ref_rewrite", "embed_edge"],
                    "default": "objet_ref_rewrite",
                },
                "expected_occurrence_count": {"type": "integer", "minimum": 1},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "locator_fingerprint", "object_id"],
        },
    },
    {
        "name": "block_header_check",
        "description": "Dry-run preview of the derived block header for one draft or canonical zet.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "zet_projection_plan_check",
        "description": "Read-only dry-run ZET publication/projection plan preview for one local zet. Never publishes, writes receipts, calls providers, or transports.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zet": {"type": "string"},
                "surface": {"type": "string", "enum": sorted(archive_services.ZET_PROJECTION_SURFACE_KINDS)},
                "visibility": {
                    "type": "string",
                    "enum": sorted(archive_services.ZET_PROJECTION_VISIBILITIES),
                    "default": "unknown",
                },
                "projection_format": {
                    "type": "string",
                    "enum": sorted(archive_services.ZET_PROJECTION_FORMATS),
                    "default": "metadata_only",
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "zet", "surface"],
        },
    },
    {
        "name": "zet_shared_update_record_review_preview",
        "description": "Read-only dry-run review preview for one local ZET shared update record before any renewal action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "record": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "record"],
        },
    },
    {
        "name": "zet_shared_update_record_review_index",
        "description": "Read-only dry-run index over local archive-contained ZET shared update records before any renewal action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "records_dir": {"type": "string"},
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.ZET_SHARED_UPDATE_REVIEW_INDEX_MAX_LIMIT,
                    "default": archive_services.ZET_SHARED_UPDATE_REVIEW_INDEX_MAX_LIMIT,
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "records_dir"],
        },
    },
    {
        "name": "zet_transport_would_plan",
        "description": "Read-only dry-run ZET would-transport plan for one local shared update record. This never transports, creates keys, writes receipts, calls providers, or starts workers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "record": {"type": "string"},
                "method": {"type": "string", "enum": sorted(archive_services.ZET_TRANSPORT_METHODS)},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "record", "method"],
        },
    },
    {
        "name": "foreign_block_intake_check",
        "description": "Read-only dry-run intake preview for a foreign/shared block or Markdown-compatible zet before any trust/import action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "content": {"type": "object"},
                "text": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_trust_check",
        "description": "Read-only dry-run trust/attestation eligibility preview from a foreign-block intake report.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "intake_report": {"type": "object"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_attestation_packet_check",
        "description": "Read-only dry-run human-review attestation packet preview from a foreign-block trust report.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "trust_report": {"type": "object"},
                "prospective_attestor": {"type": "string"},
                "review_scope": {"type": "string", "enum": ["human_review", "policy_review", "operator_review"]},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_quarantine_plan",
        "description": "Read-only dry-run quarantine placement plan from a foreign-block attestation packet preview.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "attestation_packet": {"type": "object"},
                "quarantine_case_id": {"type": "string"},
                "reviewer": {"type": "string"},
                "quarantine_policy": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_QUARANTINE_POLICIES),
                },
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "quarantine_foreign_block_check",
        "description": "Read-only dry-run check for an approved CLI-only foreign block quarantine write.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "quarantine_plan": {"type": "object"},
                "expected_case_id": {"type": "string"},
                "reviewed_by": {"type": "string"},
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_quarantine_review_index",
        "description": "Read-only inventory and consistency check for existing foreign block quarantine cases.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "status": {"type": "string", "enum": ["written_untrusted", "all"], "default": "written_untrusted"},
                "include_receipts": {"type": "boolean", "default": False},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_quarantine_decision_check",
        "description": "Read-only decision-path preview for one existing foreign block quarantine case.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "decision_intent": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_QUARANTINE_DECISION_INTENTS),
                    "default": "auto",
                },
                "reviewer": {"type": "string"},
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "case_id"],
        },
    },
    {
        "name": "record_quarantine_decision_check",
        "description": "Read-only dry-run check for a CLI-only foreign block quarantine decision record write.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "decision_preview": {"type": "object"},
                "expected_case_id": {"type": "string"},
                "expected_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_QUARANTINE_DECISIONS),
                },
                "reviewed_by": {"type": "string"},
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_quarantine_decision_review_index",
        "description": "Read-only inventory and consistency check for recorded foreign block quarantine decisions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "decision": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_QUARANTINE_DECISIONS | {"all"}),
                    "default": "all",
                },
                "include_receipts": {"type": "boolean", "default": False},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_decision_outcome_plan",
        "description": "Read-only outcome planner for one recorded foreign block quarantine decision.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "expected_decision": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_QUARANTINE_DECISIONS),
                },
                "reviewer": {"type": "string"},
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "case_id"],
        },
    },
    {
        "name": "foreign_block_attestation_review_candidate_plan",
        "description": "Read-only candidate planner for human attestation review from an eligible foreign block quarantine decision.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "expected_decision": {
                    "type": "string",
                    "enum": [archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_DECISION],
                },
                "expected_outcome": {
                    "type": "string",
                    "enum": [archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_OUTCOME],
                },
                "prospective_attestor": {"type": "string"},
                "review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES),
                    "default": "full_human_review",
                },
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "case_id"],
        },
    },
    {
        "name": "record_attestation_review_candidate_check",
        "description": "Read-only dry-run check for a CLI-only foreign block attestation review candidate record write.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "candidate_plan": {"type": "object"},
                "expected_case_id": {"type": "string"},
                "expected_review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES),
                },
                "expected_attestor": {"type": "string"},
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_attestation_review_candidate_index",
        "description": "Read-only index and consistency check for recorded foreign block attestation review candidates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES | {"all"}),
                    "default": "all",
                },
                "include_receipts": {"type": "boolean", "default": False},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_attestation_statement_draft_preview",
        "description": "Read-only non-binding attestation statement draft preview for one recorded foreign block candidate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "expected_review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES),
                },
                "prospective_attestor": {"type": "string"},
                "statement_style": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_STATEMENT_STYLES),
                    "default": "minimal",
                },
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "case_id"],
        },
    },
    {
        "name": "record_attestation_statement_draft_check",
        "description": "Read-only dry-run check for a CLI-only local attestation statement draft record write.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "path": {"type": "string"},
                "draft_preview": {"type": "object"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_attestation_statement_draft_review_index",
        "description": "Read-only index and consistency check for recorded foreign block attestation statement drafts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "statement_style": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_STATEMENT_STYLES | {"all"}),
                    "default": "all",
                },
                "review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES | {"all"}),
                    "default": "all",
                },
                "include_receipts": {"type": "boolean", "default": False},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "foreign_block_attestation_statement_draft_decision_preview",
        "description": "Read-only decision-route preview for one recorded foreign block attestation statement draft.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "case_id": {"type": "string"},
                "decision_intent": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_STATEMENT_DRAFT_DECISION_INTENTS),
                    "default": "needs_more_review",
                },
                "reviewer": {"type": "string"},
                "expected_review_scope": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_REVIEW_CANDIDATE_SCOPES),
                },
                "expected_statement_style": {
                    "type": "string",
                    "enum": sorted(archive_services.FOREIGN_BLOCK_ATTESTATION_STATEMENT_STYLES),
                },
                "review_note": {"type": "string"},
                "dry_run": {"type": "boolean", "default": True},
            },
            "required": ["archive_root", "case_id"],
        },
    },
    {
        "name": "create_draft_zettel",
        "description": (
            "Preview an AI-assisted/generated inbox draft. "
            "Dry-run returns the exact source-fidelity plan and approval replay; "
            "live writing is CLI-only because it requires the local Windows exact-human "
            "approval dialog and authenticated one-use claim. Verbatim mode may compose "
            "its body from one content-addressed "
            "source object or one approved reviewed-session evidence id. This never "
            "mints canonical memory and never accepts a mutable source path."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "title": {"type": "string"},
                "body": {
                    "type": "string",
                    "description": (
                        "Private candidate body. Required except when verbatim mode "
                        "composes the exact source region. Never echoed in tool summaries."
                    ),
                },
                "abstract": {"type": "string", "maxLength": archive_services.ZET_ABSTRACT_MAX_CHARS},
                "archive_id": {"type": "string"},
                "kind": {"type": "string", "default": "fleeting_capture"},
                "facets": {"type": "object"},
                "visibility": {"type": "object"},
                "dry_run": {
                    "type": "boolean",
                    "default": True,
                    "description": "Preview only. Exactly one of dry_run or approved must be true.",
                },
                "approved": {
                    "type": "boolean",
                    "const": False,
                    "default": False,
                    "description": (
                        "Must remain false. MCP cannot perform live exact-human "
                        "approval; use the reviewed local CLI command."
                    ),
                },
                "expected_archive_id": {"type": "string"},
                "expected_type": {"type": "string", "enum": sorted(archive_services.RUNTIME_CONTEXT_ARCHIVE_TYPES)},
                "profile_context": {"type": "object"},
                "creation_mode": {
                    "type": "string",
                    "enum": ["ai_assisted", "ai_generated"],
                    "default": "ai_assisted",
                    "description": "MCP is an AI-only authoring surface; human_written is not accepted.",
                },
                "created_by": {"type": "string"},
                "source": {"type": "string"},
                "assisted_by": {
                    "type": "array",
                    "items": {"type": "string", "const": "ai_runtime:mcp"},
                    "minItems": 1,
                    "maxItems": 1,
                    "default": ["ai_runtime:mcp"],
                    "description": (
                        "Fixed MCP authoring identity. Caller-supplied actor "
                        "spoofing is rejected."
                    ),
                },
                "supervised_by": {"type": "array", "items": {"type": "string"}},
                "derived_from": {"type": "array", "items": {"type": "string"}},
                "source_refs": {"type": "array", "items": {"type": "object"}},
                "source_intake_plan": {"type": "object"},
                "prompt_boundary_report": {"type": "object"},
                "local_ai_sessions": {"type": "array", "items": {"type": "object"}},
                "draft_id": {"type": "string"},
                "created_at": {"type": "string"},
                "expected_body_sha256": {"type": "string"},
                "draft_approved_by": {"type": "string"},
                "source_fidelity_mode": {
                    "type": "string",
                    "enum": sorted(archive_services.SOURCE_FIDELITY_MODES),
                    "description": (
                        "verbatim, faithful_summary, or sanitized_derivative; "
                        "bound into the reviewed source-fidelity plan."
                    ),
                },
                "source_fidelity_audience": {
                    "type": "string",
                    "enum": sorted(archive_services.ZET_QUALITY_AUDIENCES),
                    "description": "Intended audience bound into the source-fidelity plan.",
                },
                "fidelity_source_object_id": {
                    "type": "string",
                    "pattern": "^sha256:[0-9a-f]{64}$",
                    "description": "Immutable source object id; a local source path is never accepted.",
                },
                "fidelity_session_evidence_id": {
                    "type": "string",
                    "pattern": "^source-fidelity-session-evidence:[0-9a-f]{64}$",
                    "description": (
                        "Approved private reviewed-session evidence id. Exactly "
                        "one fidelity authority id is required."
                    ),
                },
                "expected_source_fidelity_plan_sha256": {
                    "type": "string",
                    "pattern": "^[0-9a-f]{64}$",
                    "description": "Exact plan digest from the reviewed dry-run replay.",
                },
            },
            "required": [
                "archive_root",
                "title",
                "abstract",
                "facets",
                "source_fidelity_mode",
                "source_fidelity_audience",
            ],
            "oneOf": [
                {
                    "required": ["fidelity_source_object_id"],
                    "not": {"required": ["fidelity_session_evidence_id"]},
                },
                {
                    "required": ["fidelity_session_evidence_id"],
                    "not": {"required": ["fidelity_source_object_id"]},
                },
            ],
        },
    },
    {
        "name": "list_views",
        "description": "List saved AI context views from views/*.yml.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "archive_index",
        "description": "Build a generated local SQLite search index at db/archive-index.sqlite.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "archive_search",
        "description": (
            "Search zettels, object manifest entries, derived texts, views, and source-map entries "
            "through the generated local SQLite index. Results are capped by `limit` (max 100), so "
            "check `truncated` before treating the returned rows as every match. `total_matches` is "
            "exact when `truncated` is false; when true it is null unless `count_total` is set."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "query": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
                "count_total": {
                    "type": "boolean",
                    "default": False,
                    "description": (
                        "Count every match beyond the limit. Costs a full scan of each searched "
                        "table, so leave it off when only `truncated` matters."
                    ),
                },
            },
            "required": ["archive_root", "query"],
        },
    },
    {
        "name": "objet_rediscovery_plan",
        "description": (
            "Summarize checked and unchecked objet rediscovery layers before "
            "any global absence claim. Read-only; never echoes the query, "
            "search rows, filenames, source ids, local paths, provider "
            "locators, or secret values."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "query": {
                    "type": "string",
                    "description": "Private local query; never echoed.",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": archive_services.SEARCH_LIMIT_CEILING,
                    "default": 20,
                },
                "count_total": {
                    "type": "boolean",
                    "default": False,
                    "description": (
                        "Count all generated-index matches. This cannot make "
                        "the multi-layer rediscovery result complete."
                    ),
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Required. Read-only inspection; must be true.",
                },
            },
            "required": ["archive_root", "query", "dry_run"],
        },
    },
    {
        "name": "promotion_check",
        "description": "Dry-run check whether an inbox draft zettel can be promoted. This never writes canonical memory.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "mint_zettel_check",
        "description": (
            "Dry-run check whether an inbox draft zet can be minted. Returns "
            "content-free source-fidelity evidence and the current reviewed plan "
            "digest without reflecting source text. This never writes canonical "
            "memory, receipts, or snapshots."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "zettel_id": {"type": "string"},
                "path": {"type": "string"},
            },
            "required": ["archive_root"],
        },
    },
    {
        "name": "share_check",
        "description": "Dry-run check whether a saved view can be shared with a trusted counterparty. This never writes or sends data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "view": {"type": "string"},
                "target_archive": {"type": "string"},
                "counterparty_id": {"type": "string"},
                "counterparty_fingerprint": {"type": "string"},
                "allow_sensitive": {"type": "boolean", "default": False},
            },
            "required": ["archive_root", "view", "target_archive"],
        },
    },
    {
        "name": "delegate_zet_check",
        "description": "Dry-run check whether zets from a saved view can be delegated. This never writes receipts or sends data.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "view": {"type": "string"},
                "target_archive": {"type": "string"},
                "target_policy": {"type": "string", "enum": sorted(archive_services.DELEGATE_TARGET_POLICIES)},
                "counterparty_id": {"type": "string"},
                "counterparty_fingerprint": {"type": "string"},
                "allow_sensitive": {"type": "boolean", "default": False},
            },
            "required": ["archive_root", "view"],
        },
    },
    {
        "name": "attest_zet_check",
        "description": "Dry-run check whether a delegated foreign zet receipt can be attested. This never writes receipts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "delegate_receipt": {"type": "string"},
                "counterparty_id": {"type": "string"},
                "counterparty_fingerprint": {"type": "string"},
            },
            "required": ["archive_root", "delegate_receipt"],
        },
    },
    {
        "name": "anchor_zet_check",
        "description": "Dry-run check whether an attested foreign zet can be anchored into local meaning. This never writes metadata.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "attestation_receipt": {"type": "string"},
            },
            "required": ["archive_root", "attestation_receipt"],
        },
    },
    {
        "name": "ownership_transfer_check",
        "description": "Dry-run check whether archive ownership can be transferred. This never changes owners or writes receipts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_root": {"type": "string"},
                "new_owner": {"type": "string"},
                "new_owner_kind": {"type": "string", "enum": sorted(archive_services.OWNER_KINDS)},
                "new_owner_archive": {"type": "string"},
                "operators_after": {"type": "array", "items": {"type": "string"}},
                "approved_by": {"type": "array", "items": {"type": "string"}},
                "subject": {"type": "string"},
                "counterparty_id": {"type": "string"},
                "counterparty_fingerprint": {"type": "string"},
                "reason": {"type": "string"},
            },
            "required": ["archive_root", "new_owner"],
        },
    },
]


def main() -> int:
    configure_stdio_utf8()
    server = JsonRpcMcpServer()
    return server.serve(sys.stdin, sys.stdout)


class JsonRpcMcpServer:
    def serve(self, stdin: Any, stdout: Any) -> int:
        from ._mcp_session_transport import SessionStdioTransport

        transport = SessionStdioTransport(
            self.handle_message, lambda response: self._write(stdout, response),
            jsonrpc_request_id_is_valid,
        )
        try:
            input_stream = getattr(stdin, "buffer", stdin)
            for raw_line in input_stream:
                if transport.stopped:
                    break
                if isinstance(raw_line, bytes):
                    try:
                        raw_line = raw_line.decode("utf-8", errors="strict")
                    except UnicodeDecodeError:
                        if not transport.send(error_response(None, JSONRPC_PARSE_ERROR)):
                            return 0
                        continue
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    message = json.loads(
                        line,
                        parse_constant=reject_nonstandard_json_constant,
                        parse_float=parse_finite_json_float,
                    )
                except (json.JSONDecodeError, NonFiniteJsonNumberError):
                    if not transport.send(error_response(None, JSONRPC_PARSE_ERROR)):
                        return 0
                    continue
                except Exception:
                    if not transport.send(error_response(None, JSONRPC_INTERNAL_ERROR)):
                        return 0
                    continue
                transport.dispatch(message)
                if transport.stopped:
                    return 0
        finally:
            transport.close()
        return 0

    def handle_message(self, message: Any) -> dict[str, Any] | None:
        if not isinstance(message, dict):
            return error_response(None, JSONRPC_INVALID_REQUEST)

        has_request_id = "id" in message
        request_id = message.get("id") if has_request_id else None
        method = message.get("method")

        if (
            message.get("jsonrpc") != "2.0"
            or not isinstance(method, str)
            or (has_request_id and not jsonrpc_request_id_is_valid(request_id))
        ):
            return error_response(None, JSONRPC_INVALID_REQUEST)

        if not has_request_id:
            self._handle_notification(method)
            return None

        # This bounded management lane uses MCP IDs, not the broader historical
        # JSON-RPC validator. Existing legacy/direct handlers keep their ABI.
        from ._mcp_session_transport import is_management_request
        if is_management_request(message) and type(request_id) not in (str, int):
            return error_response(None, JSONRPC_INVALID_REQUEST)

        try:
            params = message.get("params")
            if params is None:
                params = {}
            elif not isinstance(params, dict):
                raise InvalidParamsError()
            result = self._dispatch_request(method, params)
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        except ToolError:
            return {"jsonrpc": "2.0", "id": request_id, "result": tool_error_result()}
        except InvalidParamsError:
            return error_response(request_id, JSONRPC_INVALID_PARAMS)
        except MethodNotFoundError:
            return error_response(request_id, JSONRPC_METHOD_NOT_FOUND)
        except Exception:  # pragma: no cover - defensive protocol boundary.
            if method == "tools/call":
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": tool_error_result(),
                }
            return error_response(request_id, JSONRPC_INTERNAL_ERROR)

    def _handle_notification(self, method: str) -> None:
        return None

    def _dispatch_request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        if method == "initialize":
            return handle_initialize(params)
        if method == "ping":
            return {}
        if method == "tools/list":
            return {"tools": TOOL_DEFINITIONS}
        if method == "tools/call":
            return handle_tools_call(params)
        raise MethodNotFoundError()

    def _write(self, stdout: Any, response: dict[str, Any]) -> bool:
        try:
            serialized = json.dumps(
                response,
                ensure_ascii=True,
                allow_nan=False,
                separators=(",", ":"),
            )
        except Exception:
            request_id = response.get("id") if isinstance(response, dict) else None
            if not jsonrpc_request_id_is_valid(request_id):
                request_id = None
            result = response.get("result") if isinstance(response, dict) else None
            if (
                isinstance(result, dict)
                and {"content", "structuredContent", "isError"}.issubset(result)
            ):
                replacement = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": tool_error_result(),
                }
            else:
                replacement = error_response(request_id, JSONRPC_INTERNAL_ERROR)
            serialized = json.dumps(
                replacement,
                ensure_ascii=True,
                allow_nan=False,
                separators=(",", ":"),
            )
        try:
            stdout.write(serialized + "\n")
            stdout.flush()
        except Exception:
            neutralize_failed_stdout(stdout)
            return False
        return True


def handle_initialize(params: dict[str, Any]) -> dict[str, Any]:
    requested = params.get("protocolVersion")
    protocol_version = requested if requested in SUPPORTED_PROTOCOL_VERSIONS else SUPPORTED_PROTOCOL_VERSIONS[0]
    return {
        "protocolVersion": protocol_version,
        "capabilities": {
            "tools": {"listChanged": False},
        },
        "serverInfo": {
            "name": SERVER_NAME,
            "version": __version__,
        },
    }


def handle_tools_call(params: dict[str, Any]) -> dict[str, Any]:
    name = params.get("name")
    if not isinstance(name, str):
        raise InvalidParamsError("tools/call params.name must be a string.")
    arguments = params.get("arguments")
    if arguments is None:
        arguments = {}
    elif not isinstance(arguments, dict):
        raise InvalidParamsError("tools/call params.arguments must be an object.")

    if name == "archive_work_session":
        return tool_archive_work_session(arguments)
    if name == "archive_work_session_manage":
        from ._mcp_session_transport import management_metadata
        if not management_metadata(params)[0]:
            raise InvalidParamsError()
        return tool_archive_work_session_manage(arguments)
    if name == "wom_profile_list":
        return tool_wom_profile_list(arguments)
    if name == "wom_profile_resolve":
        return tool_wom_profile_resolve(arguments)
    if name == "wom_profile_wallet_check":
        return tool_wom_profile_wallet_check(arguments)
    if name == "archive_doctor":
        return tool_archive_doctor(arguments)
    if name == "archive_runtime_context":
        return tool_archive_runtime_context(arguments)
    if name == "archive_capabilities":
        return tool_archive_capabilities(arguments)
    if name == "prompt_boundary_check":
        return tool_prompt_boundary_check(arguments)
    if name == "github_repository_setup_plan":
        return tool_github_repository_setup_plan(arguments)
    if name == "object_storage_setup_plan":
        return tool_object_storage_setup_plan(arguments)
    if name == "provider_setup_status":
        return tool_provider_setup_status(arguments)
    if name == "object_storage_adapter_readiness_plan":
        return tool_object_storage_adapter_readiness_plan(arguments)
    if name == "object_storage_operation_request_plan":
        return tool_object_storage_operation_request_plan(arguments)
    if name == "object_storage_adapter_execution_contract":
        return tool_object_storage_adapter_execution_contract(arguments)
    if name == "object_storage_upload_plan":
        return tool_object_storage_upload_plan(arguments)
    if name == "object_storage_upload_verify":
        return tool_object_storage_upload_verify(arguments)
    if name == "human_artifact_store_plan":
        return tool_human_artifact_store_plan(arguments)
    if name == "human_artifact_root_registration_plan":
        return tool_human_artifact_root_registration_plan(arguments)
    if name == "human_artifact_registry_scan":
        return tool_human_artifact_registry_scan(arguments)
    if name == "human_artifact_transition_plan":
        return tool_human_artifact_transition_plan(arguments)
    if name == "duplicate_object_reconciliation_plan":
        return tool_duplicate_object_reconciliation_plan(arguments)
    if name == "approval_integrity_audit":
        return tool_approval_integrity_audit(arguments)
    if name == "approval_integrity_guard":
        return tool_approval_integrity_guard(arguments)
    if name == "approval_integrity_overlay_plan":
        return tool_approval_integrity_overlay_plan(arguments)
    if name == "imap_mailbox_plan":
        return tool_imap_mailbox_plan(arguments)
    if name == "imap_mailbox_operation_request_plan":
        return tool_imap_mailbox_operation_request_plan(arguments)
    if name == "imap_mailbox_adapter_readiness_plan":
        return tool_imap_mailbox_adapter_readiness_plan(arguments)
    if name == "imap_mailbox_selection_plan":
        return tool_imap_mailbox_selection_plan(arguments)
    if name == "imap_mailbox_adapter_audit_plan":
        return tool_imap_mailbox_adapter_audit_plan(arguments)
    if name == "imap_mailbox_adapter_manifest_plan":
        return tool_imap_mailbox_adapter_manifest_plan(arguments)
    if name == "imap_mailbox_adapter_preflight_plan":
        return tool_imap_mailbox_adapter_preflight_plan(arguments)
    if name == "credential_ref_plan":
        return tool_credential_ref_plan(arguments)
    if name == "credential_ref_inventory":
        return tool_credential_ref_inventory(arguments)
    if name == "credential_store_recommendation":
        return tool_credential_store_recommendation(arguments)
    if name == "credential_vault_onboarding_plan":
        return tool_credential_vault_onboarding_plan(arguments)
    if name == "credential_plaintext_migration_plan":
        return tool_credential_plaintext_migration_plan(arguments)
    if name == "credential_policy_check":
        return tool_credential_policy_check(arguments)
    if name == "credential_keepassxc_command_plan":
        return tool_credential_keepassxc_command_plan(arguments)
    if name == "credential_access_broker_plan":
        return tool_credential_access_broker_plan(arguments)
    if name == "credential_access_approval_plan":
        return tool_credential_access_approval_plan(arguments)
    if name == "credential_adapter_readiness_plan":
        return tool_credential_adapter_readiness_plan(arguments)
    if name == "credential_adapter_manifest_plan":
        return tool_credential_adapter_manifest_plan(arguments)
    if name == "credential_adapter_audit_plan":
        return tool_credential_adapter_audit_plan(arguments)
    if name == "zet_surface_prototype_plan":
        return tool_zet_surface_prototype_plan(arguments)
    if name == "prehashed_objet_ledger_preview":
        return tool_prehashed_objet_ledger_preview(arguments)
    if name == "resolve_objet_ref":
        return tool_resolve_objet_ref(arguments)
    if name == "presigned_url_plan":
        return tool_presigned_url_plan(arguments)
    if name == "project_intake_plan":
        return tool_project_intake_plan(arguments)
    if name == "project_intake_unpack_queue":
        return tool_project_intake_unpack_queue(arguments)
    if name == "project_intake_unpack_choice":
        return tool_project_intake_unpack_choice(arguments)
    if name == "project_intake_staging_guide":
        return tool_project_intake_staging_guide(arguments)
    if name == "project_intake_session_guide":
        return tool_project_intake_session_guide(arguments)
    if name == "project_intake_status":
        return tool_project_intake_status(arguments)
    if name == "project_intake_next_question":
        return tool_project_intake_next_question(arguments)
    if name == "project_intake_decision_template":
        return tool_project_intake_decision_template(arguments)
    if name == "project_intake_item_plan":
        return tool_project_intake_item_plan(arguments)
    if name == "source_intake_plan":
        return tool_source_intake_plan(arguments)
    if name == "source_intake_record":
        from ._mcp_session_transport import management_metadata
        if not management_metadata(params)[0]:
            raise InvalidParamsError()
        return tool_source_intake_record(arguments)
    if name == "zet_title_remap_write":
        from ._mcp_session_transport import management_metadata
        if not management_metadata(params)[0]:
            raise InvalidParamsError()
        return tool_zet_title_remap_write(arguments)
    if name == "source_intake_batch":
        from ._mcp_session_transport import management_metadata
        if not management_metadata(params)[0]:
            raise InvalidParamsError()
        return tool_source_intake_batch(arguments)
    if name == "git_backup_reconcile_plan":
        from ._mcp_session_transport import management_metadata
        if not management_metadata(params)[0]:
            raise InvalidParamsError()
        return tool_git_backup_reconcile_plan(arguments)
    if name == "tiro_import_plan":
        return tool_tiro_import_plan(arguments)
    if name == "archive_init":
        return tool_archive_init(arguments)
    if name == "archive_onboarding_plan":
        return tool_archive_onboarding_plan(arguments)
    if name == "real_pilot_plan":
        return tool_real_pilot_plan(arguments)
    if name == "archive_preflight_check":
        return tool_archive_preflight_check(arguments)
    if name == "recovery_plan":
        return tool_recovery_plan(arguments)
    if name == "restore_drill_plan":
        return tool_restore_drill_plan(arguments)
    if name == "external_import_plan":
        return tool_external_import_plan(arguments)
    if name == "connection_import_plan":
        return tool_connection_import_plan(arguments)
    if name == "connection_evidence_parser_contract":
        return tool_connection_evidence_parser_contract(arguments)
    if name == "connection_evidence_parse_fixture":
        return tool_connection_evidence_parse_fixture(arguments)
    if name == "notion_nested_tree_plan":
        return tool_notion_nested_tree_plan(arguments)
    if name == "notion_ancestor_crawl_plan":
        return tool_notion_ancestor_crawl_plan(arguments)
    if name == "notion_ancestor_fetch_adapter_execution_contract":
        return tool_notion_ancestor_fetch_adapter_execution_contract(arguments)
    if name == "notion_media_fetch_adapter_execution_contract":
        return tool_notion_media_fetch_adapter_execution_contract(arguments)
    if name == "notion_media_result_verification_plan":
        return tool_notion_media_result_verification_plan(arguments)
    if name == "notion_block_mirror_tree_fixture_plan":
        return tool_notion_block_mirror_tree_fixture_plan(arguments)
    if name == "notion_ancestor_merge_plan":
        return tool_notion_ancestor_merge_plan(arguments)
    if name == "notion_client_issue_verification_plan":
        return tool_notion_client_issue_verification_plan(arguments)
    if name == "notion_client_fixture_request_plan":
        return tool_notion_client_fixture_request_plan(arguments)
    if name == "list_sources":
        return tool_list_sources(arguments)
    if name == "source_scan_plan":
        return tool_source_scan_plan(arguments)
    if name == "source_registration_plan":
        return tool_source_registration_plan(arguments)
    if name == "source_mount_plan":
        return tool_source_mount_plan(arguments)
    if name == "list_zettels":
        return tool_list_zettels(arguments)
    if name == "zet_catalog":
        return tool_zet_catalog(arguments)
    if name == "first_read_readiness":
        return tool_first_read_readiness(arguments)
    if name == "abstract_freshness":
        return tool_abstract_freshness(arguments)
    if name == "zet_revision_plan":
        return tool_zet_revision_plan(arguments)
    if name == "read_zettel":
        return tool_read_zettel(arguments)
    if name == "zettel_objet_links":
        return tool_zettel_objet_links(arguments)
    if name == "zettel_objet_link_receipts":
        return tool_zettel_objet_link_receipts(arguments)
    if name == "facet_vocabulary":
        return tool_facet_vocabulary(arguments)
    if name == "view_health":
        return tool_view_health(arguments)
    if name == "view_recommendation_plan":
        return tool_view_recommendation_plan(arguments)
    if name == "index_health":
        return tool_index_health(arguments)
    if name == "notion_objet_link_plan":
        return tool_notion_objet_link_plan(arguments)
    if name == "notion_objet_link_index":
        return tool_notion_objet_link_index(arguments)
    if name == "notion_objet_source_map_link_plan":
        return tool_notion_objet_source_map_link_plan(arguments)
    if name == "notion_objet_import_clue_audit":
        return tool_notion_objet_import_clue_audit(arguments)
    if name == "notion_objet_link_rewrite_plan":
        return tool_notion_objet_link_rewrite_plan(arguments)
    if name == "block_header_check":
        return tool_block_header_check(arguments)
    if name == "zet_projection_plan_check":
        return tool_zet_projection_plan_check(arguments)
    if name == "zet_shared_update_record_review_preview":
        return tool_zet_shared_update_record_review_preview(arguments)
    if name == "zet_shared_update_record_review_index":
        return tool_zet_shared_update_record_review_index(arguments)
    if name == "zet_transport_would_plan":
        return tool_zet_transport_would_plan(arguments)
    if name == "foreign_block_intake_check":
        return tool_foreign_block_intake_check(arguments)
    if name == "foreign_block_trust_check":
        return tool_foreign_block_trust_check(arguments)
    if name == "foreign_block_attestation_packet_check":
        return tool_foreign_block_attestation_packet_check(arguments)
    if name == "foreign_block_quarantine_plan":
        return tool_foreign_block_quarantine_plan(arguments)
    if name == "quarantine_foreign_block_check":
        return tool_quarantine_foreign_block_check(arguments)
    if name == "foreign_block_quarantine_review_index":
        return tool_foreign_block_quarantine_review_index(arguments)
    if name == "foreign_block_quarantine_decision_check":
        return tool_foreign_block_quarantine_decision_check(arguments)
    if name == "record_quarantine_decision_check":
        return tool_record_quarantine_decision_check(arguments)
    if name == "foreign_block_quarantine_decision_review_index":
        return tool_foreign_block_quarantine_decision_review_index(arguments)
    if name == "foreign_block_decision_outcome_plan":
        return tool_foreign_block_decision_outcome_plan(arguments)
    if name == "foreign_block_attestation_review_candidate_plan":
        return tool_foreign_block_attestation_review_candidate_plan(arguments)
    if name == "record_attestation_review_candidate_check":
        return tool_record_attestation_review_candidate_check(arguments)
    if name == "foreign_block_attestation_review_candidate_index":
        return tool_foreign_block_attestation_review_candidate_index(arguments)
    if name == "foreign_block_attestation_statement_draft_preview":
        return tool_foreign_block_attestation_statement_draft_preview(arguments)
    if name == "record_attestation_statement_draft_check":
        return tool_record_attestation_statement_draft_check(arguments)
    if name == "foreign_block_attestation_statement_draft_review_index":
        return tool_foreign_block_attestation_statement_draft_review_index(arguments)
    if name == "foreign_block_attestation_statement_draft_decision_preview":
        return tool_foreign_block_attestation_statement_draft_decision_preview(arguments)
    if name == "create_draft_zettel":
        return tool_create_draft_zettel(arguments)
    if name == "list_views":
        return tool_list_views(arguments)
    if name == "archive_index":
        return tool_archive_index(arguments)
    if name == "archive_search":
        return tool_archive_search(arguments)
    if name == "objet_rediscovery_plan":
        return tool_objet_rediscovery_plan(arguments)
    if name == "promotion_check":
        return tool_promotion_check(arguments)
    if name == "mint_zettel_check":
        return tool_mint_zettel_check(arguments)
    if name == "share_check":
        return tool_share_check(arguments)
    if name == "delegate_zet_check":
        return tool_delegate_zet_check(arguments)
    if name == "attest_zet_check":
        return tool_attest_zet_check(arguments)
    if name == "anchor_zet_check":
        return tool_anchor_zet_check(arguments)
    if name == "ownership_transfer_check":
        return tool_ownership_transfer_check(arguments)

    raise InvalidParamsError("Unknown tool.")


def tool_archive_doctor(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    strict = bool(arguments.get("strict", False))
    doctor = archive_cli.Doctor(archive_root)
    diagnostics = doctor.run()
    errors = [item for item in diagnostics if item.severity == "ERROR"]
    warnings = [item for item in diagnostics if item.severity == "WARN"]
    ok = not errors and not (strict and warnings)
    text = f"archive_doctor: {len(errors)} error(s), {len(warnings)} warning(s)."
    return tool_success_result(
        text,
        {
            "ok": ok,
            "errors": len(errors),
            "warnings": len(warnings),
            "diagnostics": [item.as_dict() for item in diagnostics],
        },
    )


def tool_wom_profile_list(arguments: dict[str, Any]) -> dict[str, Any]:
    registry = require_path_arg(arguments, "registry")
    requested_redaction = bool(arguments.get("redact_local_paths", True))
    redact_local_paths = mcp_redact_local_paths(requested_redaction)
    result = call_service(
        archive_services.profile_list,
        registry,
        current_profile=optional_string_arg(arguments, "current_profile"),
        strict=bool(arguments.get("strict", False)),
        redact_local_paths=redact_local_paths,
    )
    add_mcp_redaction_warning(result, requested_redaction, redact_local_paths)
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"wom_profile_list: {state}.", result)


def tool_wom_profile_resolve(arguments: dict[str, Any]) -> dict[str, Any]:
    registry = require_path_arg(arguments, "registry")
    target = require_string_arg(arguments, "target")
    requested_redaction = bool(arguments.get("redact_local_paths", True))
    redact_local_paths = mcp_redact_local_paths(requested_redaction)
    result = call_service(
        archive_services.profile_resolve,
        registry,
        target=target,
        current_profile=optional_string_arg(arguments, "current_profile"),
        strict=bool(arguments.get("strict", False)),
        redact_local_paths=redact_local_paths,
    )
    add_mcp_redaction_warning(result, requested_redaction, redact_local_paths)
    state = str(result.get("resolution_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"wom_profile_resolve: {state}.", result)


def tool_wom_profile_wallet_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    profile = require_string_arg(arguments, "profile")
    registry = optional_path_arg(arguments, "registry")
    if arguments.get("dry_run", True) is False:
        raise ToolError("wom_profile_wallet_check is dry-run only.")
    requested_redaction = bool(arguments.get("redact_local_paths", True))
    redact_local_paths = mcp_redact_local_paths(requested_redaction)
    result = call_service(
        archive_services.profile_wallet_preview,
        archive_root,
        profile=profile,
        registry_path=registry,
        dry_run=bool(arguments.get("dry_run", True)),
        redact_local_paths=redact_local_paths,
    )
    add_mcp_redaction_warning(result, requested_redaction, redact_local_paths)
    state = str(result.get("resolution_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"wom_profile_wallet_check: {state}.", result)


def tool_archive_runtime_context(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    strict = bool(arguments.get("strict", False))
    full_doctor = bool(arguments.get("full_doctor", False))
    requested_redaction = bool(arguments.get("redact_local_paths", True))
    redact_local_paths = mcp_redact_local_paths(requested_redaction)
    diagnostics: list[dict[str, Any]] | None = None
    inspection_reads = {
        "zettel_bodies_read": False,
        "objet_bytes_read": False,
        "archive_text_scanned_for_secret_patterns": False,
    }
    if full_doctor:
        doctor = archive_cli.Doctor(archive_root)
        diagnostics = [item.as_dict() for item in doctor.run()]
        inspection_reads = doctor.read_observations()
    result = call_service(
        archive_services.runtime_context,
        archive_root,
        expected_archive_id=optional_string_arg(arguments, "expected_archive_id"),
        expected_type=optional_string_arg(arguments, "expected_type"),
        strict=strict,
        redact_local_paths=redact_local_paths,
        diagnostics=diagnostics,
        inspection_mode="full_doctor" if full_doctor else "quick",
        inspection_reads=inspection_reads,
    )
    add_mcp_redaction_warning(result, requested_redaction, redact_local_paths)
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"archive_runtime_context: {state}; mode={result['inspection']['mode']}.", result)


def tool_archive_work_session_manage(arguments: dict[str, Any]) -> dict[str, Any]:
    from ._mcp_session_transport import current_session_request
    from .work_session_command import REQUEST_LIMIT_BYTES, dispatch_work_session_management

    flags = {"dry_run", "approve", "apply", "resume", "review_original"}
    refs = {"client_app_ref", "task_route_ref", "work_session_ref", "target_app_ref"}
    allowed = {"archive_root", "action", "request", *flags, *refs}
    if (type(arguments) is not dict or any(type(key) is not str for key in arguments)
            or set(arguments) - allowed
            or type(arguments.get("action")) is not str
            or arguments["action"] not in {"register-app", "request-init", "create", "claim", "pause", "resume", "complete", "handoff", "accept", "recover"}):
        raise InvalidParamsError()
    if (any(type(arguments[key]) is not bool for key in flags if key in arguments)
            or any(type(arguments[key]) is not str for key in refs if key in arguments)
            or ("request" in arguments and type(arguments["request"]) is not dict)):
        raise InvalidParamsError()
    valid_size = False
    try:
        valid_size = len(json.dumps(arguments, ensure_ascii=False, allow_nan=False).encode("utf-8")) <= REQUEST_LIMIT_BYTES
    except (TypeError, ValueError, UnicodeError):
        pass
    if not valid_size:
        raise InvalidParamsError()
    archive_root = require_path_arg(arguments, "archive_root")
    context = current_session_request()
    wait_callbacks = {} if context is None else {
        "cancel_requested": context.cancel_requested, "progress": context.progress,
    }
    result = dispatch_work_session_management(archive_root, action=arguments["action"],
        **{key: arguments.get(key, False) for key in flags},
        **{key: arguments.get(key) for key in refs}, request=arguments.get("request"), **wait_callbacks)
    if not result["ok"]:
        return {"content": [{"type": "text", "text": "Work-session operation could not be completed."}],
                "structuredContent": result, "isError": True}
    return tool_success_result("Work-session operation returned; original evidence and current ownership remain distinct.", result)


def tool_archive_work_session(arguments: dict[str, Any]) -> dict[str, Any]:
    from .work_session_query import WorkSessionQueryError, query_work_sessions

    allowed = {"archive_root", "action", "kind", "ref", "client_app_ref",
               "workstream_ref", "page_size", "cursor"}
    if set(arguments) - allowed:
        raise InvalidParamsError()
    for key in allowed - {"page_size"}:
        if key in arguments and type(arguments[key]) is not str:
            raise InvalidParamsError()
    page_size = arguments.get("page_size", 20)
    if type(page_size) is not int or not 1 <= page_size <= 2000:
        raise InvalidParamsError()
    if arguments.get("action", "list") not in {"list", "inspect"} or arguments.get(
            "kind", "session") not in {"app", "workstream", "session"}:
        raise InvalidParamsError()
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        result = query_work_sessions(
            archive_root, action=arguments.get("action", "list"), kind=arguments.get("kind", "session"),
            reference=arguments.get("ref"), client_app_ref=arguments.get("client_app_ref"),
            workstream_ref=arguments.get("workstream_ref"), page_size=page_size, cursor=arguments.get("cursor"),
        )
    except WorkSessionQueryError as error:
        return {"content": [{"type": "text", "text": "Work-session query could not be completed."}],
                "structuredContent": {"schema": "wom-kit/work-session-query/v1", "ok": False,
                                      "reason_code": error.code, "read_only": True, "private_values_echoed": False},
                "isError": True}
    return tool_success_result("Read-only work-session registry query returned.", result)


def tool_archive_capabilities(arguments: dict[str, Any]) -> dict[str, Any]:
    unexpected = set(arguments) - {"no_commands"}
    if unexpected or (
        "no_commands" in arguments
        and type(arguments["no_commands"]) is not bool
    ):
        raise InvalidParamsError()
    result = archive_cli.capabilities_result(
        no_commands=bool(arguments.get("no_commands", False))
    )
    return tool_success_result(
        "archive_capabilities: parser-derived availability returned.",
        result,
    )


def tool_prompt_boundary_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("prompt_boundary_check is dry-run only.")
    result = call_service(
        archive_services.prompt_boundary_check,
        archive_root,
        text=optional_string_arg(arguments, "text"),
        relative_path=optional_string_arg(arguments, "path"),
        dry_run=True,
    )
    state = str(result.get("risk_level") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"prompt_boundary_check: {state}.", result)


def tool_github_repository_setup_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.github_repository_setup_plan,
        archive_root,
        profile_id=optional_string_arg(arguments, "profile_id"),
        profile_slug=optional_string_arg(arguments, "profile_slug"),
        github_owner=optional_string_arg(arguments, "github_owner"),
        github_account_ref=optional_string_arg(arguments, "github_account_ref"),
        repo_name=optional_string_arg(arguments, "repo_name"),
        visibility=optional_string_arg(arguments, "visibility") or archive_services.GITHUB_REPOSITORY_DEFAULT_VISIBILITY,
        remote_protocol=optional_string_arg(arguments, "remote_protocol")
        or archive_services.GITHUB_REPOSITORY_DEFAULT_REMOTE_PROTOCOL,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"github_repository_setup_plan: {state}.", result)


def tool_object_storage_setup_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.object_storage_setup_plan,
        archive_root,
        provider=optional_string_arg(arguments, "provider"),
        profile_id=optional_string_arg(arguments, "profile_id"),
        profile_slug=optional_string_arg(arguments, "profile_slug"),
        storage_account_ref=optional_string_arg(arguments, "storage_account_ref"),
        bucket_name=optional_string_arg(arguments, "bucket_name"),
        region=optional_string_arg(arguments, "region"),
        endpoint_ref=optional_string_arg(arguments, "endpoint_ref"),
        objet_prefix=optional_string_arg(arguments, "objet_prefix"),
        visibility=optional_string_arg(arguments, "visibility") or archive_services.OBJECT_STORAGE_DEFAULT_VISIBILITY,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"object_storage_setup_plan: {state}.", result)


def tool_provider_setup_status(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("provider_setup_status is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.provider_setup_status, archive_root)
    state = str(result.get("status") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"provider_setup_status: {state}.", result)


def tool_object_storage_adapter_readiness_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("object_storage_adapter_readiness_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.object_storage_adapter_readiness_plan,
        archive_root,
        operation=optional_string_arg(arguments, "operation") or "presigned_download",
        provider_ref=optional_string_arg(arguments, "provider_ref"),
        dry_run=True,
    )
    state = str(result.get("readiness_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"object_storage_adapter_readiness_plan: {state}.", result)


def tool_object_storage_operation_request_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("object_storage_operation_request_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        ttl_seconds = int(arguments.get("ttl_seconds", archive_services.PRESIGNED_URL_DEFAULT_TTL_SECONDS))
    except (TypeError, ValueError):
        raise ToolError("ttl_seconds must be an integer.")
    result = call_service(
        archive_services.object_storage_operation_request_plan,
        archive_root,
        operation=optional_string_arg(arguments, "operation") or "presigned_download",
        object_id=optional_string_arg(arguments, "object_id"),
        store_ref=optional_string_arg(arguments, "store_ref"),
        ttl_seconds=ttl_seconds,
        provider_ref=optional_string_arg(arguments, "provider_ref"),
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:object-storage",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:object-storage",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = str(result.get("request_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"object_storage_operation_request_plan: {state}.", result)


def tool_object_storage_adapter_execution_contract(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("object_storage_adapter_execution_contract is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.object_storage_adapter_execution_contract,
        archive_root,
        operation=optional_string_arg(arguments, "operation") or "upload_object",
        object_id=optional_string_arg(arguments, "object_id"),
        store_ref=optional_string_arg(arguments, "store_ref"),
        provider_ref=optional_string_arg(arguments, "provider_ref"),
        dry_run=True,
    )
    state = str(result.get("contract_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"object_storage_adapter_execution_contract: {state}.", result)


def _optional_max_objects_arg(arguments: dict[str, Any]) -> int | None:
    value = arguments.get("max_objects")
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ToolError("max_objects must be an integer.")


def tool_object_storage_upload_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("object_storage_upload_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.object_storage_upload_plan,
        archive_root,
        provider_kind=optional_string_arg(arguments, "provider_kind") or "cloudflare-r2",
        store_ref=optional_string_arg(arguments, "store_ref"),
        access_key_id_ref=optional_string_arg(arguments, "access_key_id_ref"),
        secret_access_key_ref=optional_string_arg(arguments, "secret_access_key_ref"),
        only=optional_string_arg(arguments, "only"),
        max_objects=_optional_max_objects_arg(arguments),
        skip_uploaded=bool(arguments.get("skip_uploaded", False)),
        dry_run=True,
    )
    state = "ready" if result.get("ok") else "blocked"
    return tool_success_result(f"object_storage_upload_plan: {state}.", result)


def tool_object_storage_upload_verify(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("object_storage_upload_verify is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.object_storage_upload_verify,
        archive_root,
        provider_kind=optional_string_arg(arguments, "provider_kind") or "cloudflare-r2",
        store_ref=optional_string_arg(arguments, "store_ref"),
        only=optional_string_arg(arguments, "only"),
        max_objects=_optional_max_objects_arg(arguments),
        dry_run=True,
    )
    state = "ready" if result.get("ok") else "blocked"
    return tool_success_result(f"object_storage_upload_verify: {state}.", result)


def tool_human_artifact_store_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is False:
        raise ToolError("human_artifact_store_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.human_artifact_store_plan,
        archive_root,
        surface_kind=require_string_arg(arguments, "surface_kind"),
        surface_ref=optional_string_arg(arguments, "surface_ref"),
        role=optional_string_arg(arguments, "role") or archive_services.HUMAN_ARTIFACT_DEFAULT_ROLE,
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"human_artifact_store_plan: {state}.", result)


def _human_artifact_mcp_local_ui_required(
    lifecycle_action: str,
) -> dict[str, Any]:
    return tool_success_result(
        f"{lifecycle_action}: blocked; local native approval UI required.",
        {
            "ok": False,
            "state": "blocked",
            "lifecycle_action": lifecycle_action,
            "reason_codes": ["exact_human_approval_cli_required"],
            "requires_local_native_approval_ui": True,
            "write_performed": False,
            "private_values_echoed": False,
        },
    )


def _human_artifact_mcp_write_requested(arguments: dict[str, Any]) -> bool:
    dry_run = arguments.get("dry_run", True)
    approve = arguments.get("approve", False)
    approved = arguments.get("approved", False)
    if any(type(value) is not bool for value in (dry_run, approve, approved)):
        raise ToolError()
    return dry_run is not True or approve is True or approved is True


def _human_artifact_mcp_max_entries(arguments: dict[str, Any]) -> int:
    value = arguments.get(
        "max_entries_per_root",
        human_artifact_registry.DEFAULT_MAX_ENTRIES_PER_ROOT,
    )
    if type(value) is not int:
        raise ToolError()
    return value


def _human_artifact_mcp_result(
    lifecycle_action: str,
    function: Any,
    *args: Any,
    **kwargs: Any,
) -> dict[str, Any]:
    try:
        result = function(*args, **kwargs)
    except human_artifact_registry.HumanArtifactRegistryError as exc:
        result = {
            "ok": False,
            "state": "blocked",
            "lifecycle_action": lifecycle_action,
            "reason_codes": [exc.code],
            "write_performed": False,
            "private_values_echoed": False,
        }
    state = "passed" if result.get("ok") is True else "blocked"
    return tool_success_result(f"{lifecycle_action}: {state}.", result)


def tool_human_artifact_root_registration_plan(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "human_artifact_project_root_registration_plan"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(
            "human_artifact_project_root_registration"
        )
    archive_root = require_path_arg(arguments, "archive_root")
    project_root = require_path_arg(arguments, "project_root")
    root_kind = optional_string_arg(arguments, "root_kind") or "external_project"
    if root_kind not in human_artifact_registry.EXTERNAL_ROOT_KINDS:
        raise ToolError()
    return _human_artifact_mcp_result(
        lifecycle_action,
        human_artifact_registry.plan_project_root_registration,
        archive_root,
        project_root,
        root_kind=root_kind,
    )


def tool_human_artifact_registry_scan(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "human_artifact_registry_scan"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(lifecycle_action)
    archive_root = require_path_arg(arguments, "archive_root")
    return _human_artifact_mcp_result(
        lifecycle_action,
        human_artifact_registry.scan_human_artifacts,
        archive_root,
        max_entries_per_root=_human_artifact_mcp_max_entries(arguments),
    )


def tool_human_artifact_transition_plan(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "human_artifact_transition_plan"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(
            "human_artifact_transition"
        )
    archive_root = require_path_arg(arguments, "archive_root")
    related_refs = arguments.get("related_refs", [])
    if not isinstance(related_refs, list):
        raise ToolError()
    normalized_refs: list[dict[str, str]] = []
    for value in related_refs:
        if (
            not isinstance(value, dict)
            or set(value) != {"kind", "ref"}
            or type(value.get("kind")) is not str
            or type(value.get("ref")) is not str
        ):
            raise ToolError()
        normalized_refs.append(
            {"kind": value["kind"], "ref": value["ref"]}
        )
    size_bytes = arguments.get("size_bytes")
    if type(size_bytes) is not int:
        raise ToolError()
    return _human_artifact_mcp_result(
        lifecycle_action,
        human_artifact_registry.plan_artifact_transition,
        archive_root,
        require_string_arg(arguments, "artifact_id"),
        target_state=require_string_arg(arguments, "target_state"),
        content_sha256=require_string_arg(arguments, "content_sha256"),
        size_bytes=size_bytes,
        related_refs=normalized_refs,
        max_entries_per_root=_human_artifact_mcp_max_entries(arguments),
    )


def _mcp_use_archive_receipt_authentication_key(
    archive_root: Path,
    consumer: Any,
) -> dict[str, Any]:
    """Use the established callback-only archive key without creating it."""

    from .credential_secure_intake_windows import _CtypesWindowsNativeFacade
    from .credential_secure_registry import _StableArchiveFingerprintKeyProvider

    native = _CtypesWindowsNativeFacade(cli_live_approved=True)
    provider = _StableArchiveFingerprintKeyProvider(native)
    return provider.use_key(
        archive_root,
        consumer,
        create_if_missing=False,
    )


def _approval_integrity_mcp_keyed_result(
    lifecycle_action: str,
    archive_root: Path,
    consumer: Any,
) -> dict[str, Any]:
    try:
        result = _mcp_use_archive_receipt_authentication_key(
            archive_root,
            consumer,
        )
    except approval_integrity.ApprovalIntegrityError as exc:
        result = {
            "ok": False,
            "state": "blocked",
            "lifecycle_action": lifecycle_action,
            "reason_codes": [exc.code],
            "private_values_echoed": False,
        }
    except Exception:
        result = {
            "ok": False,
            "state": "blocked",
            "lifecycle_action": lifecycle_action,
            "reason_codes": ["approval_integrity_key_unavailable"],
            "private_values_echoed": False,
        }
    if not isinstance(result, dict):
        raise ToolError()
    state = "passed" if result.get("ok") is True else "blocked"
    return tool_success_result(f"{lifecycle_action}: {state}.", result)


def tool_duplicate_object_reconciliation_plan(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "duplicate_object_reconciliation_plan"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(
            "duplicate_object_reconciliation"
        )
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        result = duplicate_object_reconciliation.plan_duplicate_object_reconciliation(
            archive_root
        )
    except (
        duplicate_object_reconciliation.DuplicateObjectReconciliationError
    ) as exc:
        result = {
            "ok": False,
            "state": "blocked",
            "lifecycle_action": lifecycle_action,
            "reason_codes": [exc.code],
            "object_ids_echoed": False,
            "paths_echoed": False,
            "row_content_echoed": False,
        }
    state = "passed" if result.get("ok") is True else "blocked"
    return tool_success_result(f"{lifecycle_action}: {state}.", result)


def tool_approval_integrity_audit(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "approval_integrity_audit"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(lifecycle_action)
    max_receipts = arguments.get("max_receipts", 4096)
    if type(max_receipts) is not int:
        raise ToolError()
    archive_root = require_path_arg(arguments, "archive_root")
    return _approval_integrity_mcp_keyed_result(
        lifecycle_action,
        archive_root,
        lambda key: approval_integrity.audit_approval_integrity(
            archive_root,
            max_receipts=max_receipts,
            receipt_authentication_key=key,
        ),
    )


def tool_approval_integrity_guard(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "approval_integrity_guard"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(lifecycle_action)
    max_overlays = arguments.get("max_overlays", 1024)
    if type(max_overlays) is not int:
        raise ToolError()
    archive_root = require_path_arg(arguments, "archive_root")
    return _approval_integrity_mcp_keyed_result(
        lifecycle_action,
        archive_root,
        lambda key: approval_integrity.approval_integrity_guard(
            archive_root,
            affected_kind=require_string_arg(arguments, "affected_kind"),
            affected_id_sha256=require_string_arg(
                arguments,
                "affected_id_sha256",
            ),
            receipt_authentication_key=key,
            max_overlays=max_overlays,
        ),
    )


def tool_approval_integrity_overlay_plan(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    lifecycle_action = "approval_integrity_overlay_plan"
    if _human_artifact_mcp_write_requested(arguments):
        return _human_artifact_mcp_local_ui_required(
            "approval_integrity_overlay"
        )
    max_overlays = arguments.get("max_overlays", 1024)
    if type(max_overlays) is not int:
        raise ToolError()
    archive_root = require_path_arg(arguments, "archive_root")
    return _approval_integrity_mcp_keyed_result(
        lifecycle_action,
        archive_root,
        lambda key: approval_integrity.plan_approval_integrity_overlay(
            archive_root,
            operation_receipt=require_string_arg(
                arguments,
                "operation_receipt",
            ),
            expected_operation_receipt_sha256=require_string_arg(
                arguments,
                "expected_operation_receipt_sha256",
            ),
            affected_kind=require_string_arg(arguments, "affected_kind"),
            affected_id_sha256=require_string_arg(
                arguments,
                "affected_id_sha256",
            ),
            state=require_string_arg(arguments, "state"),
            expected_current_overlay_digest=optional_string_arg(
                arguments,
                "expected_current_overlay_digest",
            ),
            receipt_authentication_key=key,
            max_overlays=max_overlays,
        ),
    )


def tool_imap_mailbox_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.imap_mailbox_plan,
        archive_root,
        source_id=require_string_arg(arguments, "source_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=arguments.get("imap_port", 993),
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"imap_mailbox_plan: {state}.", result)


def tool_imap_mailbox_operation_request_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_operation_request_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        imap_port = int(arguments.get("imap_port", 993))
    except (TypeError, ValueError):
        raise ToolError("imap_port must be an integer.")
    try:
        max_messages = int(arguments.get("max_messages", archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT))
    except (TypeError, ValueError):
        raise ToolError("max_messages must be an integer.")
    since_days_arg = arguments.get("since_days")
    since_days: int | None = None
    if since_days_arg is not None:
        try:
            since_days = int(since_days_arg)
        except (TypeError, ValueError):
            raise ToolError("since_days must be an integer.")
    result = call_service(
        archive_services.imap_mailbox_operation_request_plan,
        archive_root,
        source_id=require_string_arg(arguments, "source_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=imap_port,
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        operation=optional_string_arg(arguments, "operation") or "header_metadata_scan",
        max_messages=max_messages,
        since_days=since_days,
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:mail-source-access",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        credential_provider=optional_string_arg(arguments, "credential_provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = str(result.get("request_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"imap_mailbox_operation_request_plan: {state}.", result)


def tool_imap_mailbox_adapter_readiness_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_adapter_readiness_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        imap_port = int(arguments.get("imap_port", 993))
    except (TypeError, ValueError):
        raise ToolError("imap_port must be an integer.")
    try:
        max_messages = int(arguments.get("max_messages", archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT))
    except (TypeError, ValueError):
        raise ToolError("max_messages must be an integer.")
    since_days_arg = arguments.get("since_days")
    since_days: int | None = None
    if since_days_arg is not None:
        try:
            since_days = int(since_days_arg)
        except (TypeError, ValueError):
            raise ToolError("since_days must be an integer.")
    result = call_service(
        archive_services.imap_mailbox_adapter_readiness_plan,
        archive_root,
        source_id=require_string_arg(arguments, "source_id"),
        adapter_id=optional_string_arg(arguments, "adapter_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=imap_port,
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        operation=optional_string_arg(arguments, "operation") or "header_metadata_scan",
        max_messages=max_messages,
        since_days=since_days,
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:mail-source-access",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        credential_provider=optional_string_arg(arguments, "credential_provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = str(result.get("readiness_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"imap_mailbox_adapter_readiness_plan: {state}.", result)


def tool_imap_mailbox_selection_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_selection_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        imap_port = int(arguments.get("imap_port", 993))
    except (TypeError, ValueError):
        raise ToolError("imap_port must be an integer.")
    try:
        max_messages = int(arguments.get("max_messages", archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT))
    except (TypeError, ValueError):
        raise ToolError("max_messages must be an integer.")
    since_days_arg = arguments.get("since_days")
    since_days: int | None = None
    if since_days_arg is not None:
        try:
            since_days = int(since_days_arg)
        except (TypeError, ValueError):
            raise ToolError("since_days must be an integer.")
    result = call_service(
        archive_services.imap_mailbox_selection_plan,
        archive_root,
        source_id=require_string_arg(arguments, "source_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=imap_port,
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        operation=optional_string_arg(arguments, "operation") or "header_metadata_scan",
        selection_rule=optional_string_arg(arguments, "selection_rule") or "newest_first",
        selector_id=optional_string_arg(arguments, "selector_id") or "mail-selection:recent-inbox",
        max_messages=max_messages,
        since_days=since_days,
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:mail-source-access",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        credential_provider=optional_string_arg(arguments, "credential_provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = str(result.get("selection_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"imap_mailbox_selection_plan: {state}.", result)


def tool_imap_mailbox_adapter_audit_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_adapter_audit_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        imap_port = int(arguments.get("imap_port", 993))
    except (TypeError, ValueError):
        raise ToolError("imap_port must be an integer.")
    try:
        max_messages = int(arguments.get("max_messages", archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT))
    except (TypeError, ValueError):
        raise ToolError("max_messages must be an integer.")
    since_days_arg = arguments.get("since_days")
    since_days: int | None = None
    if since_days_arg is not None:
        try:
            since_days = int(since_days_arg)
        except (TypeError, ValueError):
            raise ToolError("since_days must be an integer.")
    result = call_service(
        archive_services.imap_mailbox_adapter_audit_plan,
        archive_root,
        adapter_id=require_string_arg(arguments, "adapter_id"),
        source_id=require_string_arg(arguments, "source_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=imap_port,
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        operation=optional_string_arg(arguments, "operation") or "header_metadata_scan",
        selection_rule=optional_string_arg(arguments, "selection_rule") or "newest_first",
        selector_id=optional_string_arg(arguments, "selector_id") or "mail-selection:recent-inbox",
        max_messages=max_messages,
        since_days=since_days,
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:mail-source-access",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        credential_provider=optional_string_arg(arguments, "credential_provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        result_status=optional_string_arg(arguments, "result_status") or "not_run",
        dry_run=True,
    )
    state = str(result.get("audit_state") or ("passed" if result["ok"] else "blocked"))
    receipt = result.get("receipt_preview") if isinstance(result.get("receipt_preview"), dict) else {}
    return tool_success_result(
        f"imap_mailbox_adapter_audit_plan: {state}, result={receipt.get('result_status') or '-'}.",
        result,
    )


def tool_imap_mailbox_adapter_preflight_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_adapter_preflight_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        imap_port = int(arguments.get("imap_port", 993))
    except (TypeError, ValueError):
        raise ToolError("imap_port must be an integer.")
    try:
        max_messages = int(arguments.get("max_messages", archive_services.IMAP_MAILBOX_OPERATION_MAX_MESSAGES_DEFAULT))
    except (TypeError, ValueError):
        raise ToolError("max_messages must be an integer.")
    since_days_arg = arguments.get("since_days")
    since_days: int | None = None
    if since_days_arg is not None:
        try:
            since_days = int(since_days_arg)
        except (TypeError, ValueError):
            raise ToolError("since_days must be an integer.")
    result = call_service(
        archive_services.imap_mailbox_adapter_preflight_plan,
        archive_root,
        adapter_id=require_string_arg(arguments, "adapter_id"),
        source_id=require_string_arg(arguments, "source_id"),
        provider=optional_string_arg(arguments, "provider") or "generic_imap",
        imap_host=optional_string_arg(arguments, "imap_host"),
        imap_port=imap_port,
        account_ref=require_string_arg(arguments, "account_ref"),
        username_ref=require_string_arg(arguments, "username_ref"),
        auth_mode=optional_string_arg(arguments, "auth_mode") or "app_password_ref",
        app_password_ref=optional_string_arg(arguments, "app_password_ref"),
        oauth_token_ref=optional_string_arg(arguments, "oauth_token_ref"),
        mailbox_ref=optional_string_arg(arguments, "mailbox_ref") or "imap:mailbox:inbox",
        operation=optional_string_arg(arguments, "operation") or "header_metadata_scan",
        selection_rule=optional_string_arg(arguments, "selection_rule") or "newest_first",
        selector_id=optional_string_arg(arguments, "selector_id") or "mail-selection:recent-inbox",
        max_messages=max_messages,
        since_days=since_days,
        credential_id=optional_string_arg(arguments, "credential_id") or "cred:mail-source-access",
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        credential_provider=optional_string_arg(arguments, "credential_provider"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = str(result.get("preflight_state") or ("passed" if result["ok"] else "blocked"))
    gate = result.get("gate_summary") if isinstance(result.get("gate_summary"), dict) else {}
    return tool_success_result(
        f"imap_mailbox_adapter_preflight_plan: {state}, request={gate.get('request_state') or '-'}.",
        result,
    )


def tool_imap_mailbox_adapter_manifest_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("imap_mailbox_adapter_manifest_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    providers_arg = arguments.get("providers")
    operations_arg = arguments.get("operations")
    selection_rules_arg = arguments.get("selection_rules")
    result = call_service(
        archive_services.imap_mailbox_adapter_manifest_plan,
        archive_root,
        adapter_id=require_string_arg(arguments, "adapter_id"),
        providers=[str(item) for item in providers_arg] if isinstance(providers_arg, list) else None,
        operations=[str(item) for item in operations_arg] if isinstance(operations_arg, list) else None,
        selection_rules=[str(item) for item in selection_rules_arg] if isinstance(selection_rules_arg, list) else None,
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:imap-mailbox",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    manifest = result.get("manifest_preview") if isinstance(result.get("manifest_preview"), dict) else {}
    return tool_success_result(
        f"imap_mailbox_adapter_manifest_plan: {state}, adapter={manifest.get('adapter_id') or '-'}.",
        result,
    )


def tool_credential_ref_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_ref_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_ref_plan,
        archive_root,
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=require_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind") or "generic_secret",
        purpose=optional_string_arg(arguments, "purpose"),
        provider=optional_string_arg(arguments, "provider"),
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"credential_ref_plan: {state}.", result)


def tool_credential_ref_inventory(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_ref_inventory is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_ref_inventory,
        archive_root,
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"credential_ref_inventory: {state}, {result['credential_count']} ref(s).", result)


def tool_credential_store_recommendation(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_store_recommendation is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_store_recommendation,
        archive_root,
        scenario=require_string_arg(arguments, "scenario"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    primary = result.get("primary_recommendation") if isinstance(result.get("primary_recommendation"), dict) else {}
    return tool_success_result(
        f"credential_store_recommendation: {state}, primary={primary.get('store_id') or '-'}.",
        result,
    )


def tool_credential_vault_onboarding_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_vault_onboarding_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_vault_onboarding_plan,
        archive_root,
        scenario=require_string_arg(arguments, "scenario"),
        store_id=optional_string_arg(arguments, "store_id") or "recommended",
        credential_id=optional_string_arg(arguments, "credential_id"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=optional_string_arg(arguments, "action_kind"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    store = result.get("selected_store") if isinstance(result.get("selected_store"), dict) else {}
    return tool_success_result(
        f"credential_vault_onboarding_plan: {state}, store={store.get('store_id') or '-'}.",
        result,
    )


def tool_credential_plaintext_migration_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_plaintext_migration_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_plaintext_migration_plan,
        archive_root,
        source_label=require_string_arg(arguments, "source_label"),
        credential_id=require_string_arg(arguments, "credential_id"),
        target_store_id=optional_string_arg(arguments, "target_store_id") or "recommended",
        scenario=optional_string_arg(arguments, "scenario") or "personal_local_first",
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    target = result.get("target") if isinstance(result.get("target"), dict) else {}
    return tool_success_result(
        f"credential_plaintext_migration_plan: {state}, target={target.get('selected_store_id') or '-'}.",
        result,
    )


def tool_credential_policy_check(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_policy_check is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_policy_check,
        archive_root,
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=require_string_arg(arguments, "action_kind"),
        approval_decision=optional_string_arg(arguments, "approval_decision") or "needs_review",
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        adapter_kind=optional_string_arg(arguments, "adapter_kind"),
        operation=optional_string_arg(arguments, "operation"),
        consumer=optional_string_arg(arguments, "consumer"),
        reviewed_by=optional_string_arg(arguments, "reviewed_by"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        approval_receipt=optional_string_arg(arguments, "approval_receipt"),
        dry_run=True,
    )
    return tool_success_result(
        f"credential_policy_check: {result.get('policy_result') or '-'}.",
        result,
    )


def tool_credential_keepassxc_command_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_keepassxc_command_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_keepassxc_command_plan,
        archive_root,
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=optional_string_arg(arguments, "action_kind") or "plaintext_secret_migration",
        operation=optional_string_arg(arguments, "operation") or "plaintext_secret_migration",
        approval_receipt=require_string_arg(arguments, "approval_receipt"),
        entry_label=require_string_arg(arguments, "entry_label"),
        group_label=optional_string_arg(arguments, "group_label"),
        database_ref=optional_string_arg(arguments, "database_ref") or "keepassxc:human-selected-database",
        consumer=optional_string_arg(arguments, "consumer") or "wom:adapter:keepassxc",
        reviewed_by=optional_string_arg(arguments, "reviewed_by"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    summary = result.get("policy_check_summary") if isinstance(result.get("policy_check_summary"), dict) else {}
    return tool_success_result(
        f"credential_keepassxc_command_plan: {state}, policy={summary.get('policy_result') or '-'}.",
        result,
    )


def tool_credential_access_broker_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_access_broker_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_access_broker_plan,
        archive_root,
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=require_string_arg(arguments, "action_kind"),
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        consumer=optional_string_arg(arguments, "consumer") or "wom_local_adapter",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    request = result.get("broker_request") if isinstance(result.get("broker_request"), dict) else {}
    return tool_success_result(
        f"credential_access_broker_plan: {state}, action={request.get('action_kind') or '-'}.",
        result,
    )


def tool_credential_access_approval_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_access_approval_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_access_approval_plan,
        archive_root,
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=require_string_arg(arguments, "action_kind"),
        decision=optional_string_arg(arguments, "decision") or "needs_review",
        store_kind=optional_string_arg(arguments, "store_kind") or "password_manager",
        consumer=optional_string_arg(arguments, "consumer") or "wom_local_adapter",
        reviewed_by=optional_string_arg(arguments, "reviewed_by") or "human:pending-review",
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(
        f"credential_access_approval_plan: {state}, decision={result.get('decision') or '-'}.",
        result,
    )


def tool_credential_adapter_readiness_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_adapter_readiness_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_adapter_readiness_plan,
        archive_root,
        adapter_kind=require_string_arg(arguments, "adapter_kind"),
        operation=require_string_arg(arguments, "operation"),
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=require_string_arg(arguments, "action_kind"),
        store_kind=optional_string_arg(arguments, "store_kind"),
        consumer=optional_string_arg(arguments, "consumer"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    adapter = result.get("adapter") if isinstance(result.get("adapter"), dict) else {}
    return tool_success_result(
        f"credential_adapter_readiness_plan: {state}, adapter={adapter.get('adapter_kind') or '-'}.",
        result,
    )


def tool_credential_adapter_manifest_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_adapter_manifest_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    operations = arguments.get("operations")
    if operations is not None and not isinstance(operations, list):
        raise ToolError("operations must be an array when provided.")
    result = call_service(
        archive_services.credential_adapter_manifest_plan,
        archive_root,
        adapter_id=require_string_arg(arguments, "adapter_id"),
        adapter_kind=require_string_arg(arguments, "adapter_kind"),
        operations=[str(item) for item in operations] if isinstance(operations, list) else None,
        store_kind=optional_string_arg(arguments, "store_kind"),
        consumer=optional_string_arg(arguments, "consumer"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    manifest = result.get("manifest_preview") if isinstance(result.get("manifest_preview"), dict) else {}
    return tool_success_result(
        f"credential_adapter_manifest_plan: {state}, adapter={manifest.get('adapter_id') or '-'}.",
        result,
    )


def tool_credential_adapter_audit_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("credential_adapter_audit_plan is read-only and requires dry-run.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.credential_adapter_audit_plan,
        archive_root,
        adapter_id=require_string_arg(arguments, "adapter_id"),
        adapter_kind=require_string_arg(arguments, "adapter_kind"),
        operation=require_string_arg(arguments, "operation"),
        credential_id=require_string_arg(arguments, "credential_id"),
        credential_kind=optional_string_arg(arguments, "credential_kind"),
        provider=optional_string_arg(arguments, "provider"),
        action_kind=require_string_arg(arguments, "action_kind"),
        result_status=optional_string_arg(arguments, "result_status") or "not_run",
        store_kind=optional_string_arg(arguments, "store_kind"),
        consumer=optional_string_arg(arguments, "consumer"),
        platform=optional_string_arg(arguments, "platform") or "windows",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    receipt = result.get("receipt_preview") if isinstance(result.get("receipt_preview"), dict) else {}
    return tool_success_result(
        f"credential_adapter_audit_plan: {state}, result={receipt.get('result_status') or '-'}.",
        result,
    )


def tool_zet_surface_prototype_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_surface_prototype_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.zet_surface_prototype_plan,
        archive_root,
        surface_kind=require_string_arg(arguments, "surface_kind"),
        surface_ref=optional_string_arg(arguments, "surface_ref"),
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"zet_surface_prototype_plan: {state}.", result)


def tool_prehashed_objet_ledger_preview(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("prehashed_objet_ledger_preview is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    ledger = require_path_arg(arguments, "ledger")
    result = call_service(
        archive_services.prehashed_objet_ledger_preview,
        archive_root,
        ledger,
        store_kind=optional_string_arg(arguments, "store_kind") or "generic_content_addressed_store",
        sha256_field=optional_string_arg(arguments, "sha256_field") or "sha256",
        size_field=optional_string_arg(arguments, "size_field") or "bytes",
        mime_field=optional_string_arg(arguments, "mime_field") or "mime",
        dry_run=True,
        max_rows=int(arguments.get("max_rows", 100000)),
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"prehashed_objet_ledger_preview: {state}.", result)


def tool_resolve_objet_ref(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("resolve_objet_ref is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.resolve_objet_ref,
        archive_root,
        object_id=require_string_arg(arguments, "object_id"),
        dry_run=True,
    )
    state = str(result.get("resolution_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"resolve_objet_ref: {state}.", result)


def tool_presigned_url_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("presigned_url_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    try:
        ttl_seconds = int(arguments.get("ttl_seconds", archive_services.PRESIGNED_URL_DEFAULT_TTL_SECONDS))
    except (TypeError, ValueError):
        raise ToolError("ttl_seconds must be an integer.")
    result = call_service(
        archive_services.presigned_url_plan,
        archive_root,
        object_id=require_string_arg(arguments, "object_id"),
        store_ref=optional_string_arg(arguments, "store_ref"),
        operation=optional_string_arg(arguments, "operation") or "download",
        ttl_seconds=ttl_seconds,
        dry_run=True,
    )
    state = str(result.get("plan_state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"presigned_url_plan: {state}.", result)


def tool_project_intake_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    staged_folder = require_path_arg(arguments, "staged_folder")
    result = call_service(archive_services.project_intake_plan, archive_root, staged_folder)
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"project_intake_plan: {state}.", result)


def tool_project_intake_unpack_queue(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_unpack_queue is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    staged_folder = require_path_arg(arguments, "staged_folder")
    result = call_service(
        archive_services.project_intake_unpack_queue,
        archive_root,
        staged_folder,
        receipt=optional_string_arg(arguments, "receipt"),
        max_items=int(arguments.get("max_items", 25)),
        dry_run=True,
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_unpack_queue: {state}.", result)


def tool_project_intake_unpack_choice(arguments: dict[str, Any]) -> dict[str, Any]:
    dry_run = bool(arguments.get("dry_run", True))
    approve = bool(arguments.get("approve", False))
    archive_root = require_path_arg(arguments, "archive_root")
    choice = require_path_arg(arguments, "choice")
    staged_folder = require_path_arg(arguments, "staged_folder")
    result = call_service(
        archive_services.project_intake_unpack_choice,
        archive_root,
        choice,
        receipt=require_string_arg(arguments, "receipt"),
        staged_folder=staged_folder,
        dry_run=dry_run,
        approve=approve,
        reviewed_by=optional_string_arg(arguments, "reviewed_by"),
    )
    state = "recorded" if result.get("ok") and not result.get("dry_run") else ("ready" if result.get("ok") else "blocked")
    return tool_success_result(f"project_intake_unpack_choice: {state}.", result)


def tool_project_intake_staging_guide(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_staging_guide is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.project_intake_staging_guide,
        archive_root,
        project_slug=require_string_arg(arguments, "project_slug"),
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"project_intake_staging_guide: {state}.", result)


def tool_project_intake_session_guide(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_session_guide is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    staged_folder_value = optional_string_arg(arguments, "staged_folder")
    staged_folder = require_path_arg({"staged_folder": staged_folder_value}, "staged_folder") if staged_folder_value else None
    result = call_service(
        archive_services.project_intake_session_guide,
        archive_root,
        project_slug=optional_string_arg(arguments, "project_slug"),
        staged_folder=staged_folder,
        receipt=optional_string_arg(arguments, "receipt"),
        session_id=optional_string_arg(arguments, "session_id"),
        staged_folder_ref=optional_string_arg(arguments, "staged_folder_ref"),
        dry_run=True,
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_session_guide: {state}.", result)


def tool_project_intake_status(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_status is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.project_intake_status,
        archive_root,
        require_string_arg(arguments, "receipt"),
        dry_run=True,
    )
    state = str(result.get("readiness", {}).get("status") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_status: {state}.", result)


def tool_project_intake_next_question(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_next_question is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    staged_folder_value = optional_string_arg(arguments, "staged_folder")
    receipt = optional_string_arg(arguments, "receipt")
    staged_folder = require_path_arg({"staged_folder": staged_folder_value}, "staged_folder") if staged_folder_value else None
    result = call_service(
        archive_services.project_intake_next_question,
        archive_root,
        staged_folder=staged_folder,
        receipt=receipt,
        dry_run=True,
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_next_question: {state}.", result)


def tool_project_intake_decision_template(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_decision_template is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    staged_folder_value = optional_string_arg(arguments, "staged_folder")
    receipt = optional_string_arg(arguments, "receipt")
    staged_folder = require_path_arg({"staged_folder": staged_folder_value}, "staged_folder") if staged_folder_value else None
    result = call_service(
        archive_services.project_intake_decision_template,
        archive_root,
        staged_folder=staged_folder,
        receipt=receipt,
        session_id=optional_string_arg(arguments, "session_id"),
        staged_folder_ref=optional_string_arg(arguments, "staged_folder_ref"),
        dry_run=True,
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_decision_template: {state}.", result)


def tool_project_intake_item_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("project_intake_item_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    local_path = require_path_arg(arguments, "local_path")
    result = call_service(
        archive_services.project_intake_item_plan,
        archive_root,
        receipt=require_string_arg(arguments, "receipt"),
        local_path=local_path,
        source_role=optional_string_arg(arguments, "source_role") or archive_services.SOURCE_INTAKE_DEFAULT_ROLE,
        title=optional_string_arg(arguments, "title"),
        mime=optional_string_arg(arguments, "mime"),
        dry_run=True,
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"project_intake_item_plan: {state}.", result)


def tool_git_backup_reconcile_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    from ._mcp_session_transport import current_session_request
    from .git_backup_session_command import dispatch_session_git_backup, _project_mcp_git_backup_result

    fresh = {"remote_name", "branch", "credential_mode", "max_changes", "max_changed_bytes"}
    required = {"archive_root", "mode", "client_app_ref", "task_route_ref"}
    allowed = required | fresh | {"work_session_ref", "reviewed_by"}
    if (type(arguments) is not dict or any(type(key) is not str for key in arguments)
            or set(arguments) - allowed or not required <= set(arguments)):
        raise InvalidParamsError()
    for key, value in arguments.items():
        if key in {"max_changes", "max_changed_bytes"}:
            limit = 100000 if key == "max_changes" else 2147483648
            if type(value) is not int or not 1 <= value <= limit:
                raise InvalidParamsError()
        elif type(value) is not str or not value.strip() or len(value) > 65536:
            raise InvalidParamsError()
    mode = arguments["mode"]
    if mode not in {"preview", "apply", "resume", "review_original"}:
        raise InvalidParamsError()
    original = mode in {"resume", "review_original"}
    if (original and (fresh | {"reviewed_by"}) & set(arguments)
            or not original and "work_session_ref" not in arguments
            or mode == "apply" and "reviewed_by" not in arguments
            or mode != "apply" and "reviewed_by" in arguments
            or "credential_mode" in arguments and arguments["credential_mode"] != "stored"
            or len(json.dumps(arguments, ensure_ascii=True).encode("utf-8")) > 65536):
        raise InvalidParamsError()
    archive_root = require_path_arg(arguments, "archive_root")
    context = current_session_request()
    callbacks = {} if context is None else {"cancel_requested": context.cancel_requested, "progress": context.progress}
    raw = dispatch_session_git_backup(archive_root, mode=mode,
        client_app_ref=arguments["client_app_ref"], task_route_ref=arguments["task_route_ref"],
        work_session_ref=arguments.get("work_session_ref"), reviewer_claim=arguments.get("reviewed_by"),
        options={key: arguments[key] for key in fresh if key in arguments}, **callbacks)
    result = _project_mcp_git_backup_result(raw, mode=mode)
    if result["ok"] is not True:
        return {"content": [{"type": "text", "text": "Session Git backup could not be completed."}],
                "structuredContent": result, "isError": True}
    return tool_success_result("Session Git backup result returned; completion is reported separately from eligibility.", result)


def tool_zet_title_remap_write(arguments: dict[str, Any]) -> dict[str, Any]:
    from ._mcp_session_transport import current_session_request
    from .local_recovery_session import _dispatch_session_local_recovery
    from .local_title_recovery import zet_title_recovery_execution_plan

    strings = {"archive_root", "mode", "client_app_ref", "task_route_ref",
               "work_session_ref", "source_mirror", "reviewed_by"}
    counts = {"max_items", "expected_identifier_title_count"}
    required = {"archive_root", "mode", "client_app_ref", "task_route_ref"}
    if (type(arguments) is not dict or any(type(key) is not str for key in arguments)
            or set(arguments) - strings - counts or not required <= set(arguments)
            or any(type(value) is not str or not value.strip() or len(value) > 65536
                   for key, value in arguments.items() if key in strings)
            or any(type(value) is not int or not 0 <= value <= 2**63 - 1
                   for key, value in arguments.items() if key in counts)
            or arguments["mode"] not in {"preview", "apply", "resume", "review_original"}
            or len(json.dumps(arguments, ensure_ascii=True).encode("utf-8")) > 65536):
        raise InvalidParamsError()
    mode = arguments["mode"]
    original = mode in {"resume", "review_original"}
    if (original and ({"source_mirror", "reviewed_by"} | counts) & set(arguments)
            or not original and not {"work_session_ref", "source_mirror"} <= set(arguments)
            or mode == "apply" and "reviewed_by" not in arguments
            or mode == "preview" and "reviewed_by" in arguments
            or not 1 <= arguments.get("max_items", archive_services.ZET_TITLE_REMAP_MAX_ITEMS) <= 5000):
        raise InvalidParamsError()
    root = require_path_arg(arguments, "archive_root")
    context = current_session_request()
    callbacks = {} if context is None else {"cancel_requested": context.cancel_requested, "progress": context.progress}
    planner = None
    if not original:
        mirror = Path(arguments["source_mirror"])
        mirror = require_path_arg({"mirror": str(mirror if mirror.is_absolute() else root / mirror)}, "mirror")
        planner = lambda: zet_title_recovery_execution_plan(root, source_mirror=mirror,
            max_items=arguments.get("max_items", archive_services.ZET_TITLE_REMAP_MAX_ITEMS),
            expected_identifier_title_count=arguments.get("expected_identifier_title_count"))
    result = _dispatch_session_local_recovery(root, mode=mode,
        client_app_ref=arguments["client_app_ref"], task_route_ref=arguments["task_route_ref"],
        work_session_ref=arguments.get("work_session_ref"), plan_factory=planner,
        allowed_domains={"zet_title_recovery"},
        reviewer_claim=None if original else arguments.get("reviewed_by", "person:local-recovery-operator"), **callbacks)
    if result.get("ok") is not True:
        return {"content": [{"type": "text", "text": "Session title recovery could not be completed."}],
                "structuredContent": result, "isError": True}
    return tool_success_result("Session title recovery returned; field completion and file backup ownership are separate.", result)


def tool_source_intake_record(arguments: dict[str, Any]) -> dict[str, Any]:
    return _tool_session_source_intake(arguments, family="record")


def tool_source_intake_batch(arguments: dict[str, Any]) -> dict[str, Any]:
    return _tool_session_source_intake(arguments, family="batch")


def _tool_session_source_intake(arguments: dict[str, Any], *, family: str) -> dict[str, Any]:
    """Two fixed public routes; no caller-supplied dispatch or family authority."""
    from ._mcp_session_transport import current_session_request
    from .source_intake_session_command import dispatch_session_source_intake, dispatch_session_source_intake_record

    if type(family) is not str or family not in {"record", "batch"}:
        raise InvalidParamsError()
    record = family == "record"
    input_key = "source_intake_plan" if record else "manifest"
    allowed = {"archive_root", "mode", "client_app_ref", "task_route_ref", "work_session_ref",
               input_key, "reviewed_by"}
    required = {"archive_root", "mode", "client_app_ref", "task_route_ref"}
    if not record and (type(arguments) is not dict or any(type(key) is not str for key in arguments)):
        raise InvalidParamsError()
    if (type(arguments) is not dict or set(arguments) - allowed or not required <= set(arguments)
            or any(type(arguments[key]) is not str for key in arguments)
            or arguments["mode"] not in {"preview", "apply", "resume", "review_original"}):
        raise InvalidParamsError()
    # Keep the record route's original missing/empty-field error ordering. Its
    # existing command owns those structured failures; only the new batch tool
    # requires every fresh input at the MCP grammar boundary.
    original_mode = arguments["mode"] in {"resume", "review_original"}
    if not record and (any(not value.strip() or len(value) > 65536 for value in arguments.values())
            or not original_mode and not {"manifest", "work_session_ref"} <= set(arguments)
            or arguments["mode"] == "apply" and "reviewed_by" not in arguments):
        raise InvalidParamsError()
    # Bound both the direct call and asynchronous transport input. Do not echo
    # rejected path/identity values or let extra approval knobs reach a writer.
    if len(json.dumps(arguments, ensure_ascii=True).encode("utf-8")) > 65536:
        raise InvalidParamsError()
    if (original_mode and {input_key, "reviewed_by"} & set(arguments)
            or arguments["mode"] == "preview" and "reviewed_by" in arguments):
        raise InvalidParamsError()
    archive_root = require_path_arg(arguments, "archive_root")
    value = arguments.get(input_key)
    plan_path = None
    if value is not None:
        candidate = Path(value)
        candidate = candidate if candidate.is_absolute() else archive_root / candidate
        path_label = "plan" if record else "manifest"
        plan_path = require_path_arg({path_label: str(candidate)}, path_label)
    context = current_session_request()
    callbacks = {} if context is None else {"cancel_requested": context.cancel_requested, "progress": context.progress}
    dispatch = dispatch_session_source_intake_record if record else dispatch_session_source_intake
    input_path = {"plan_path": plan_path} if record else {"request_path": plan_path}
    result = dispatch(archive_root, mode=arguments["mode"],
        client_app_ref=arguments["client_app_ref"], task_route_ref=arguments["task_route_ref"],
        work_session_ref=arguments.get("work_session_ref"),
        reviewer_claim=arguments.get("reviewed_by"), **input_path, **callbacks)
    if result.get("ok") is not True:
        message = "Source-intake record could not be completed." if record else "Source-intake batch could not be completed."
        return {"content": [{"type": "text", "text": message}],
                "structuredContent": result, "isError": True}
    message = ("Source-intake metadata record returned; source bytes are not captured." if record else
               "Source-intake batch metadata returned; any prepared capture request needs separate approval to capture bytes.")
    return tool_success_result(message, result)


def tool_source_intake_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is False:
        raise ToolError("source_intake_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    local_path_value = optional_string_arg(arguments, "local_path")
    local_path = require_path_arg({"local_path": local_path_value}, "local_path") if local_path_value else None
    requested_redaction = bool(arguments.get("redact_local_paths", True))
    redact_local_paths = mcp_redact_local_paths(requested_redaction)
    result = call_service(
        archive_services.source_intake_plan,
        archive_root,
        local_path=local_path,
        source_id=optional_string_arg(arguments, "source"),
        item_id=optional_string_arg(arguments, "item_id"),
        relative_path=optional_string_arg(arguments, "relative_path"),
        objet_ref=optional_string_arg(arguments, "objet_ref"),
        object_id=optional_string_arg(arguments, "object_id"),
        provider=optional_string_arg(arguments, "provider"),
        provider_object_id=optional_string_arg(arguments, "provider_object_id"),
        provider_kind=optional_string_arg(arguments, "provider_kind"),
        ai_artifact_ref=optional_string_arg(arguments, "ai_artifact_ref"),
        runtime=optional_string_arg(arguments, "runtime"),
        artifact_kind=optional_string_arg(arguments, "artifact_kind"),
        expected_archive_id=optional_string_arg(arguments, "expected_archive_id"),
        expected_type=optional_string_arg(arguments, "expected_type"),
        profile_id=optional_string_arg(arguments, "profile_id"),
        source_role=optional_string_arg(arguments, "source_role") or archive_services.SOURCE_INTAKE_DEFAULT_ROLE,
        title=optional_string_arg(arguments, "title"),
        mime=optional_string_arg(arguments, "mime"),
        redact_local_paths=redact_local_paths,
        project_intake_receipt=optional_string_arg(arguments, "project_intake_receipt"),
    )
    add_mcp_redaction_warning(result, requested_redaction, redact_local_paths)
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"source_intake_plan: {state}.", result)


def tool_tiro_import_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is False:
        raise ToolError("tiro_import_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.tiro_import_plan,
        archive_root,
        manifest_path=require_string_arg(arguments, "manifest"),
        source=optional_string_arg(arguments, "source") or archive_services.TIRO_IMPORT_SOURCE,
        max_segments=int(arguments.get("max_segments", 1000)),
    )
    state = str(result.get("state") or ("passed" if result["ok"] else "blocked"))
    return tool_success_result(f"tiro_import_plan: {state}.", result)


def tool_archive_init(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        return tool_success_result(
            "archive_init: blocked.",
            {
                "ok": False,
                "dry_run": False,
                "state": "blocked",
                "lifecycle_action": "archive_init",
                "reason_codes": [
                    "compound_exact_human_approval_binding_required"
                ],
                "files_written": [],
                "private_values_echoed": False,
            },
        )
    archive_cli.require_yaml()
    archive_root = require_path_arg(arguments, "archive_root")
    archive_type = require_string_arg(arguments, "archive_type")
    archive_id = require_string_arg(arguments, "archive_id")
    principal_id = require_string_arg(arguments, "principal_id")
    principal_name = optional_string_arg(arguments, "principal_name")
    principal_kind = optional_string_arg(arguments, "principal_kind") or "person"
    name = optional_string_arg(arguments, "name")
    dry_run = bool(arguments.get("dry_run", True))

    template = archive_cli.TEMPLATES_ROOT / archive_type
    if archive_type not in {"personal", "company", "family"} or not template.is_dir():
        raise ToolError(f"Unknown archive_type: {archive_type}")
    if archive_root.exists() and any(archive_root.iterdir()):
        raise ToolError(f"Target must be empty or absent: {archive_root}")

    if dry_run:
        return tool_success_result(
            f"Would initialize {archive_type} archive at {archive_root}",
            {"archive_root": str(archive_root), "archive_type": archive_type, "dry_run": True},
        )

    raise AssertionError("archive_init_non_dry_run_must_fail_closed")


def tool_archive_onboarding_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    target_root = require_path_arg(arguments, "target_root")
    archive_type = require_string_arg(arguments, "archive_type")
    archive_id = require_string_arg(arguments, "archive_id")
    principal_id = require_string_arg(arguments, "principal_id")
    principal_name = optional_string_arg(arguments, "principal_name")
    principal_kind = optional_string_arg(arguments, "principal_kind") or archive_services.default_principal_kind_for_archive_type(archive_type)
    name = optional_string_arg(arguments, "name")
    provider_profile = optional_string_arg(arguments, "provider_profile") or "local_only"
    result = archive_services.onboarding_plan(
        target_root,
        archive_type=archive_type,
        archive_id=archive_id,
        principal_id=principal_id,
        principal_name=principal_name,
        principal_kind=principal_kind,
        name=name,
        provider_profile=provider_profile,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"archive_onboarding_plan: {state}.", result)


def tool_real_pilot_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    personal_root = require_path_arg(arguments, "personal_root")
    team_root = require_path_arg(arguments, "team_root")
    result = call_service(
        archive_services.real_pilot_plan,
        personal_root=personal_root,
        team_root=team_root,
        personal_archive_id=optional_string_arg(arguments, "personal_archive_id") or "archive:personal:life",
        personal_principal_id=optional_string_arg(arguments, "personal_principal_id") or "person:me",
        personal_principal_name=optional_string_arg(arguments, "personal_principal_name"),
        team_archive_id=optional_string_arg(arguments, "team_archive_id") or "archive:company:founding-team",
        team_principal_id=optional_string_arg(arguments, "team_principal_id") or "team:founding-team",
        team_principal_name=optional_string_arg(arguments, "team_principal_name"),
        personal_provider_profile=optional_string_arg(arguments, "personal_provider_profile") or "object_storage_planned",
        team_provider_profile=optional_string_arg(arguments, "team_provider_profile") or "full_provider_plan",
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"real_pilot_plan: {state}.", result)


def tool_archive_preflight_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    peer_value = optional_string_arg(arguments, "peer_archive")
    peer_archive = require_path_arg({"peer_archive": peer_value}, "peer_archive") if peer_value else None
    strict = bool(arguments.get("strict", False))
    diagnostics = [item.as_dict() for item in archive_cli.Doctor(archive_root).run()]
    result = call_service(
        archive_services.preflight_check,
        archive_root,
        diagnostics=diagnostics,
        peer_archive_root=peer_archive,
        require_source_maps=bool(arguments.get("require_source_maps", False)),
        require_restore_drill=bool(arguments.get("require_restore_drill", False)),
        strict=strict,
        docker_runtime={"checked": False, "ok": None, "status": "not_checked"},
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"archive_preflight_check: {state}.", result)


def tool_recovery_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.recovery_plan, archive_root)
    return tool_success_result(f"recovery_plan: {result['archive_id']}.", result)


def tool_restore_drill_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    target = require_path_arg(arguments, "target")
    result = call_service(archive_services.restore_drill_dry_run, archive_root, target)
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"restore_drill_plan: {state}.", result)


def tool_external_import_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    export_path = require_path_arg(arguments, "export_path")
    source = require_string_arg(arguments, "source")
    limit = int(arguments.get("limit", 200))
    result = call_service(
        archive_services.external_import_dry_run,
        archive_root,
        export_path,
        source_system=source,
        limit=limit,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"external_import_plan: {state}.", result)


def tool_connection_import_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("connection_import_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.connection_import_plan,
        archive_root,
        source=require_string_arg(arguments, "source"),
        connection_kind=optional_string_arg(arguments, "connection_kind") or "all",
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"connection_import_plan: {state}.", result)


def tool_connection_evidence_parser_contract(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("connection_evidence_parser_contract is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.connection_evidence_parser_contract,
        archive_root,
        source=require_string_arg(arguments, "source"),
        connection_kind=optional_string_arg(arguments, "connection_kind") or "all",
        dry_run=True,
    )
    state = result.get("contract_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"connection_evidence_parser_contract: {state}.", result)


def tool_connection_evidence_parse_fixture(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("connection_evidence_parse_fixture is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.connection_evidence_parse_fixture,
        archive_root,
        evidence_path=require_string_arg(arguments, "evidence"),
        source=require_string_arg(arguments, "source"),
        connection_kind=optional_string_arg(arguments, "connection_kind") or "all",
        max_items=int(arguments.get("max_items", 100)),
        dry_run=True,
    )
    state = result.get("parse_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"connection_evidence_parse_fixture: {state}.", result)


def tool_notion_nested_tree_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_nested_tree_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_nested_tree_plan,
        archive_root,
        tree_path=require_string_arg(arguments, "tree"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", 1000)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_nested_tree_plan: {state}.", result)


def tool_notion_ancestor_crawl_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_ancestor_crawl_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_ancestor_crawl_plan,
        archive_root,
        tree_path=require_string_arg(arguments, "tree"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", 1000)),
        max_depth=int(arguments.get("max_depth", 16)),
        scope_generation_ids=arguments.get("scope_generation_ids"),
        scope_root_refs=arguments.get("scope_root_refs"),
        scope_ancestor_refs=arguments.get("scope_ancestor_refs"),
        scope_leaf_refs=arguments.get("scope_leaf_refs"),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_ancestor_crawl_plan: {state}.", result)


def tool_notion_ancestor_fetch_adapter_execution_contract(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_ancestor_fetch_adapter_execution_contract is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_ancestor_fetch_adapter_execution_contract,
        archive_root,
        tree_path=require_string_arg(arguments, "tree"),
        source=require_string_arg(arguments, "source"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        max_items=int(arguments.get("max_items", 1000)),
        max_depth=int(arguments.get("max_depth", 16)),
        scope_generation_ids=arguments.get("scope_generation_ids"),
        scope_root_refs=arguments.get("scope_root_refs"),
        scope_ancestor_refs=arguments.get("scope_ancestor_refs"),
        scope_leaf_refs=arguments.get("scope_leaf_refs"),
        dry_run=True,
    )
    state = result.get("contract_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_ancestor_fetch_adapter_execution_contract: {state}.", result)


def tool_notion_media_fetch_adapter_execution_contract(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_media_fetch_adapter_execution_contract is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_media_fetch_adapter_execution_contract,
        archive_root,
        tree_path=require_string_arg(arguments, "tree"),
        source=require_string_arg(arguments, "source"),
        credential_ref=optional_string_arg(arguments, "credential_ref"),
        max_items=int(arguments.get("max_items", 1000)),
        scope_generation_ids=arguments.get("scope_generation_ids"),
        scope_root_refs=arguments.get("scope_root_refs"),
        scope_leaf_refs=arguments.get("scope_leaf_refs"),
        dry_run=True,
    )
    state = result.get("contract_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_media_fetch_adapter_execution_contract: {state}.", result)


def tool_notion_media_result_verification_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_media_result_verification_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_media_result_verification_plan,
        archive_root,
        media_result_path=require_string_arg(arguments, "media_result"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", 1000)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_media_result_verification_plan: {state}.", result)


def tool_notion_block_mirror_tree_fixture_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_block_mirror_tree_fixture_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_block_mirror_tree_fixture_plan,
        archive_root,
        mirror_path=require_string_arg(arguments, "mirror"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_block_mirror_tree_fixture_plan: {state}.", result)


def tool_notion_ancestor_merge_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_ancestor_merge_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_ancestor_merge_plan,
        archive_root,
        tree_path=require_string_arg(arguments, "tree"),
        ancestors_path=require_string_arg(arguments, "ancestors"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_ancestor_merge_plan: {state}.", result)


def tool_notion_client_issue_verification_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_client_issue_verification_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_client_issue_verification_plan,
        archive_root,
        tree_path=optional_string_arg(arguments, "tree"),
        mirror_path=optional_string_arg(arguments, "mirror"),
        ancestors_path=optional_string_arg(arguments, "ancestors"),
        source=require_string_arg(arguments, "source"),
        max_items=int(arguments.get("max_items", archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT)),
        max_depth=int(arguments.get("max_depth", 16)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_client_issue_verification_plan: {state}.", result)


def tool_notion_client_fixture_request_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_client_fixture_request_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_client_fixture_request_plan,
        archive_root,
        tree_path=optional_string_arg(arguments, "tree"),
        mirror_path=optional_string_arg(arguments, "mirror"),
        ancestors_path=optional_string_arg(arguments, "ancestors"),
        source=require_string_arg(arguments, "source"),
        scenario=optional_string_arg(arguments, "scenario") or "missing_ancestor",
        max_items=int(arguments.get("max_items", archive_services.NOTION_NESTED_TREE_MAX_ITEMS_LIMIT)),
        max_depth=int(arguments.get("max_depth", 16)),
        dry_run=True,
    )
    state = result.get("plan_state") or ("passed" if result["ok"] else "blocked")
    return tool_success_result(f"notion_client_fixture_request_plan: {state}.", result)


def tool_list_sources(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.list_sources, archive_root)
    return tool_success_result(f"Found {result['source_count']} source(s).", result)


def tool_source_scan_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    source = require_string_arg(arguments, "source")
    source_root_value = optional_string_arg(arguments, "source_root")
    source_root = require_path_arg({"source_root": source_root_value}, "source_root") if source_root_value else None
    limit = int(arguments.get("limit", 2000))
    result = call_service(
        archive_services.source_scan_dry_run,
        archive_root,
        source_id=source,
        source_root=source_root,
        limit=limit,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"source_scan_plan: {state}.", result)


def tool_source_registration_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    local_root_value = optional_string_arg(arguments, "local_root")
    local_root = require_path_arg({"local_root": local_root_value}, "local_root") if local_root_value else None
    result = call_service(
        archive_services.add_source_dry_run,
        archive_root,
        source_id=require_string_arg(arguments, "source_id"),
        source_type=require_string_arg(arguments, "source_type"),
        description=optional_string_arg(arguments, "description"),
        root_ref=optional_string_arg(arguments, "root_ref"),
        local_root=local_root,
        write_local_profile=bool(arguments.get("write_local_profile", False)),
        include=optional_string_list_arg(arguments, "include"),
        exclude=optional_string_list_arg(arguments, "exclude"),
        max_items=int(arguments.get("max_items", 2000)),
        visibility_scope=optional_string_arg(arguments, "visibility_scope") or "private",
        source_visibility=optional_string_arg(arguments, "source_visibility") or "private",
        replace=bool(arguments.get("replace", False)),
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"source_registration_plan: {state}.", result)


def tool_source_mount_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.source_mount_plan, archive_root)
    return tool_success_result(f"source_mount_plan: {len(result['sources'])} source(s).", result)


def tool_list_zettels(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    status = optional_string_arg(arguments, "status") or "canonical"
    limit = int(arguments.get("limit", 100))
    result = call_service(archive_services.list_zettels, archive_root, status=status, limit=limit)

    return tool_success_result(
        f"Found {result['count']} zettel(s).",
        result,
    )


def tool_zet_catalog(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_catalog is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    status = optional_string_arg(arguments, "status") or "canonical"
    projection = optional_string_arg(arguments, "projection") or "full"
    coverage_mode = optional_string_arg(arguments, "coverage_mode") or "page"
    order_mode = optional_string_arg(arguments, "order") or "path"
    raw_start_zettel_ids = arguments.get("start_zettel_ids")
    start_zettel_ids = (
        [str(value) for value in raw_start_zettel_ids]
        if isinstance(raw_start_zettel_ids, list)
        else []
    )
    max_estimated_tokens_value = arguments.get("max_estimated_tokens")
    max_estimated_tokens = int(max_estimated_tokens_value) if max_estimated_tokens_value is not None else None
    response_envelope_reserve_tokens = int(arguments.get("response_envelope_reserve_tokens", 0))
    response_profile = optional_string_arg(arguments, "response_profile") or "full"
    result = call_service(
        archive_services.zet_catalog,
        archive_root,
        status=status,
        projection=projection,
        coverage_mode=coverage_mode,
        order_mode=order_mode,
        start_zettel_ids=start_zettel_ids,
        cursor=int(arguments.get("cursor", 0)),
        page_size=int(arguments.get("page_size", 200)),
        max_estimated_tokens=max_estimated_tokens,
        response_envelope_reserve_tokens=response_envelope_reserve_tokens,
        response_profile=response_profile,
        expected_snapshot_id=optional_string_arg(arguments, "expected_snapshot_id"),
        continuation_token=optional_string_arg(arguments, "continuation_token"),
        dry_run=True,
        item_cache=zet_catalog_item_cache(archive_root, status),
        materialize_session_snapshot=True,
    )
    coverage = result.get("coverage") if isinstance(result.get("coverage"), dict) else {}
    if not result.get("ok"):
        state = "blocked"
    elif not coverage.get("complete"):
        state = "more_pages"
    elif not coverage.get("archive_wide_coverage_claim_ready"):
        state = "page_complete_without_strict_claim"
    elif coverage.get("archive_wide_abstract_reading_claim_ready"):
        state = "node_and_abstract_complete"
    else:
        state = "node_complete_with_abstract_gaps"
    return tool_success_result(
        f"zet_catalog: {state}, {coverage.get('returned_count', 0)} returned, {coverage.get('remaining_count', 0)} remaining.",
        result,
    )


def tool_first_read_readiness(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("first_read_readiness is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.first_read_readiness,
        archive_root,
        dry_run=True,
        max_items=int(arguments.get("max_items", 100)),
        item_cache=zet_catalog_item_cache(archive_root, "canonical"),
    )
    return tool_success_result(
        "first_read_readiness: "
        f"{result.get('state', 'unknown')}, {result.get('canonical_zet_count', 0)} canonical zet(s) checked.",
        result,
    )


def tool_abstract_freshness(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("abstract_freshness is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.abstract_freshness,
        archive_root,
        dry_run=True,
        max_items=int(arguments.get("max_items", 100)),
    )
    return tool_success_result(
        "abstract_freshness: "
        f"{result.get('state', 'unknown')}, {result.get('canonical_zet_count', 0)} canonical zet(s) checked, "
        f"{result.get('attention', {}).get('total_count', 0)} need review.",
        result,
    )


def tool_zet_revision_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_revision_plan is dry-run only.")
    try:
        result = call_service(
            archive_services.zet_revision_plan,
            require_path_arg(arguments, "archive_root"),
            zettel_id=require_string_arg(arguments, "zettel_id"),
            proposal_path=require_string_arg(arguments, "proposal_path"),
            dry_run=True,
        )
    except ToolError as exc:
        raise ToolError(
            "zet_revision_plan could not read one safe canonical zet and private revision proposal."
        ) from exc
    return tool_success_result(
        "zet_revision_plan: "
        f"{result.get('status', 'unknown')}; canonical files changed: no.",
        result,
    )


def tool_read_zettel(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    body_cursor = arguments.get("body_cursor", 0)
    if isinstance(body_cursor, bool) or not isinstance(body_cursor, int):
        raise ToolError("body_cursor must be a non-negative integer.")
    body_max_chars = arguments.get("body_max_chars")
    if body_max_chars is not None and (isinstance(body_max_chars, bool) or not isinstance(body_max_chars, int)):
        raise ToolError("body_max_chars must be an integer.")
    result = call_service(
        archive_services.read_zettel,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        section=optional_string_arg(arguments, "section") or "body",
        body_cursor=body_cursor,
        body_max_chars=body_max_chars,
        expected_body_sha256=optional_string_arg(arguments, "expected_body_sha256"),
    )
    frontmatter = result["frontmatter"]
    return tool_success_result(
        f"Read zettel {frontmatter.get('id', result['path']) if isinstance(frontmatter, dict) else result['path']}.",
        result,
    )


def tool_zettel_objet_links(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zettel_objet_links is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.zettel_objet_links,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        dry_run=True,
        max_refs=int(arguments.get("max_refs", 100)),
    )
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(f"zettel_objet_links: {state}, {result['count']} link(s).", result)


def tool_zettel_objet_link_receipts(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zettel_objet_link_receipts is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    max_receipts = arguments.get("max_receipts", 100)
    if isinstance(max_receipts, bool) or not isinstance(max_receipts, int):
        raise ToolError("max_receipts must be an integer.")
    result = call_service(
        completion_workflows.zettel_objet_link_receipts,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        object_id=optional_string_arg(arguments, "object_id"),
        role=optional_string_arg(arguments, "role"),
        dry_run=True,
        max_receipts=max_receipts,
    )
    summary = (
        result.get("summary")
        if isinstance(result.get("summary"), dict)
        else {}
    )
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        (
            "zettel_objet_link_receipts: "
            f"{state}, {summary.get('validated_receipt_count', 0)} "
            "validated receipt(s)."
        ),
        result,
    )


def tool_notion_objet_link_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_objet_link_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.notion_objet_link_plan,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        dry_run=True,
        max_locators=int(arguments.get("max_locators", 100)),
        max_candidates=int(arguments.get("max_candidates", 20)),
    )
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(f"notion_objet_link_plan: {state}, {result['locator_count']} locator(s).", result)


def tool_notion_objet_link_index(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_objet_link_index is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.notion_objet_link_index,
        archive_root,
        dry_run=True,
        max_zettels=int(arguments.get("max_zettels", 50)),
        max_locators_per_zettel=int(arguments.get("max_locators_per_zettel", 20)),
        max_candidates=int(arguments.get("max_candidates", 5)),
    )
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        "notion_objet_link_index: "
        f"{state}, {summary.get('zettels_with_locator_count', 0)} zettel(s), "
        f"{summary.get('zettel_locator_rows_with_manifest_candidate_count', 0)} matched locator row(s).",
        result,
    )


def tool_notion_objet_source_map_link_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_objet_source_map_link_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    source_maps = arguments.get("source_maps")
    ledgers = arguments.get("ledgers")
    if source_maps is not None and not isinstance(source_maps, list):
        raise ToolError("source_maps must be an array when provided.")
    if ledgers is not None and not isinstance(ledgers, list):
        raise ToolError("ledgers must be an array when provided.")
    result = call_service(
        archive_services.notion_objet_source_map_link_plan,
        archive_root,
        source_maps=[str(item) for item in source_maps or []],
        ledgers=[str(item) for item in ledgers or []],
        dry_run=True,
        max_rows=int(arguments.get("max_rows", 10000)),
        max_candidates=int(arguments.get("max_candidates", 200)),
    )
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        "notion_objet_source_map_link_plan: "
        f"{state}, {summary.get('candidate_count', 0)} candidate(s), "
        f"{summary.get('source_map_record_count', 0)} source-map row(s).",
        result,
    )


def tool_notion_objet_import_clue_audit(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_objet_import_clue_audit is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    source_maps = arguments.get("source_maps")
    ledgers = arguments.get("ledgers")
    if source_maps is not None and not isinstance(source_maps, list):
        raise ToolError("source_maps must be an array when provided.")
    if ledgers is not None and not isinstance(ledgers, list):
        raise ToolError("ledgers must be an array when provided.")
    result = call_service(
        archive_services.notion_objet_import_clue_audit,
        archive_root,
        source_maps=[str(item) for item in source_maps or []],
        ledgers=[str(item) for item in ledgers or []],
        dry_run=True,
        max_rows=int(arguments.get("max_rows", 10000)),
        max_zettels=int(arguments.get("max_zettels", 500)),
        max_candidates=int(arguments.get("max_candidates", 1000)),
    )
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        "notion_objet_import_clue_audit: "
        f"{state}, {summary.get('notion_import_zettel_count', 0)} Notion import zettel(s), "
        f"{summary.get('missing_material_clue_after_locator_omission_count', 0)} missing material clue(s).",
        result,
    )


def tool_notion_objet_link_rewrite_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("notion_objet_link_rewrite_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    expected_occurrence_count = arguments.get("expected_occurrence_count")
    result = call_service(
        archive_services.notion_objet_link_rewrite_plan,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        locator_fingerprint=require_string_arg(arguments, "locator_fingerprint"),
        object_id=require_string_arg(arguments, "object_id"),
        target_mode=str(arguments.get("target_mode") or "objet_ref_rewrite"),
        expected_occurrence_count=int(expected_occurrence_count) if expected_occurrence_count is not None else None,
        dry_run=True,
    )
    state = "passed" if result.get("ok") else "blocked"
    locator = result.get("selected_locator") if isinstance(result.get("selected_locator"), dict) else {}
    return tool_success_result(
        "notion_objet_link_rewrite_plan: "
        f"{state}, {locator.get('occurrence_count', 0)} selected occurrence(s), "
        f"{len(result.get('would_change') or [])} planned change(s).",
        result,
    )


def tool_facet_vocabulary(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("facet_vocabulary is read-only and requires dry_run=true.")
    result = call_service(
        archive_services.facet_vocabulary,
        archive_root,
        dry_run=True,
    )
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(f"facet_vocabulary: {state}.", result)


def tool_view_health(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("view_health is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.view_health,
        archive_root,
        dry_run=True,
        max_values=int(arguments.get("max_values", 10)),
    )
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    role_summary = result.get("facet_role_summary") if isinstance(result.get("facet_role_summary"), dict) else {}
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        "view_health: "
        f"{state}, {summary.get('active_view_count', 0)} active, "
        f"{summary.get('empty_view_count', 0)} empty, "
        f"{role_summary.get('internal_key_count', 0)} internal facet key(s).",
        result,
    )


def tool_view_recommendation_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("view_recommendation_plan is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.view_recommendation_plan,
        archive_root,
        dry_run=True,
        max_values=int(arguments.get("max_values", 5)),
        max_recommendations=int(arguments.get("max_recommendations", 12)),
    )
    summary = result.get("summary") if isinstance(result.get("summary"), dict) else {}
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(
        "view_recommendation_plan: "
        f"{state}, {summary.get('recommendation_count', 0)} recommendation(s), "
        f"{summary.get('navigation_key_count', 0)} navigation key(s).",
        result,
    )


def tool_index_health(arguments: dict[str, Any]) -> dict[str, Any]:
    if arguments.get("dry_run", True) is not True:
        raise ToolError("index_health is dry-run only.")
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(
        archive_services.index_health,
        archive_root,
        dry_run=True,
        max_items=int(arguments.get("max_items", 50)),
    )
    state = "passed" if result.get("ok") else "blocked"
    return tool_success_result(f"index_health: {state}, {result.get('index_state')}.", result)


def tool_block_header_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.block_header_preview,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
        dry_run=bool(arguments.get("dry_run", True)),
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"block_header_check: {state}.", result)


def tool_zet_projection_plan_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_projection_plan_check is dry-run only.")
    result = call_service(
        archive_services.zet_projection_plan_preview,
        archive_root,
        zet_ref=require_string_arg(arguments, "zet"),
        surface=require_string_arg(arguments, "surface"),
        dry_run=True,
        visibility=optional_string_arg(arguments, "visibility") or "unknown",
        projection_format=optional_string_arg(arguments, "projection_format") or "metadata_only",
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"zet_projection_plan_check: {state}.", result)


def tool_zet_shared_update_record_review_preview(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_shared_update_record_review_preview is dry-run only.")
    result = call_service(
        archive_services.zet_shared_update_record_review_preview,
        archive_root,
        record=require_string_arg(arguments, "record"),
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"zet_shared_update_record_review_preview: {state}.", result)


def tool_zet_shared_update_record_review_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_shared_update_record_review_index is dry-run only.")
    limit = arguments.get("limit", archive_services.ZET_SHARED_UPDATE_REVIEW_INDEX_MAX_LIMIT)
    if isinstance(limit, bool) or not isinstance(limit, int):
        raise ToolError("limit must be an integer between 1 and 100.")
    result = call_service(
        archive_services.zet_shared_update_record_review_index,
        archive_root,
        records_dir=require_string_arg(arguments, "records_dir"),
        dry_run=True,
        limit=limit,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"zet_shared_update_record_review_index: {state}.", result)


def tool_zet_transport_would_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("zet_transport_would_plan is dry-run only.")
    result = call_service(
        archive_services.zet_transport_would_plan,
        archive_root,
        record=require_string_arg(arguments, "record"),
        method=require_string_arg(arguments, "method"),
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"zet_transport_would_plan: {state}.", result)


def tool_foreign_block_intake_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_intake_check is dry-run only.")
    content = arguments.get("content") if isinstance(arguments.get("content"), dict) else None
    if "content" in arguments and content is None:
        raise ToolError("foreign_block_intake_check content must be a structured object.")
    text = optional_string_arg(arguments, "text")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.foreign_block_intake_check,
        archive_root,
        relative_path=relative_path,
        text=text,
        content=content,
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_intake_check: {state}.", result)


def tool_foreign_block_trust_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_trust_check is dry-run only.")
    intake_report = arguments.get("intake_report") if isinstance(arguments.get("intake_report"), dict) else None
    if "intake_report" in arguments and intake_report is None:
        raise ToolError("foreign_block_trust_check intake_report must be a structured object.")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.foreign_block_trust_preview,
        archive_root,
        intake_report_path=relative_path,
        intake_report=intake_report,
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_trust_check: {state}.", result)


def tool_foreign_block_attestation_packet_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_packet_check is dry-run only.")
    trust_report = arguments.get("trust_report") if isinstance(arguments.get("trust_report"), dict) else None
    if "trust_report" in arguments and trust_report is None:
        raise ToolError("foreign_block_attestation_packet_check trust_report must be a structured object.")
    relative_path = optional_string_arg(arguments, "path")
    prospective_attestor = optional_string_arg(arguments, "prospective_attestor")
    review_scope = optional_string_arg(arguments, "review_scope") or "human_review"
    result = call_service(
        archive_services.foreign_block_attestation_packet_preview,
        archive_root,
        trust_report_path=relative_path,
        trust_report=trust_report,
        dry_run=True,
        prospective_attestor=prospective_attestor,
        review_scope=review_scope,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_packet_check: {state}.", result)


def tool_foreign_block_quarantine_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_quarantine_plan is dry-run only.")
    attestation_packet = arguments.get("attestation_packet") if isinstance(arguments.get("attestation_packet"), dict) else None
    if "attestation_packet" in arguments and attestation_packet is None:
        raise ToolError("foreign_block_quarantine_plan attestation_packet must be a structured object.")
    relative_path = optional_string_arg(arguments, "path")
    quarantine_case_id = optional_string_arg(arguments, "quarantine_case_id")
    reviewer = optional_string_arg(arguments, "reviewer")
    quarantine_policy = optional_string_arg(arguments, "quarantine_policy") or archive_services.FOREIGN_BLOCK_QUARANTINE_DEFAULT_POLICY
    result = call_service(
        archive_services.foreign_block_quarantine_plan,
        archive_root,
        attestation_packet_path=relative_path,
        attestation_packet=attestation_packet,
        dry_run=True,
        quarantine_case_id=quarantine_case_id,
        reviewer=reviewer,
        quarantine_policy=quarantine_policy,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_quarantine_plan: {state}.", result)


def tool_quarantine_foreign_block_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("quarantine_foreign_block_check is dry-run only.")
    quarantine_plan = arguments.get("quarantine_plan") if isinstance(arguments.get("quarantine_plan"), dict) else None
    if "quarantine_plan" in arguments and quarantine_plan is None:
        raise ToolError("quarantine_plan must be a structured object.")
    relative_path = optional_string_arg(arguments, "path")
    expected_case_id = optional_string_arg(arguments, "expected_case_id")
    reviewed_by = optional_string_arg(arguments, "reviewed_by")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.quarantine_foreign_block,
        archive_root,
        plan_path=relative_path,
        plan=quarantine_plan,
        dry_run=True,
        approve=False,
        reviewed_by=reviewed_by,
        expected_case_id=expected_case_id,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"quarantine_foreign_block_check: {state}.", result)


def tool_foreign_block_quarantine_review_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_quarantine_review_index is dry-run only.")
    case_id = optional_string_arg(arguments, "case_id")
    status = optional_string_arg(arguments, "status") or "written_untrusted"
    include_receipts = bool(arguments.get("include_receipts", False))
    result = call_service(
        archive_services.foreign_block_quarantine_review_index,
        archive_root,
        case_id=case_id,
        status=status,
        include_receipts=include_receipts,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_quarantine_review_index: {state}.", result)


def tool_foreign_block_quarantine_decision_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_quarantine_decision_check is dry-run only.")
    case_id = require_string_arg(arguments, "case_id")
    decision_intent = optional_string_arg(arguments, "decision_intent") or "auto"
    reviewer = optional_string_arg(arguments, "reviewer")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.foreign_block_quarantine_decision_preview,
        archive_root,
        case_id=case_id,
        decision_intent=decision_intent,
        reviewer=reviewer,
        review_note=review_note,
        dry_run=True,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_quarantine_decision_check: {state}.", result)


def tool_record_quarantine_decision_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("record_quarantine_decision_check is dry-run only.")
    if arguments.get("approve") is not None:
        raise ToolError("record_quarantine_decision_check does not approve or write.")
    decision_preview = arguments.get("decision_preview")
    if decision_preview is not None and not isinstance(decision_preview, dict):
        raise ToolError("decision_preview must be a structured object.")
    path = optional_string_arg(arguments, "path")
    expected_case_id = optional_string_arg(arguments, "expected_case_id")
    expected_decision = optional_string_arg(arguments, "expected_decision")
    reviewed_by = optional_string_arg(arguments, "reviewed_by")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.record_quarantine_decision,
        archive_root,
        decision_preview_path=path,
        decision_preview=decision_preview,
        dry_run=True,
        approve=False,
        reviewed_by=reviewed_by,
        expected_case_id=expected_case_id,
        expected_decision=expected_decision,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"record_quarantine_decision_check: {state}.", result)


def tool_foreign_block_quarantine_decision_review_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_quarantine_decision_review_index is dry-run only.")
    case_id = optional_string_arg(arguments, "case_id")
    decision = optional_string_arg(arguments, "decision") or "all"
    include_receipts = bool(arguments.get("include_receipts", False))
    result = call_service(
        archive_services.foreign_block_quarantine_decision_review_index,
        archive_root,
        case_id=case_id,
        decision=decision,
        include_receipts=include_receipts,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_quarantine_decision_review_index: {state}.", result)


def tool_foreign_block_decision_outcome_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_decision_outcome_plan is dry-run only.")
    case_id = require_string_arg(arguments, "case_id")
    expected_decision = optional_string_arg(arguments, "expected_decision")
    reviewer = optional_string_arg(arguments, "reviewer")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.foreign_block_decision_outcome_plan,
        archive_root,
        case_id=case_id,
        dry_run=True,
        expected_decision=expected_decision,
        reviewer=reviewer,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_decision_outcome_plan: {state}.", result)


def tool_foreign_block_attestation_review_candidate_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_review_candidate_plan is dry-run only.")
    case_id = require_string_arg(arguments, "case_id")
    expected_decision = optional_string_arg(arguments, "expected_decision")
    expected_outcome = optional_string_arg(arguments, "expected_outcome")
    prospective_attestor = optional_string_arg(arguments, "prospective_attestor")
    review_scope = optional_string_arg(arguments, "review_scope") or "full_human_review"
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.foreign_block_attestation_review_candidate_plan,
        archive_root,
        case_id=case_id,
        dry_run=True,
        expected_decision=expected_decision,
        expected_outcome=expected_outcome,
        prospective_attestor=prospective_attestor,
        review_scope=review_scope,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_review_candidate_plan: {state}.", result)


def tool_record_attestation_review_candidate_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("record_attestation_review_candidate_check is dry-run only.")
    if arguments.get("approve") is not None:
        raise ToolError("record_attestation_review_candidate_check does not approve or write.")
    candidate_plan = arguments.get("candidate_plan")
    if candidate_plan is not None and not isinstance(candidate_plan, dict):
        raise ToolError("candidate_plan must be a structured object.")
    path = optional_string_arg(arguments, "path")
    expected_case_id = optional_string_arg(arguments, "expected_case_id")
    expected_review_scope = optional_string_arg(arguments, "expected_review_scope")
    expected_attestor = optional_string_arg(arguments, "expected_attestor")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.record_attestation_review_candidate,
        archive_root,
        candidate_plan_path=path,
        candidate_plan=candidate_plan,
        dry_run=True,
        approve=False,
        reviewed_by=None,
        expected_case_id=expected_case_id,
        expected_review_scope=expected_review_scope,
        expected_attestor=expected_attestor,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"record_attestation_review_candidate_check: {state}.", result)


def tool_foreign_block_attestation_review_candidate_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_review_candidate_index is dry-run only.")
    case_id = optional_string_arg(arguments, "case_id")
    review_scope = optional_string_arg(arguments, "review_scope") or "all"
    include_receipts = bool(arguments.get("include_receipts", False))
    result = call_service(
        archive_services.foreign_block_attestation_review_candidate_index,
        archive_root,
        case_id=case_id,
        review_scope=review_scope,
        include_receipts=include_receipts,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_review_candidate_index: {state}.", result)


def tool_foreign_block_attestation_statement_draft_preview(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_statement_draft_preview is dry-run only.")
    case_id = require_string_arg(arguments, "case_id")
    expected_review_scope = optional_string_arg(arguments, "expected_review_scope")
    prospective_attestor = optional_string_arg(arguments, "prospective_attestor")
    statement_style = optional_string_arg(arguments, "statement_style") or "minimal"
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.foreign_block_attestation_statement_draft_preview,
        archive_root,
        case_id=case_id,
        dry_run=True,
        expected_review_scope=expected_review_scope,
        prospective_attestor=prospective_attestor,
        statement_style=statement_style,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_statement_draft_preview: {state}.", result)


def tool_record_attestation_statement_draft_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("record_attestation_statement_draft_check is dry-run only.")
    if arguments.get("approve") is not None:
        raise ToolError("record_attestation_statement_draft_check does not approve or write.")
    draft_preview = arguments.get("draft_preview")
    if draft_preview is not None and not isinstance(draft_preview, dict):
        raise ToolError("draft_preview must be a structured object.")
    path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.record_attestation_statement_draft,
        archive_root,
        draft_preview_path=path,
        draft_preview=draft_preview,
        dry_run=True,
        approve=False,
        reviewed_by=None,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"record_attestation_statement_draft_check: {state}.", result)


def tool_foreign_block_attestation_statement_draft_review_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_statement_draft_review_index is dry-run only.")
    case_id = optional_string_arg(arguments, "case_id")
    statement_style = optional_string_arg(arguments, "statement_style") or "all"
    review_scope = optional_string_arg(arguments, "review_scope") or "all"
    include_receipts = bool(arguments.get("include_receipts", False))
    result = call_service(
        archive_services.foreign_block_attestation_statement_draft_review_index,
        archive_root,
        case_id=case_id,
        statement_style=statement_style,
        review_scope=review_scope,
        include_receipts=include_receipts,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_statement_draft_review_index: {state}.", result)


def tool_foreign_block_attestation_statement_draft_decision_preview(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    if arguments.get("dry_run", True) is not True:
        raise ToolError("foreign_block_attestation_statement_draft_decision_preview is dry-run only.")
    case_id = require_string_arg(arguments, "case_id")
    decision_intent = optional_string_arg(arguments, "decision_intent") or "needs_more_review"
    reviewer = optional_string_arg(arguments, "reviewer")
    expected_review_scope = optional_string_arg(arguments, "expected_review_scope")
    expected_statement_style = optional_string_arg(arguments, "expected_statement_style")
    review_note = optional_string_arg(arguments, "review_note")
    result = call_service(
        archive_services.foreign_block_attestation_statement_draft_decision_preview,
        archive_root,
        case_id=case_id,
        dry_run=True,
        decision_intent=decision_intent,
        reviewer=reviewer,
        expected_review_scope=expected_review_scope,
        expected_statement_style=expected_statement_style,
        review_note=review_note,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"foreign_block_attestation_statement_draft_decision_preview: {state}.", result)


def tool_create_draft_zettel(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    title = require_string_arg(arguments, "title")
    creation_mode = optional_string_arg(arguments, "creation_mode") or "ai_assisted"
    if creation_mode not in {"ai_assisted", "ai_generated"}:
        raise ToolError()
    requested_assisted_by = optional_string_list_arg(arguments, "assisted_by")
    if requested_assisted_by not in (None, ["ai_runtime:mcp"]):
        raise ToolError()
    source_fidelity_mode = optional_string_arg(arguments, "source_fidelity_mode")
    if (
        source_fidelity_mode is not None
        and source_fidelity_mode not in archive_services.SOURCE_FIDELITY_MODES
    ):
        raise ToolError()
    source_fidelity_audience = optional_string_arg(arguments, "source_fidelity_audience")
    if (
        source_fidelity_audience is not None
        and source_fidelity_audience not in archive_services.ZET_QUALITY_AUDIENCES
    ):
        raise ToolError()
    raw_body = arguments.get("body")
    if raw_body in (None, "") and source_fidelity_mode == "verbatim":
        body = ""
    elif not isinstance(raw_body, str) or not raw_body:
        raise ToolError()
    else:
        body = raw_body

    raw_dry_run = arguments.get("dry_run", True)
    raw_approved = arguments.get("approved", False)
    if not isinstance(raw_dry_run, bool) or not isinstance(raw_approved, bool):
        raise ToolError()
    dry_run = raw_dry_run
    approved = raw_approved
    if dry_run == approved:
        raise ToolError()
    if approved:
        return tool_success_result(
            "create_draft_zettel: blocked.",
            {
                "ok": False,
                "dry_run": False,
                "lifecycle_action": "create_draft",
                "state": "blocked",
                "reason_codes": ["exact_human_approval_cli_required"],
                "private_values_echoed": False,
            },
        )

    draft_id = optional_string_arg(arguments, "draft_id")
    created_at = optional_string_arg(arguments, "created_at")
    if approved and not all(
        isinstance(value, str) and value.strip()
        for value in (draft_id, created_at)
    ):
        return tool_success_result(
            "create_draft_zettel: blocked.",
            {
                "ok": False,
                "dry_run": False,
                "lifecycle_action": "create_draft",
                "state": "blocked",
                "reason_codes": [
                    "create_draft_ai_replay_identity_required"
                ],
                "private_values_echoed": False,
            },
        )

    expected_body_sha256 = optional_string_arg(arguments, "expected_body_sha256")
    draft_approved_by = optional_string_arg(arguments, "draft_approved_by")
    expected_source_fidelity_plan_sha256 = optional_string_arg(
        arguments,
        "expected_source_fidelity_plan_sha256",
    )
    if approved and not all(
        isinstance(value, str) and value.strip()
        for value in (
            draft_approved_by,
            expected_body_sha256,
            expected_source_fidelity_plan_sha256,
        )
    ):
        raise ToolError()

    archive_id = optional_string_arg(arguments, "archive_id")
    kind = optional_string_arg(arguments, "kind") or "fleeting_capture"
    facets = arguments.get("facets") if isinstance(arguments.get("facets"), dict) else {}
    visibility = arguments.get("visibility") if isinstance(arguments.get("visibility"), dict) else None
    profile_context = arguments.get("profile_context") if isinstance(arguments.get("profile_context"), dict) else {}
    source_refs = arguments.get("source_refs") if isinstance(arguments.get("source_refs"), list) else []
    if "source_intake_plan" in arguments and not isinstance(arguments.get("source_intake_plan"), dict):
        raise ToolError("source_intake_plan must be a structured object, not a local file path.")
    source_intake_plan = arguments.get("source_intake_plan") if isinstance(arguments.get("source_intake_plan"), dict) else None
    if "prompt_boundary_report" in arguments and not isinstance(arguments.get("prompt_boundary_report"), dict):
        raise ToolError("prompt_boundary_report must be a structured object, not a local file path.")
    prompt_boundary_report = (
        arguments.get("prompt_boundary_report") if isinstance(arguments.get("prompt_boundary_report"), dict) else None
    )
    local_ai_sessions = arguments.get("local_ai_sessions") if isinstance(arguments.get("local_ai_sessions"), list) else []
    created_by = optional_string_arg(arguments, "created_by") or "mcp:zettel-kasten-archive-mcp"
    source = optional_string_arg(arguments, "source") or "mcp_tool_call"
    fidelity_source_object_id = optional_string_arg(
        arguments, "fidelity_source_object_id"
    )
    fidelity_session_evidence_id = optional_string_arg(
        arguments, "fidelity_session_evidence_id"
    )
    if bool(fidelity_source_object_id) == bool(
        fidelity_session_evidence_id
    ):
        raise ToolError()
    result = call_service(
        archive_services.create_draft_zettel,
        archive_root,
        title=title,
        body=body,
        abstract=optional_string_arg(arguments, "abstract"),
        archive_id=archive_id,
        kind=kind,
        facets=facets,
        visibility=visibility,
        created_by=created_by,
        source=source,
        dry_run=dry_run,
        expected_archive_id=optional_string_arg(arguments, "expected_archive_id"),
        expected_type=optional_string_arg(arguments, "expected_type"),
        profile_id=profile_context.get("profile_id") if isinstance(profile_context.get("profile_id"), str) else None,
        profile_operator_id=(
            profile_context.get("operator_id")
            if isinstance(profile_context.get("operator_id"), str)
            else profile_context.get("profile_operator_id")
            if isinstance(profile_context.get("profile_operator_id"), str)
            else None
        ),
        profile_authority_mode=(
            profile_context.get("authority_mode")
            if isinstance(profile_context.get("authority_mode"), str)
            else profile_context.get("profile_authority_mode")
            if isinstance(profile_context.get("profile_authority_mode"), str)
            else None
        ),
        creation_mode=creation_mode,
        assisted_by=["ai_runtime:mcp"],
        supervised_by=optional_string_list_arg(arguments, "supervised_by"),
        derived_from=optional_string_list_arg(arguments, "derived_from"),
        source_refs=source_refs,
        source_intake_plan=source_intake_plan,
        prompt_boundary_report=prompt_boundary_report,
        local_ai_sessions=local_ai_sessions,
        draft_id=draft_id,
        created_at=created_at,
        expected_body_sha256=expected_body_sha256,
        draft_approved_by=draft_approved_by,
        approved=approved,
        source_fidelity_mode=source_fidelity_mode,
        source_fidelity_audience=source_fidelity_audience,
        fidelity_source_object_id=fidelity_source_object_id,
        fidelity_session_evidence_id=fidelity_session_evidence_id,
        expected_source_fidelity_plan_sha256=(
            expected_source_fidelity_plan_sha256
        ),
    )

    if result.get("dry_run"):
        state = "passed" if result.get("ok") else "blocked"
        return tool_success_result(f"create_draft_zettel dry-run: {state}.", result)
    state = "recorded" if result.get("ok", True) else "blocked"
    return tool_success_result(f"create_draft_zettel: {state}.", result)


def tool_list_views(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.list_views, archive_root)
    return tool_success_result(f"Found {result['count']} view(s).", result)


def tool_archive_index(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    result = call_service(archive_services.index_archive, archive_root)
    return tool_success_result(
        "Indexed "
        f"{result['zettels']} zettel(s), "
        f"{result['objects']} object(s), "
        f"{result['views']} view(s), "
        f"{result['source_map_entries']} source map item(s).",
        result,
    )


def tool_archive_search(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    query = require_string_arg(arguments, "query")
    limit = int(arguments.get("limit", 20))
    count_total = bool(arguments.get("count_total", False))
    result = call_service(
        archive_services.search_archive,
        archive_root,
        query,
        limit=limit,
        count_total=count_total,
    )
    # Reporting only the returned count reads as a complete answer, which is how
    # a host AI concludes "that is all there is" from a truncated page.
    if not result["truncated"]:
        summary = f"Found {result['total_matches']} result(s); this is the complete match set."
    elif result["total_matches_known"]:
        summary = (
            f"Returned {result['returned']} of {result['total_matches']} match(es); "
            f"more matches exist beyond the requested limit."
        )
    else:
        summary = (
            f"Returned {result['returned']} match(es); more matches exist beyond the requested "
            f"limit. Call again with count_total for the exact number."
        )
    return tool_success_result(summary, result)


def tool_objet_rediscovery_plan(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    raw_query = arguments.get("query")
    query = (
        raw_query
        if isinstance(raw_query, str)
        else require_string_arg(arguments, "query")
    )
    limit = int(arguments.get("limit", 20))
    count_total = bool(arguments.get("count_total", False))
    dry_run = arguments.get("dry_run") is True
    result = call_service(
        archive_services.objet_rediscovery_plan,
        archive_root,
        query,
        dry_run=dry_run,
        limit=limit,
        count_total=count_total,
    )
    if result.get("status") == "search_incomplete":
        summary = "SEARCH INCOMPLETE. No global absence claim is supported."
    else:
        summary = "Objet rediscovery plan blocked safely."
    return tool_success_result(summary, result)


def tool_promotion_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.promote_zettel_dry_run,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"promotion_check: {state}.", result)


def tool_mint_zettel_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    zettel_id = optional_string_arg(arguments, "zettel_id")
    relative_path = optional_string_arg(arguments, "path")
    result = call_service(
        archive_services.mint_zettel_dry_run,
        archive_root,
        zettel_id=zettel_id,
        relative_path=relative_path,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"mint_zettel_check: {state}.", result)


def tool_share_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    view_id = require_string_arg(arguments, "view")
    target_archive = require_string_arg(arguments, "target_archive")
    counterparty_id = optional_string_arg(arguments, "counterparty_id")
    counterparty_fingerprint = optional_string_arg(arguments, "counterparty_fingerprint")
    allow_sensitive = bool(arguments.get("allow_sensitive", False))
    result = call_service(
        archive_services.share_archive_scope_dry_run,
        archive_root,
        view_id=view_id,
        target_archive=target_archive,
        counterparty_id=counterparty_id,
        counterparty_fingerprint=counterparty_fingerprint,
        allow_sensitive=allow_sensitive,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"share_check: {state}.", result)


def tool_delegate_zet_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    view_id = require_string_arg(arguments, "view")
    target_archive = optional_string_arg(arguments, "target_archive")
    target_policy = optional_string_arg(arguments, "target_policy")
    counterparty_id = optional_string_arg(arguments, "counterparty_id")
    counterparty_fingerprint = optional_string_arg(arguments, "counterparty_fingerprint")
    allow_sensitive = bool(arguments.get("allow_sensitive", False))
    result = call_service(
        archive_services.delegate_zets_dry_run,
        archive_root,
        view_id=view_id,
        target_archive=target_archive,
        counterparty_id=counterparty_id,
        counterparty_fingerprint=counterparty_fingerprint,
        allow_sensitive=allow_sensitive,
        target_policy=target_policy,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"delegate_zet_check: {state}.", result)


def tool_attest_zet_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    delegate_receipt = require_string_arg(arguments, "delegate_receipt")
    counterparty_id = optional_string_arg(arguments, "counterparty_id")
    counterparty_fingerprint = optional_string_arg(arguments, "counterparty_fingerprint")
    result = call_service(
        archive_services.attest_zets_dry_run,
        archive_root,
        delegate_receipt_path=delegate_receipt,
        counterparty_id=counterparty_id,
        counterparty_fingerprint=counterparty_fingerprint,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"attest_zet_check: {state}.", result)


def tool_anchor_zet_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    attestation_receipt = require_string_arg(arguments, "attestation_receipt")
    result = call_service(
        archive_services.anchor_zets_dry_run,
        archive_root,
        attestation_receipt_path=attestation_receipt,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"anchor_zet_check: {state}.", result)


def tool_ownership_transfer_check(arguments: dict[str, Any]) -> dict[str, Any]:
    archive_root = require_path_arg(arguments, "archive_root")
    new_owner = require_string_arg(arguments, "new_owner")
    new_owner_kind = optional_string_arg(arguments, "new_owner_kind")
    new_owner_archive = optional_string_arg(arguments, "new_owner_archive")
    operators_after = optional_string_list_arg(arguments, "operators_after")
    approved_by = optional_string_list_arg(arguments, "approved_by")
    subject = optional_string_arg(arguments, "subject")
    counterparty_id = optional_string_arg(arguments, "counterparty_id")
    counterparty_fingerprint = optional_string_arg(arguments, "counterparty_fingerprint")
    reason = optional_string_arg(arguments, "reason")
    result = call_service(
        archive_services.ownership_transfer_dry_run,
        archive_root,
        new_owner=new_owner,
        new_owner_kind=new_owner_kind,
        new_owner_archive=new_owner_archive,
        operators_after=operators_after,
        approved_by=approved_by,
        subject=subject,
        counterparty_id=counterparty_id,
        counterparty_fingerprint=counterparty_fingerprint,
        reason=reason,
    )
    state = "passed" if result["ok"] else "blocked"
    return tool_success_result(f"ownership_transfer_check: {state}.", result)


class SimpleArgs:
    def __init__(self, **kwargs: Any) -> None:
        self.__dict__.update(kwargs)


class ToolError(Exception):
    pass


class InvalidParamsError(Exception):
    pass


class MethodNotFoundError(Exception):
    pass


def tool_success_result(text: str, structured: dict[str, Any]) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": text}],
        "structuredContent": structured,
        "isError": False,
    }


def tool_error_result() -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": TOOL_EXECUTION_ERROR_TEXT}],
        "structuredContent": {"error": TOOL_EXECUTION_ERROR_CODE},
        "isError": True,
    }


def mcp_redact_local_paths(requested_redaction: bool) -> bool:
    return requested_redaction or os.environ.get(MCP_ALLOW_LOCAL_PATHS_ENV) != "1"


def add_mcp_redaction_warning(result: dict[str, Any], requested_redaction: bool, effective_redaction: bool) -> None:
    if requested_redaction or not effective_redaction:
        return
    warnings = result.get("warnings")
    if not isinstance(warnings, list):
        warnings = []
        result["warnings"] = warnings
    warnings.append(
        "MCP local path disclosure was requested but ignored because "
        f"{MCP_ALLOW_LOCAL_PATHS_ENV}=1 is not set."
    )


def error_response(request_id: Any, code: int) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": JSONRPC_ERROR_MESSAGES[code]},
    }


def jsonrpc_request_id_is_valid(request_id: Any) -> bool:
    if request_id is None or isinstance(request_id, str):
        return True
    if isinstance(request_id, bool):
        return False
    if isinstance(request_id, int):
        return True
    return isinstance(request_id, float) and math.isfinite(request_id)


class _FailedStdioSink:
    encoding = "utf-8"
    errors = "strict"
    closed = False

    @staticmethod
    def write(value: str) -> int:
        return len(value)

    @staticmethod
    def flush() -> None:
        return None

    @staticmethod
    def isatty() -> bool:
        return False


_FAILED_STDOUT_SINK = _FailedStdioSink()


def neutralize_failed_stdout(stream: Any) -> None:
    if stream is sys.stdout:
        sys.stdout = _FAILED_STDOUT_SINK


def require_string_arg(arguments: dict[str, Any], name: str) -> str:
    value = arguments.get(name)
    if not isinstance(value, str) or not value:
        raise ToolError(f"Missing required string argument: {name}")
    return value


def optional_string_arg(arguments: dict[str, Any], name: str) -> str | None:
    value = arguments.get(name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ToolError(f"Argument must be a string: {name}")
    return value


def optional_string_list_arg(arguments: dict[str, Any], name: str) -> list[str] | None:
    value = arguments.get(name)
    if value is None:
        return None
    if not isinstance(value, list):
        raise ToolError(f"Argument must be a list of strings: {name}")
    result: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise ToolError(f"Argument must be a list of strings: {name}")
        result.append(item)
    return result


def require_path_arg(arguments: dict[str, Any], name: str) -> Path:
    path = Path(require_string_arg(arguments, name)).resolve()
    enforce_mcp_path_allowlist(path)
    return path


def optional_path_arg(arguments: dict[str, Any], name: str) -> Path | None:
    value = arguments.get(name)
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise ToolError(f"Argument must be a non-empty string path: {name}")
    path = Path(value).resolve()
    enforce_mcp_path_allowlist(path)
    return path


def enforce_mcp_path_allowlist(path: Path) -> None:
    raw_roots = os.environ.get(MCP_ALLOWED_ROOTS_ENV)
    if not raw_roots and os.environ.get("AI_ARCHIVE_CONTAINER") == "1":
        raw_roots = "/archives"
    if not raw_roots:
        return

    allowed_roots = [Path(item).resolve() for item in raw_roots.split(os.pathsep) if item.strip()]
    if not allowed_roots:
        return
    if any(path == root or path.is_relative_to(root) for root in allowed_roots):
        return
    allowed = ", ".join(str(root) for root in allowed_roots)
    raise ToolError(f"MCP path is outside allowed archive root(s): {path}. Allowed root(s): {allowed}")


def require_existing_archive_root(arguments: dict[str, Any]) -> Path:
    archive_root = require_path_arg(arguments, "archive_root")
    if not archive_root.is_dir():
        raise ToolError(f"Archive root does not exist or is not a directory: {archive_root}")
    return archive_root


def call_service(func: Any, *args: Any, **kwargs: Any) -> Any:
    try:
        return func(*args, **kwargs)
    except archive_services.ArchiveServiceError as exc:
        raise ToolError() from exc


if __name__ == "__main__":
    raise SystemExit(main())
